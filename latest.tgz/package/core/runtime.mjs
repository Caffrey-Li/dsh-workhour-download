// Runs the browser work in a plain Node child process instead of inside the
// DSH host.
//
// Two reasons: the host is an Electron process where loading playwright-core can
// fail (and the failure is opaque), and a hung Chrome would freeze the whole
// plugin. The CLI (bin/file.mjs) already implements every operation the settings
// page needs, so the host just collects its JSON output.
import { spawn } from 'node:child_process'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'

const isWindows = () => process.platform === 'win32'

let cachedNode = null

// The host itself may be Electron; a standalone node is preferred, and Electron's
// own binary is the last resort (it runs scripts as node with the env flag).
export async function nodeBinary() {
  if (cachedNode) return cachedNode
  const candidates = [
    '/opt/homebrew/bin/node',
    '/usr/local/bin/node',
    path.join(os.homedir(), '.local', 'bin', 'node'),
  ]
  for (const candidate of candidates) {
    if (fs.existsSync(candidate)) {
      cachedNode = candidate
      return candidate
    }
  }
  if (isWindows()) {
    const found = await new Promise((resolve) => {
      const child = spawn('where', ['node'], { windowsHide: true })
      let out = ''
      child.stdout.on('data', (chunk) => { out += chunk })
      child.on('error', () => resolve(null))
      child.on('close', () => resolve(out.split(/\r?\n/)[0]?.trim() || null))
    })
    if (found && fs.existsSync(found)) {
      cachedNode = found
      return found
    }
  }
  if (/node(\.exe)?$/i.test(path.basename(process.execPath))) {
    cachedNode = process.execPath
    return cachedNode
  }
  cachedNode = process.execPath
  return cachedNode
}

export async function runCli(root, args, { timeoutMs = 240_000, onProgress } = {}) {
  const node = await nodeBinary()
  const script = path.join(root, 'bin', 'file.mjs')
  return new Promise((resolve, reject) => {
    const child = spawn(node, [script, ...args], {
      cwd: root,
      windowsHide: true,
      env: { ...process.env, ELECTRON_RUN_AS_NODE: '1' },
    })
    let out = ''
    let err = ''
    const timer = setTimeout(() => {
      child.kill('SIGKILL')
      reject(new Error(`执行超时（${Math.round(timeoutMs / 1000)} 秒）：node ${path.basename(script)} ${args.join(' ')}`))
    }, timeoutMs)
    child.stdout.on('data', (chunk) => { out += chunk })
    child.stderr.on('data', (chunk) => {
      const text = String(chunk)
      for (const line of text.split(/\r?\n/)) {
        if (!line.startsWith('@@PROGRESS ')) { err += `${line}\n`; continue }
        try {
          const event = JSON.parse(line.slice('@@PROGRESS '.length))
          onProgress?.(event)
        } catch {
          // 不是进度行就忽略
        }
      }
    })
    child.on('error', (error) => {
      clearTimeout(timer)
      reject(error)
    })
    child.on('close', (code) => {
      clearTimeout(timer)
      const trimmed = out.trim()
      let parsed = null
      if (trimmed) {
        try {
          parsed = JSON.parse(trimmed.slice(trimmed.indexOf('{')))
        } catch {
          parsed = null
        }
      }
      if (parsed) {
        resolve(parsed)
        return
      }
      reject(new Error(err.trim() || trimmed || `子进程退出码 ${code}`))
    })
  })
}

// Writes a plan to a temp file so no quoting (Windows backslashes, spaces in
// project names) can corrupt the JSON on its way to the child.
export function planFile(plan) {
  const file = path.join(os.tmpdir(), `workhour-plan-${process.pid}-${Date.now()}.json`)
  fs.writeFileSync(file, JSON.stringify(plan), { mode: 0o600 })
  return file
}
