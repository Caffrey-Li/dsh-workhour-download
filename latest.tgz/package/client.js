// Browser half: the workhour page, shared by Settings and the sidebar panel.
//
// The host owns configuration, calendar reads and execution.
window.__ModuleLoader__.load({
  id: 'dsh-workhour-filler',
  factory(require) {
    const React = require('react')
    const h = React.createElement
    const NS = 'workhour'
    const CLIENT_BUILD = '0.7.5'
    const RUN_STEPS = ['start', 'login', 'check', 'open', 'date', 'fill', 'submit', 'done']
    const RUN_STEP_LABELS = {
      start: '准备填报', login: '启动浏览器并登录', check: '检查是否已填报', open: '打开填报页面',
      date: '选择填报日期', fill: '填写分摊和内容', submit: '提交并核对结果', done: '整理执行结果',
    }

    const dict = { zh: {}, en: {} }

    const L = {
      title: '工时填报',
      accountSection: '账号',
      accountDesc: '账号密码存在本机系统保险箱，不写文件、不进对话记录',
      accountLabel: '账号',
      passwordLabel: '密码',
      accountPlaceholder: '工号或用户名',
      passwordPlaceholder: '登录密码，至少 4 位',
      saveAccount: '保存账号',
      changeAccount: '修改',
      colProject: '项目',
      colContent: '工作内容',
      addRow: '添加一行',
      defaultContent: '默认工作内容',
      kind: '频率',
      weekday: '工作日（周一至周五）',
      daily: '每天',
      time: '时间',
      askMode: '等我来确认（跳过并提醒）',
      autoMode: '超时后自动按默认分摊执行',
      submitSwitch: '允许真实提交',
      install: '安装定时任务',
      uninstall: '卸载定时任务',
      backfillSection: '补填日历',
      daysLoading: '正在读系统日历…',
      daysFailed: '读不到日期状态',
      refreshDays: '刷新填报状态',
      prefill: '预填今天',
      submitToday: '提交今天',
      diag: '诊断',
      checkUpdate: '检查更新',
      doUpdate: '立即更新',
      upToDate: '已是最新版本',
      newVersion: '发现新版本',
      updateFailed: '更新失败',
      restartHint: '装完需要重启 DSH',
      savedAt: '已保存',
      saving: '保存中…',
      dirty: '有未保存的改动',
      saveFailed: '保存失败',
      noSession: '还没有可用会话，先在聊天里发一条消息。',
      loading: '读取中…',
      skipFiled: '已填报，跳过',
      accountSaved: '账号已保存',
      accountFailed: '账号保存失败',
    }

    const style = `
      .wh {
        --wh-surface: var(--dsw-alias-bg-layer-1, #fff);
        --wh-raised: var(--dsw-alias-bg-layer-2, #f7f8fa);
        --wh-line: var(--dsw-alias-border-l1, #e5e6eb);
        --wh-fg: var(--dsw-alias-label-primary, #1d2129);
        --wh-muted: var(--dsw-alias-label-secondary, #5a6677);
        --wh-accent: var(--dsw-alias-state-info-primary, #165dff);
        --wh-positive: var(--dsw-alias-state-success-primary, #168553);
        --wh-warning: var(--dsw-alias-state-warning-primary, #ad570b);
        --wh-error: var(--dsw-alias-state-error-primary, #c82e36);
        min-width: 0; min-height: 0; color: var(--wh-fg);
        display: flex; flex-direction: column; font: inherit; font-size: 13px; line-height: 1.5;
        container: workhour / inline-size;
      }
      [data-ds-dark-theme] .wh {
        --wh-surface: var(--dsw-alias-bg-layer-1, #151a21);
        --wh-raised: var(--dsw-alias-bg-layer-2, #1a2029);
        --wh-line: var(--dsw-alias-border-l1, #303b49);
        --wh-fg: var(--dsw-alias-label-primary, #e7edf5);
        --wh-muted: var(--dsw-alias-label-secondary, #a2afc2);
        --wh-accent: var(--dsw-alias-state-info-primary, #6696ff);
        --wh-positive: var(--dsw-alias-state-success-primary, #54d5a1);
        --wh-warning: var(--dsw-alias-state-warning-primary, #f2a33c);
        --wh-error: var(--dsw-alias-state-error-primary, #ff757d);
      }
      .wh *, .wh *::before, .wh *::after { box-sizing: border-box; }
      .wh--panel { flex: 1; }
      .wh--settings { height: min(720px, calc(100dvh - 156px)); }
      .wh-top, .wh-footer { flex: none; }
      .wh-top { padding: 0 0 10px; }
      .wh-body { flex: 1; min-height: 0; overflow: auto; overscroll-behavior: contain; padding: 1px 2px 12px; }
      .wh-stack { display: grid; gap: 12px; min-width: 0; }
      .wh-row { display: flex; flex-wrap: wrap; align-items: center; gap: 8px; min-width: 0; }
      .wh-between { justify-content: space-between; }
      .wh h1, .wh h2, .wh p { margin: 0; }
      .wh h1 { font-size: 17px; font-weight: 650; }
      .wh h2 { font-size: 14px; font-weight: 650; }
      .wh-muted { color: var(--wh-muted); font-size: 12px; }
      .wh-positive { color: var(--wh-positive); }
      .wh-warning { color: var(--wh-warning); }
      .wh-error { color: var(--wh-error); }
      .wh-card { border: 1px solid var(--wh-line); border-radius: 12px; background: var(--wh-surface); min-width: 0; }
      .wh-card-head { padding: 10px 14px; border-bottom: 1px solid var(--wh-line); }
      .wh-card-body { padding: 12px 14px; }
      .wh-overview, .wh-columns { display: grid; grid-template-columns: minmax(0, 1fr); gap: 12px; align-items: start; }
      @container workhour (min-width: 840px) { .wh-overview { grid-template-columns: minmax(0, 1fr) 248px; } }
      @container workhour (min-width: 640px) { .wh-columns { grid-template-columns: repeat(2, minmax(0, 1fr)); } }
      .wh-rail { display: grid; gap: 10px; min-width: 0; }
      .wh-note { padding: 8px 10px; background: var(--wh-raised); border: 1px solid var(--wh-line); border-radius: 8px; font-size: 12px; overflow-wrap: anywhere; }
      .wh-tabs { width: fit-content; display: flex; flex-wrap: wrap; gap: 3px; padding: 3px; border: 1px solid var(--wh-line); border-radius: 9px; margin-top: 10px; }
      .wh button, .wh input, .wh select { font: inherit; }
      .wh-btn, .wh-tab, .wh input:not([type=checkbox]), .wh select {
        min-height: 32px; border: 1px solid var(--wh-line); border-radius: 7px; color: var(--wh-fg); background: var(--wh-raised);
      }
      .wh-btn, .wh-tab { padding: 4px 10px; cursor: pointer; }
      .wh-tab { border-color: transparent; background: transparent; color: var(--wh-muted); min-height: 28px; }
      .wh-tab[aria-current=page] { color: var(--wh-accent); background: var(--wh-raised); border-color: var(--wh-line); }
      .wh-btn:hover:not(:disabled), .wh-tab:hover { border-color: var(--wh-accent); }
      .wh-primary { background: var(--wh-accent); color: #fff; border-color: transparent; font-weight: 600; }
      .wh-submit { background: color-mix(in srgb, var(--wh-warning) 13%, var(--wh-surface)); border-color: var(--wh-warning); color: var(--wh-warning); font-weight: 600; }
      .wh-quiet { border-color: transparent; background: transparent; color: var(--wh-muted); }
      .wh button:disabled { opacity: .55; cursor: not-allowed; }
      .wh :is(button,input,select):focus-visible { outline: 2px solid var(--wh-accent); outline-offset: 1px; }
      .wh input:not([type=checkbox]), .wh select { width: 100%; min-width: 0; padding: 4px 8px; }
      .wh input[type=checkbox] { accent-color: var(--wh-accent); }
      .wh-field { display: grid; gap: 4px; min-width: 0; font-size: 12px; color: var(--wh-muted); }
      .wh-field span { min-width: 0; }
      .wh-tag { padding: 2px 7px; font-size: 11px; line-height: 1.5; border-radius: 999px; background: var(--wh-raised); border: 1px solid var(--wh-line); white-space: nowrap; }
      .wh-mode { border-color: currentColor; }
      .wh-date-grid { display: grid; grid-template-columns: repeat(7, minmax(0, 1fr)); gap: 5px; }
      .wh-window-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(76px, 1fr)); gap: 5px; }
      .wh-weekday { text-align: center; font-size: 11px; color: var(--wh-muted); }
      .wh-day {
        min-width: 0; min-height: 50px; display: flex; flex-direction: column; justify-content: space-between; align-items: flex-start;
        gap: 4px; padding: 5px; border: 1px solid var(--wh-line); border-radius: 6px;
        background: var(--wh-raised); color: var(--wh-fg); cursor: pointer; text-align: left; overflow: hidden;
      }
      .wh-day[aria-pressed=true] { border-color: var(--wh-accent); color: var(--wh-accent); background: color-mix(in srgb, var(--wh-accent) 10%, var(--wh-surface)); }
      .wh-day:disabled { background: var(--wh-surface); color: var(--wh-muted); opacity: .7; }
      .wh-day.is-today { box-shadow: inset 0 0 0 1px color-mix(in srgb, var(--wh-warning) 60%, transparent); }
      .wh-day.is-rest { border-style: dashed; }
      .wh-day.is-rest:not([aria-pressed=true]) { background: color-mix(in srgb, var(--wh-raised), var(--wh-muted) 14%); }
      .wh-day-status { font-size: 10px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 100%; }
      .wh-numeric { font-variant-numeric: tabular-nums; }
      .wh-footer { background: var(--wh-surface); border: 1px solid var(--wh-line); border-radius: 9px; padding: 8px 12px; overflow-wrap: anywhere; }
      .wh-plan-row { position: relative; padding: 8px 40px 8px 8px; border: 1px solid var(--wh-line); border-radius: 8px; display: grid; gap: 7px; }
      .wh-plan-row .wh-remove { position: absolute; top: 6px; right: 6px; color: var(--wh-error); }
      @container workhour (min-width: 740px) {
        .wh-plan-row { grid-template-columns: minmax(0, 1.1fr) 84px minmax(0, 1.4fr) auto; align-items: end; padding-right: 8px; }
        .wh-plan-row .wh-remove { position: static; }
      }
      .wh-list { margin: 0; padding: 0; list-style: none; min-width: 0; }
      .wh-list li { padding: 5px 0; overflow-wrap: anywhere; }
      .wh-list li + li { border-top: 1px solid var(--wh-line); }
      .wh-empty { padding: 20px 12px; text-align: center; }
      .wh-run-feedback { margin-top: 8px; }
      .wh-run-results { max-height: min(22dvh, 144px); overflow: auto; }
      .wh-progress { width: 100%; height: 6px; accent-color: var(--wh-accent); }
      .wh-overlay { position: fixed; z-index: 3100; inset: 0; display: grid; place-items: center; padding: 12px; background: rgba(0,0,0,.45); }
      .wh-dialog { width: min(100%, 460px); max-height: 90dvh; overflow: auto; box-shadow: 0 14px 50px rgba(0,0,0,.25); }
      .wh-diagnostics { width: min(100%, 700px); }
      .wh-diagnostics pre { margin: 0; white-space: pre-wrap; overflow-wrap: anywhere; font-size: 12px; }
    `

    const TABS = [
      ['overview', '概览'], ['plan', '默认分摊'], ['schedule', '定时任务'], ['account', '账号与维护'],
    ]
    const WEEKDAYS = ['日', '一', '二', '三', '四', '五', '六']
    const PLAN_FIELDS = ['defaultPlan', 'defaultContent']
    const RULE_FIELDS = ['schedule', 'ask']
    const RUN_FIELDS = [...PLAN_FIELDS, 'submit']
    const OVERVIEW_FIELDS = ['submit', 'holidays']
    const subset = (value, fields) => Object.fromEntries(fields.map((field) => [field, value[field]]))

    function planError(rows, defaultContent) {
      if (!rows.length) return '请添加至少一个项目'
      const projects = new Set()
      let total = 0
      for (const [index, row] of rows.entries()) {
        const position = index + 1
        const project = String(row?.project ?? '').trim()
        if (!project) return `请选择第 ${position} 行的项目`
        if (projects.has(project)) return `项目「${project}」重复`
        projects.add(project)
        const percent = Number(row.percent)
        if (!Number.isInteger(percent) || percent < 1 || percent > 100) return `第 ${position} 行的占比须为 1–100 的整数`
        const content = String(row.content ?? defaultContent ?? '项目投入')
        if (!content.length || content.length > 2000) return `第 ${position} 行的工作内容须为 1–2000 字`
        total += percent
      }
      return total === 100 ? '' : `占比合计须为 100%，当前为 ${total}%`
    }

    function calendarDates(today) {
      const [year, month] = today.split('-').map(Number)
      const first = new Date(year, month - 1, 1)
      const offset = (first.getDay() + 6) % 7
      const count = new Date(year, month, 0).getDate()
      return Array.from({ length: offset + count }, (_, index) => {
        const day = index - offset + 1
        return day < 1 ? null : `${today.slice(0, 7)}-${String(day).padStart(2, '0')}`
      })
    }

    function operationResult(result) {
      if (result.skipped) return { label: L.skipFiled, detail: result.reason, tone: 'positive' }
      if (result.unconfirmed) return { label: '待核对', detail: result.message, tone: 'warning' }
      if (!result.ok) return { label: '失败', detail: result.message ?? result.error ?? '执行未完成', tone: 'error' }
      if (result.dryRun) return { label: '预填完成（未提交）', tone: 'positive' }
      return { label: '已提交', detail: result.message, tone: 'positive' }
    }

    function Section(ctx) {
      return function WorkhourSection({ surface = 'settings' }) {
        const [{ config, draft }, setSettings] = React.useState({ config: null, draft: null })
        const [status, setStatus] = React.useState(null)
        const [days, setDays] = React.useState(null)
        const [daysError, setDaysError] = React.useState('')
        const [readingDays, setReadingDays] = React.useState(false)
        const [syncFeedback, setSyncFeedback] = React.useState(null)
        const [picked, setPicked] = React.useState([])
        const [job, setJob] = React.useState(null)
        const [busy, setBusy] = React.useState('')
        const [message, setMessage] = React.useState('')
        const [saveState, setSaveState] = React.useState('')
        const [savedAt, setSavedAt] = React.useState('')
        const [creds, setCreds] = React.useState({ account: '', password: '' })
        const [editingAccount, setEditingAccount] = React.useState(false)
        const [update, setUpdate] = React.useState(null)
        const [diag, setDiag] = React.useState(null)
        const [run, setRun] = React.useState(null)
        const [confirming, setConfirming] = React.useState(null)
        const [tab, setTab] = React.useState('overview')
        const mounted = React.useRef(true)
        const daysRequest = React.useRef(null)
        const loadingStatus = React.useRef(null)

        // A session that another window is writing to refuses the call with
        // "already owned by an active write handle"; try the others before
        // giving up, and remember the one that worked.
        const goodSession = React.useRef(null)

        async function callOnce(sessionId, line) {
          const result = await ctx.remote.commands.execute(sessionId, line, [])
          if (!result?.ok) throw new Error(String(result?.error?.message ?? 'command failed'))
          const value = result.value
          const outcome = value?.result ?? value
          const text = typeof outcome === 'string' ? outcome : outcome?.text
          if (outcome && outcome.kind === 'error') throw new Error(String(text))
          return text ? JSON.parse(text) : value
        }

        async function command(line) {
          const sessionIds = ctx.get('sessions')?.list?.getSnapshot?.()?.ids ?? []
          const candidates = [goodSession.current, ...sessionIds].filter(Boolean)
          if (candidates.length === 0) throw new Error(L.noSession)
          let lastError = null
          for (const id of [...new Set(candidates)]) {
            try {
              const value = await callOnce(id, line)
              goodSession.current = id
              return value
            } catch (error) {
              lastError = error
              // An occupied session may become available on a later call.
              if (/owned|write handle|routing/i.test(String(error.message))) {
                if (goodSession.current === id) goodSession.current = null
                continue
              }
              throw error
            }
          }
          throw lastError ?? new Error(L.noSession)
        }

        const say = (value) => { if (mounted.current) setMessage(value) }
        const hasChanges = (saved, pending) => Boolean(saved && pending) && JSON.stringify(saved) !== JSON.stringify(pending)
        const keepEdits = (latest, previous, pending) => {
          const edits = Object.entries(pending ?? {}).filter(([field, value]) => JSON.stringify(previous?.[field]) !== JSON.stringify(value))
          return edits.length ? { ...latest, ...Object.fromEntries(edits) } : latest
        }

        const updateDays = (nextDays) => {
          setDays(nextDays)
          setPicked((current) => current.filter((date) => nextDays.some((day) => day.date === date && !day.filed && !day.disabled && !day.pending)))
        }

        const load = (includeJobs = false, explicit = false) => {
          if (loadingStatus.current) return loadingStatus.current
          loadingStatus.current = (async () => {
            try {
              const nextStatus = await command(includeJobs ? '/workhour status {"includeJobs":true}' : '/workhour status')
              const nextConfig = await command('/workhour config')
              if (!mounted.current) return { ok: false }
              setStatus(nextStatus)
              if (includeJobs) {
                if (nextStatus.run) setRun(nextStatus.run)
                if (nextStatus.backfill) setJob(nextStatus.backfill)
              }
              setSettings((current) => ({
                config: nextConfig,
                draft: keepEdits(nextConfig, current.config, current.draft),
              }))
              updateDays(Array.isArray(nextStatus?.days) ? nextStatus.days : [])
              if (tab === 'overview' && nextStatus.daysStale && nextStatus.passwordSaved &&
                  !nextStatus.run?.running && !nextStatus.backfill?.running) void refreshDays(false)
              return { ok: true }
            } catch (error) {
              if (!explicit) say(error.message)
              return { ok: false, error: error.message }
            } finally {
              loadingStatus.current = null
            }
          })()
          return loadingStatus.current
        }

        React.useEffect(() => {
          mounted.current = true
          void load(true)
          const onKey = (event) => {
            if (event.key === 'Escape') {
              setDiag(null)
              setConfirming(null)
            }
          }
          window.addEventListener('keydown', onKey)
          return () => {
            mounted.current = false
            window.removeEventListener('keydown', onKey)
          }
        }, [])

        React.useEffect(() => {
          if (tab !== 'overview' || !status?.today || busy || readingDays || run?.running || job?.running) return
          const reload = () => void load(true)
          const timer = setInterval(() => {
            if (new Date().toLocaleDateString('sv-SE') !== status.today) reload()
          }, 60_000)
          window.addEventListener('focus', reload)
          return () => {
            clearInterval(timer)
            window.removeEventListener('focus', reload)
          }
        }, [tab, status?.today, busy, readingDays, run?.running, job?.running])

        React.useEffect(() => {
          if (!run?.running && !job?.running) return undefined
          const statusCommand = run?.running ? '/workhour file-status' : '/workhour backfill-status'
          const setProgress = run?.running ? setRun : setJob
          let stopped = false
          let timer
          const poll = async () => {
            try {
              const next = await command(statusCommand)
              if (stopped) return
              setProgress(next)
              if (!next.running) {
                void load()
                return
              }
            } catch {
              // A session may be busy. Retry after the current request has settled.
            }
            if (!stopped) timer = setTimeout(poll, 650)
          }
          void poll()
          return () => {
            stopped = true
            clearTimeout(timer)
          }
        }, [run?.running, job?.running])

        const dirty = hasChanges(config, draft)
        const patch = (field, value) => setSettings((current) => ({ ...current, draft: { ...current.draft, [field]: value } }))

        const runDirty = draft && config && hasChanges(subset(config, RUN_FIELDS), subset(draft, RUN_FIELDS))
        const save = async (fields) => {
          if (!draft) return false
          setSaveState(L.saving)
          try {
            const payload = subset(draft, fields)
            const result = await command(`/workhour config ${JSON.stringify(payload)}`)
            if (!mounted.current) return false
            if (result?.ok !== true || !result.config) throw new Error(result?.reason ?? L.saveFailed)
            setSettings((current) => ({
              config: result.config,
              draft: keepEdits(result.config, { ...config, ...payload }, current.draft),
            }))
            setSaveState(L.savedAt)
            setSavedAt(new Date().toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' }))
            say('')
            return true
          } catch (error) {
            if (mounted.current) {
              setSaveState(L.saveFailed)
              say(error.message)
            }
            return false
          }
        }

        const saveAccount = async () => {
          const account = creds.account.trim()
          if (!account || creds.password.length < 4) {
            say('账号和密码都要填，密码至少 4 位')
            return
          }
          setBusy('account')
          say('')
          try {
            const keyResult = await command('/workhour key')
            const publicKey = keyResult && typeof keyResult.publicKey === 'string' ? keyResult.publicKey : null
            if (!publicKey) {
              throw new Error(`主机没有返回公钥：${JSON.stringify(keyResult).slice(0, 160)}`)
            }
            const enc = new TextEncoder()
            const key = await crypto.subtle.importKey(
              'spki',
              pemToBytes(publicKey),
              { name: 'RSA-OAEP', hash: 'SHA-256' },
              false,
              ['encrypt'],
            )
            const cipher = await crypto.subtle.encrypt({ name: 'RSA-OAEP' }, key, enc.encode(creds.password))
            const secret = btoa(String.fromCharCode(...new Uint8Array(cipher)))
            const result = await command(`/workhour setup ${JSON.stringify({ account, secret })}`)
            if (result?.ok === false) throw new Error(result.reason ?? L.accountFailed)
            setCreds({ account, password: '' })
            setEditingAccount(false)
            say(L.accountSaved)
            setSaveState(L.savedAt)
            setSavedAt(new Date().toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' }))
            await load()
          } catch (error) {
            say(`${L.accountFailed}：${error.message}`)
          } finally {
            if (mounted.current) setBusy('')
          }
        }

        const startBackfill = async () => {
          setBusy('backfill')
          say('')
          setSyncFeedback(null)
          try {
            if (runDirty && !(await save(RUN_FIELDS))) return
            const started = await command(`/workhour backfill ${JSON.stringify({ dates: readyPicked, dryRun: !submitEnabled })}`)
            if (!started?.started) throw new Error(started?.reason ?? '补填未启动')
            setJob({ running: true, total: started.total, done: 0, current: readyPicked[0], step: 'start', results: [], dryRun: started.dryRun ?? !submitEnabled })
            setPicked([])
          } catch (error) {
            say(error.message)
          } finally {
            if (mounted.current) setBusy('')
          }
        }

        // The run is a job on the host; the page polls it so the user sees the
        // steps instead of one long silence.
        const runNow = async () => {
          if (!draft) return
          setBusy('run')
          say('')
          setSyncFeedback(null)
          try {
            if (runDirty && !(await save(RUN_FIELDS))) return
            const started = await command(`/workhour file ${JSON.stringify({ date: today, dryRun: !submitEnabled })}`)
            if (!started?.started) throw new Error(started?.reason ?? '填报未启动')
            setRun({ running: true, date: started.date ?? today, step: 'start', steps: [], dryRun: started.dryRun ?? !submitEnabled })
          } catch (error) {
            say(error.message)
          } finally {
            if (mounted.current) setBusy('')
          }
        }

        const act = async (key, execute) => {
          setBusy(key)
          say('')
          setSyncFeedback(null)
          try {
            await execute()
          } catch (error) {
            say(error.message)
          } finally {
            if (mounted.current) setBusy('')
          }
        }

        const runSync = (key, starting, task) => act(key, async () => {
          const report = (text, value, max) => {
            if (mounted.current) setSyncFeedback({ text, value, max })
          }
          report(starting)
          try {
            const result = await task(report)
            if (mounted.current) setSyncFeedback({ tone: 'positive', ...result, done: true })
          } catch (error) {
            if (mounted.current) setSyncFeedback({ text: error.message, tone: 'error', done: true })
          }
        })

        const refreshStatus = async (text) => {
          const result = await load(true, true)
          if (!result.ok) throw new Error(result.error ?? '读取状态失败')
          return { text }
        }

        const refreshDays = (force = true) => {
          if (daysRequest.current) return daysRequest.current
          setDaysError('')
          setReadingDays(true)
          daysRequest.current = (async () => {
            try {
              const result = await command(force ? '/workhour days {"force":true}' : '/workhour days')
              if (!Array.isArray(result?.days)) throw new Error(result?.reason ?? '系统日历未返回日期')
              if (!mounted.current) return { ok: false }
              updateDays(result.days)
              setStatus((current) => ({
                ...current, daysCacheAt: result.at ?? new Date().toISOString(), daysStale: false,
                ...(result.today ? { today: result.today, backfillDays: result.days.map((day) => day.date) } : {}),
              }))
              return { ok: true }
            } catch (error) {
              if (mounted.current) setDaysError(error.message)
              return { ok: false, error: error.message }
            } finally {
              daysRequest.current = null
              if (mounted.current) setReadingDays(false)
            }
          })()
          return daysRequest.current
        }

        const syncProjects = async (report) => {
          const result = await command('/workhour sync')
          if (!result?.ok || !Array.isArray(result.projects)) throw new Error(result?.reason ?? result?.message ?? '项目同步失败')
          if (!mounted.current) return
          setStatus((current) => ({ ...current, projects: result.projects, projectsCount: result.projects.length }))
          report('项目已同步，正在读取填报日期…', 1, 2)
          const calendar = await refreshDays()
          return calendar.ok
            ? { text: `同步完成 · ${result.projects.length} 个项目，填报日期已刷新` }
            : { text: `项目已同步，填报日期刷新失败。 ${calendar.error ?? ''}`.trim(), tone: 'warning' }
        }

        const changeSchedule = async (action) => {
          const result = await command(`/workhour schedule ${JSON.stringify({ action })}`)
          if (!result?.ok || typeof result.installed !== 'boolean') throw new Error(result?.reason ?? result?.message ?? '定时任务操作失败')
          if (!mounted.current) return
          setStatus((current) => ({ ...current, scheduleInstalled: result.installed, scheduleStatus: result }))
          const message = result.installed ? '定时任务已安装' : '定时任务已卸载'
          say(dirty ? `${message}。请点「保存」应用页面中的修改` : message)
        }

        const btn = (label, onClick, disabled = false, appearance = '') => h('button', {
          type: 'button', className: `wh-btn ${appearance}`, onClick, disabled,
        }, label)
        const field = (label, control) => h('label', { className: 'wh-field' }, h('span', null, label), control)
        const tag = (label, tone = '', extra = '') => h('span', { className: `wh-tag ${tone ? `wh-${tone}` : ''} ${extra}` }, label)
        const card = (title, content, actions) => h('section', { className: 'wh-card' },
          h('div', { className: 'wh-card-head wh-row wh-between' }, h('h2', null, title), actions),
          h('div', { className: 'wh-card-body wh-stack' }, ...[content].flat()),
        )
        const notice = (text, tone = '') => text ? h('p', { className: `wh-note ${tone ? `wh-${tone}` : ''}`, role: 'status' }, text) : null
        const syncView = syncFeedback && h('div', { className: 'wh-run-feedback' }, syncFeedback.done
          ? notice(syncFeedback.text, syncFeedback.tone)
          : h('div', { className: 'wh-note wh-stack' },
              h('p', { role: 'status' }, syncFeedback.text),
              h('progress', { className: 'wh-progress', value: syncFeedback.value, max: syncFeedback.max, 'aria-label': '同步进度' })))
        const surfaceClass = `wh wh--${surface}`
        if (!draft) return h('div', { className: surfaceClass }, h('style', null, style),
          h('div', { className: 'wh-empty wh-stack' }, message ? notice(message, 'error') : !syncFeedback ? notice(L.loading) : null,
            syncView,
            message || syncFeedback?.tone === 'error'
              ? btn('重新读取', () => runSync('refresh', '正在重新读取工时设置…', () => refreshStatus('工时设置已刷新')), Boolean(busy)) : null))

        const rows = Array.isArray(draft.defaultPlan) ? draft.defaultPlan : []
        const total = rows.reduce((sum, row) => sum + (Number(row.percent) || 0), 0)
        const planIssue = planError(rows, draft.defaultContent)
        const schedule = draft.schedule ?? { enabled: false, kind: 'weekday', time: '09:05' }
        const ask = draft.ask ?? { mode: 'ask', timeoutMinutes: 10, remindEveryMinutes: 30 }
        const submitEnabled = draft.submit?.enabled === true
        const savedSubmit = config.submit?.enabled === true
        const active = run?.running ? run : job?.running ? job : null
        const executing = Boolean(active || busy === 'run' || busy === 'backfill')
        const displayedSubmit = active ? active.dryRun === false : submitEnabled
        const mode = displayedSubmit ? '真实提交' : '仅预填'
        const submitting = Boolean(busy || active || saveState === L.saving || update?.busy)
        const locked = submitting || Boolean(confirming)
        const refreshingDays = readingDays || busy === 'days'
        const projectNames = status?.projects ?? []
        const today = status?.today ?? ''
        const results = [run?.result && { ...run.result, date: run.result.date ?? run.date, at: run.finishedAt },
          ...(job?.results ?? []).map((row) => ({ ...row, at: job.finishedAt }))].filter(Boolean)
        results.sort((a, b) => String(a.at ?? '').localeCompare(String(b.at ?? '')))
        const dayResults = new Map(results.filter((row) => row.date).map((row) => [row.date, row]))
        const dayRecords = new Map((days ?? []).filter((day) => day.date.startsWith(today.slice(0, 7)) && day.date <= today)
          .map((day) => [day.date, day]))
        const windowDates = status?.backfillDays ?? [...dayRecords.keys()]
        const holidays = new Set(draft.holidays ?? [])
        const calendarReadAt = Date.parse(status?.daysCacheAt)
        const dayState = (date) => {
          const day = dayRecords.get(date)
          const result = dayResults.get(date)
          const currentResult = !(day && calendarReadAt > Date.parse(result?.at))
          const localFiling = date === today ? status?.filedToday : null
          const filed = Boolean(day?.filed ||
            (localFiling && !(day && calendarReadAt >= Date.parse(localFiling.at))) ||
            (currentResult && result?.ok && (result.skipped || result.dryRun === false)))
          const pending = Boolean(currentResult && result?.unconfirmed)
          if (filed) return { label: '已填报', blocked: true, filed: true }
          if (pending) return { label: '待核对', blocked: true, pending: true }
          if (day?.pending || (!day && windowDates.includes(date))) return { label: '待同步', blocked: true, unsynced: true }
          if (day?.disabled) return { label: '未开放', blocked: true }
          if (!day) return { label: date > today ? '未开放' : '范围外', blocked: true }
          return { label: result?.ok && result.dryRun ? '已预填' : '可补填', blocked: false }
        }
        const todayState = dayState(today)
        const todayResult = dayResults.get(today)
        const todayTitle = todayState.filed ? '今天已填报'
          : todayState.pending ? '今天的提交结果待核对'
            : todayState.blocked ? (todayState.unsynced || !dayRecords.has(today) ? '今天的状态待刷新' : '今天不可填报')
              : todayResult?.ok && todayResult.dryRun ? '今天已预填，未提交' : '今天尚未填报'
        const readyPicked = picked.filter((date) => !dayState(date).blocked)
        const toggleDate = (date) => setPicked((current) => current.includes(date) ? current.filter((key) => key !== date) : [...current, date].sort())
        const patchRow = (index, key, value) => patch('defaultPlan', rows.map((row, position) => position === index ? { ...row, [key]: value } : row))
        const scheduleText = schedule.kind === 'daily' ? '每天' : '工作日'
        const savedSchedule = config.schedule ?? {}
        const scheduleInstalled = Boolean(status?.scheduleInstalled)
        const usesSystemTask = scheduleInstalled && status?.scheduleStatus?.enabled !== false
        const scheduleLabel = usesSystemTask ? '已注册' : scheduleInstalled ? '已停用'
          : status?.scheduleStatus?.configured ? '未注册' : '未安装'
        const scheduleGate = JSON.stringify(status?.schedule) === JSON.stringify(savedSchedule) ? status?.scheduleGate : null
        const scheduleCheck = status?.scheduleCheck
        const lastScheduledRun = status?.lastScheduledRun
        const projectAction = btn(busy === 'sync' ? '同步中…' : '同步项目与日期',
          () => runSync('sync', '正在同步项目…', syncProjects), locked || readingDays)
        const refreshAction = btn(readingDays || busy === 'days' ? '刷新中…' : L.refreshDays,
          () => runSync('days', '正在刷新填报状态…', async () => {
            const result = await refreshDays()
            if (!result.ok) throw new Error(result.error ?? '填报状态刷新失败')
            return { text: '填报状态已刷新' }
          }), locked || readingDays)
        const confirmRun = (fn, dates) => submitEnabled ? setConfirming({ run: fn, dates }) : void fn()
        const accountForm = h('div', { className: 'wh-stack' },
          field(L.accountLabel, h('input', {
            value: creds.account, placeholder: L.accountPlaceholder, autoComplete: 'username',
            onChange: (event) => setCreds((current) => ({ ...current, account: event.target.value })),
          })),
          field(L.passwordLabel, h('input', {
            type: 'password', value: creds.password, placeholder: L.passwordPlaceholder, autoComplete: 'current-password',
            onChange: (event) => setCreds((current) => ({ ...current, password: event.target.value })),
          })),
          h('div', { className: 'wh-row' },
            btn(busy === 'account' ? '正在保存账号…' : L.saveAccount, saveAccount, locked, 'wh-primary'),
            status?.account ? btn('取消', () => { setEditingAccount(false); setCreds({ account: '', password: '' }) }, locked, 'wh-quiet') : null,
          ),
        )

        const heading = h('div', { className: 'wh-row wh-between' },
          h('h1', null, L.title),
          status?.account ? tag(mode, displayedSubmit ? 'warning' : 'positive', 'wh-mode') : null,
        )
        if (!status?.account) return h('div', { className: surfaceClass },
          h('style', null, style), h('header', { className: 'wh-top' }, heading, syncView),
          h('div', { className: 'wh-body' }, card('配置账号', [h('p', { className: 'wh-muted', key: 'note' }, L.accountDesc), h('div', { key: 'form' }, accountForm), notice(message, 'error')])),
        )

        const todayPanel = h('section', { className: 'wh-card wh-card-body wh-stack' },
          h('div', { className: 'wh-row wh-between' },
            h('div', { className: 'wh-stack', style: { gap: 3 } },
              h('span', { className: 'wh-muted wh-numeric' }, today || '今天'),
              h('div', { className: 'wh-row' }, h('h2', null, todayTitle), todayState.filed ? tag('已填报', 'positive') : null),
            ),
            h('div', { className: 'wh-row' },
              btn(executing ? '执行中…' : submitEnabled ? L.submitToday : L.prefill,
                () => confirmRun(runNow, [today]), locked || todayState.blocked || Boolean(planIssue), submitEnabled ? 'wh-submit' : 'wh-primary'),
              btn('查看分摊', () => setTab('plan'), false, 'wh-quiet'),
            ),
          ),
          todayState.pending ? notice('刷新填报状态，核对系统日历后再试。', 'warning') : null,
          !rows.length ? notice('请先同步项目并配置默认分摊。') : planIssue ? notice(planIssue, 'warning') : null,
        )

        const isBatch = Boolean(job?.running || busy === 'backfill')
        const completedDays = job?.running ? job.done ?? 0 : 0
        const progressTarget = job?.running ? `第 ${completedDays + 1} / ${job.total} 天 · ${job.current}`
          : isBatch ? `${readyPicked.length} 天` : run?.running ? run.date : today
        const progressStep = active ? RUN_STEP_LABELS[active.step] ?? '执行中'
          : saveState === L.saving ? '正在保存填报设置…' : '正在启动任务…'
        const resultPanel = executing
          ? card('执行进度', [
              h('p', { key: 'step', role: 'status' }, `${mode} · ${progressTarget} · ${progressStep}`),
              h('progress', {
                key: 'line', className: 'wh-progress', 'aria-label': isBatch ? '补填进度' : '当天填报进度',
                value: active ? completedDays * RUN_STEPS.length + Math.max(1, RUN_STEPS.indexOf(active.step) + 1) : undefined,
                max: (job?.running ? job.total || 1 : 1) * RUN_STEPS.length,
              }),
            ])
          : tab === 'overview' && (results.length || run?.error) ? card('执行结果', h('ul', { className: 'wh-list wh-run-results' },
              run?.error ? h('li', { className: 'wh-error' }, `${run.date ?? ''} · 失败：${run.error}`) : null,
              results.slice().reverse().map((result, index) => {
                const view = operationResult(result)
                return h('li', { key: `${result.date}-${index}`, className: 'wh-stack', style: { gap: 3 } },
                  h('div', { className: 'wh-row' }, h('span', { className: 'wh-numeric' }, result.date), tag(view.label, view.tone)),
                  view.detail ? h('span', { className: 'wh-muted' }, view.detail) : null,
                )
              }),
            )) : null

        const dayButton = (date, inWindow = false) => {
          const state = dayState(date)
          const dayOfWeek = new Date(`${date}T00:00:00`).getDay()
          const holiday = holidays.has(date)
          const rest = holiday || dayOfWeek === 0 || dayOfWeek === 6
          const label = `${date} 周${WEEKDAYS[dayOfWeek]} · ${state.label}${holiday ? ' · 节假日' : ''}`
          return h('button', {
            type: 'button', key: date, className: `wh-day${date === today ? ' is-today' : ''}${rest ? ' is-rest' : ''}`,
            disabled: state.blocked || locked, title: label, 'aria-label': inWindow ? `填报窗口 ${label}` : label,
            'aria-pressed': readyPicked.includes(date), onClick: () => toggleDate(date),
          },
          h('span', { className: 'wh-numeric' }, date.slice(inWindow ? 5 : -2)),
          h('span', { className: 'wh-day-status' }, state.label))
        }
        const filingWindow = card('可填报窗口', [
          windowDates.length ? h('p', { key: 'range', className: 'wh-muted wh-numeric' },
            `${windowDates[0]} 至 ${windowDates.at(-1)}${status?.daysStale && !refreshingDays ? ' · 状态待刷新' : ''}`) : null,
          notice(refreshingDays ? L.daysLoading : daysError ? `${L.daysFailed}：${daysError}` : null, daysError ? 'error' : ''),
          h('div', { key: 'window', className: 'wh-window-grid', 'aria-label': '可填报窗口' }, windowDates.map((date) => dayButton(date, true))),
        ], refreshAction)
        const calendar = card(today ? `${today.slice(0, 4)} 年 ${Number(today.slice(5, 7))} 月` : L.backfillSection, [
          h('div', { key: 'calendar', className: 'wh-date-grid', 'aria-label': '补填日历' },
            [...WEEKDAYS.slice(1), WEEKDAYS[0]].map((day) => h('span', { className: 'wh-weekday', key: day }, day)),
            today ? calendarDates(today).map((date, index) => {
              if (!date) return h('span', { key: `blank-${index}`, 'aria-hidden': true })
              return dayButton(date)
            }) : null,
          ),
          h('div', { key: 'selection', className: 'wh-note wh-row wh-between' },
            h('span', null, `已选 ${readyPicked.length} 天`),
            h('div', { className: 'wh-row' },
              btn('清除选择', () => setPicked([]), locked || !readyPicked.length, 'wh-quiet'),
              btn(`${submitEnabled ? '提交' : '预填'}所选 ${readyPicked.length} 天`,
                () => confirmRun(startBackfill, readyPicked), locked || !readyPicked.length || Boolean(planIssue), submitEnabled ? 'wh-submit' : 'wh-primary'),
            ),
          ),
          h('details', { key: 'holiday' },
            h('summary', { className: 'wh-muted' }, '节假日标记'),
            field('日期（YYYY-MM-DD，以逗号分隔）', h('input', {
              key: JSON.stringify(draft.holidays ?? []), defaultValue: (draft.holidays ?? []).join(', '), disabled: locked,
              onBlur: (event) => patch('holidays', event.target.value.split(/[,，\s]+/).filter(Boolean)),
            })),
          ),
        ], projectAction)

        const rail = h('aside', { className: 'wh-rail', 'aria-label': '填报设置摘要' },
          card('提交模式',
            h('div', { className: 'wh-stack' },
              h('label', { className: 'wh-row' }, h('input', {
                type: 'checkbox', checked: submitEnabled, disabled: locked,
                onChange: (event) => patch('submit', { ...draft.submit, enabled: event.target.checked }),
              }), h('span', null, L.submitSwitch)),
              h('p', { className: `wh-note wh-${displayedSubmit ? 'warning' : 'positive'}` }, active
                ? `本次执行：${mode}` : submitEnabled ? '提交前需要确认，也会影响已启用的定时任务。' : '只填写表单并留存截图。'),
            ), tag(mode, displayedSubmit ? 'warning' : 'positive')),
          card('默认分摊', rows.length ? h('ul', { className: 'wh-list' }, rows.map((row, index) => h('li', { className: 'wh-row wh-between', key: index },
            h('span', null, row.project || '未选择项目'), h('span', { className: 'wh-numeric' }, `${row.percent}%`))))
            : h('p', { className: 'wh-muted' }, '尚未配置分摊'), btn('编辑', () => setTab('plan'), false, 'wh-quiet')),
          card('定时任务', h('div', { className: 'wh-stack', style: { gap: 6 } },
            h('span', { className: 'wh-muted' }, `${savedSchedule.enabled ? '已启用' : '已停用'} · ${savedSchedule.kind === 'daily' ? '每天' : '工作日'} ${savedSchedule.time ?? '09:05'}`),
            btn('查看定时设置', () => setTab('schedule')),
          ), tag(savedSchedule.enabled && !usesSystemTask ? 'DSH 后台' : scheduleLabel, savedSchedule.enabled ? 'positive' : '')),
        )

        const allocation = card('默认分摊', [
          projectNames.length ? null : notice('同步项目后再选择填报项目。'),
          h('div', { key: 'rows', className: 'wh-stack' }, rows.map((row, index) => h('div', { className: 'wh-plan-row', key: index },
            field(L.colProject, h('select', {
              value: row.project ?? '', disabled: locked, 'aria-label': `第 ${index + 1} 行项目`,
              onChange: (event) => patchRow(index, 'project', event.target.value),
            },
            h('option', { value: '' }, '选择项目'),
            projectNames.map((name) => h('option', { value: name, key: name }, name)),
            row.project && !projectNames.includes(row.project) ? h('option', { value: row.project }, `${row.project}（不在列表）`) : null)),
            field('投入占比 %', h('input', {
              type: 'number', min: 1, max: 100, step: 1, value: row.percent ?? '', disabled: locked,
              onChange: (event) => patchRow(index, 'percent', event.target.value === '' ? '' : Number(event.target.value)),
            })),
            field(L.colContent, h('input', {
              value: row.content ?? draft.defaultContent ?? '项目投入', maxLength: 2000, disabled: locked,
              placeholder: draft.defaultContent || '项目投入', onChange: (event) => patchRow(index, 'content', event.target.value),
            })),
            btn('删除', () => patch('defaultPlan', rows.filter((_, position) => position !== index)), locked, 'wh-quiet wh-remove'),
          ))),
          h('div', { key: 'default', className: 'wh-row wh-between' },
            field(L.defaultContent, h('input', {
              value: draft.defaultContent ?? '', placeholder: '项目投入', maxLength: 2000, disabled: locked,
              onChange: (event) => patch('defaultContent', event.target.value),
            })),
            projectNames.length ? null : projectAction,
          ),
        ], h('div', { className: 'wh-row' }, tag(`合计 ${total}%`, planIssue ? 'warning' : 'positive'),
          btn(L.addRow, () => patch('defaultPlan', [...rows, { project: '', percent: '', content: draft.defaultContent || '项目投入' }]), locked)))
        const schedulePage = h('div', { className: 'wh-columns' },
          card('调度规则', [
            h('label', { key: 'enable', className: 'wh-row' }, h('input', {
              type: 'checkbox', checked: Boolean(schedule.enabled), disabled: locked,
              onChange: (event) => patch('schedule', { ...schedule, enabled: event.target.checked }),
            }), h('span', null, '启用定时填报')),
            field(L.kind, h('select', {
              value: schedule.kind, disabled: locked, onChange: (event) => patch('schedule', { ...schedule, kind: event.target.value }),
            }, h('option', { value: 'weekday' }, L.weekday), h('option', { value: 'daily' }, L.daily))),
            field(L.time, h('input', {
              type: 'time', value: schedule.time, disabled: locked, onChange: (event) => patch('schedule', { ...schedule, time: event.target.value }),
            })),
            field('执行方式', h('select', {
              value: ask.mode, disabled: locked, onChange: (event) => patch('ask', { ...ask, mode: event.target.value }),
            }, h('option', { value: 'ask' }, L.askMode), h('option', { value: 'auto' }, L.autoMode),
            h('option', { value: 'unattended' }, '无人值守，按默认分摊执行'))),
            ask.mode === 'unattended' ? h('p', { key: 'unattended', className: 'wh-muted' },
              '到点直接使用默认分摊，预填或提交由概览里的提交模式决定。') : null,
            h('div', { key: 'times', className: 'wh-columns' },
              field('询问超时（分钟）', h('input', {
                type: 'number', min: 1, value: ask.timeoutMinutes, disabled: locked,
                onChange: (event) => patch('ask', { ...ask, timeoutMinutes: Number(event.target.value) }),
              })),
              field('提醒间隔（分钟）', h('input', {
                type: 'number', min: 1, value: ask.remindEveryMinutes, disabled: locked,
                onChange: (event) => patch('ask', { ...ask, remindEveryMinutes: Number(event.target.value) }),
              })),
            ),
          ], tag(savedSchedule.enabled ? '已启用' : '已停用', savedSchedule.enabled ? 'positive' : '')),
          card('后台运行', [
            h('p', { key: 'state', className: 'wh-note' }, !savedSchedule.enabled ? '定时规则已停用'
              : `${usesSystemTask ? '由已注册的系统任务执行' : 'DSH 打开时自动执行'} · ${scheduleGate?.reason ?? (savedSubmit ? '允许真实提交' : '仅预填')}`),
            status?.scheduleStatus?.legacyBatch ? h('p', { key: 'legacy', className: 'wh-muted' },
              usesSystemTask ? '已检测到旧 Windows 系统任务，DSH 会尝试停用并接管。' : '旧 Windows 系统任务已停用。')
              : usesSystemTask ? h('p', { key: 'legacy', className: 'wh-muted' },
                '如需改由 DSH 后台运行，请卸载现有系统任务。') : null,
            h('div', { key: 'action', className: 'wh-row' },
              scheduleInstalled ? btn(L.uninstall, () => act('uninstall', () => changeSchedule('uninstall')), locked)
                : status?.platform === 'win32' ? null : btn(L.install, () => act('install', () => changeSchedule('install')), locked, 'wh-primary'),
              btn('刷新定时状态', () => runSync('schedule-status', '正在刷新定时状态…',
                () => refreshStatus('定时状态已刷新')), locked)),
            h('p', { key: 'saved', className: 'wh-muted' }, `已保存：${savedSchedule.kind === 'daily' ? '每天' : '工作日'} ${savedSchedule.time ?? '09:05'}`),
            h('p', { key: 'check', className: 'wh-muted' }, scheduleCheck
              ? `最近检查 ${new Date(scheduleCheck.at).toLocaleString()} · ${scheduleCheck.reason}` : '暂无定时检查记录'),
            lastScheduledRun ? h('p', { key: 'last', className: 'wh-muted' },
              `最近填报任务 ${lastScheduledRun.date} · ${lastScheduledRun.reason ?? (lastScheduledRun.ok ? '已完成' : '未完成')}`) : null,
            status?.scheduleStatus?.lastExitCode ? h('p', { key: 'exit', className: 'wh-error' },
              `系统任务上次退出码 ${status.scheduleStatus.lastExitCode}`) : null,
          ], tag(usesSystemTask ? '系统任务' : 'DSH 后台', savedSchedule.enabled ? 'positive' : '')),
        )

        const maintenance = h('div', { className: 'wh-columns' },
          card(L.accountSection, editingAccount ? accountForm : h('div', { className: 'wh-row wh-between' },
            h('span', null, status.account),
            tag(status.passwordSaved ? '密码已保存' : '未保存登录密码', status.passwordSaved ? 'positive' : 'warning'),
          ), !editingAccount ? btn(L.changeAccount, () => { setCreds({ account: status.account, password: '' }); setEditingAccount(true) }, locked) : null),
          card('诊断与更新', [
            h('p', { key: 'version', className: 'wh-muted' }, `插件 ${status.version ?? '—'} · 界面 ${CLIENT_BUILD}`),
            h('label', { key: 'auto-update', className: 'wh-row' }, h('input', {
              type: 'checkbox', checked: config.update?.automatic === true, disabled: locked,
              onChange: (event) => {
                const automatic = event.target.checked
                void act('auto-update', async () => {
                  const result = await command('/workhour config ' + JSON.stringify({ update: { automatic } }))
                  if (!result?.ok || !result.config) throw new Error(L.saveFailed)
                  if (!mounted.current) return
                  setSettings((current) => ({
                    config: result.config, draft: { ...current.draft, update: result.config.update },
                  }))
                })
              },
            }), h('span', null, '自动安装官方更新')),
            status?.backgroundUpdate ? h('p', { key: 'update-state', className: 'wh-muted' }, status.backgroundUpdate.status) : null,
            h('div', { key: 'actions', className: 'wh-row' },
              btn(L.diag, () => act('diag', async () => setDiag(await command('/workhour diag'))), locked),
              btn('刷新', () => runSync('refresh', '正在刷新工时设置…', () => refreshStatus('工时设置已刷新')), locked),
              btn(L.checkUpdate, () => act('update-check', async () => setUpdate(await command('/workhour update-check'))), locked),
              update?.newer && !update.done ? btn(L.doUpdate, () => act('update', async () => {
                const result = await command('/workhour update')
                if (!result?.ok) throw new Error(result?.error?.message ?? L.updateFailed)
                setUpdate((current) => ({ ...current, done: true }))
              }), locked, 'wh-primary') : null,
            ),
            update?.done ? notice(L.restartHint) : update?.newer ? notice(`${L.newVersion} v${update.latest}`) : update ? notice(L.upToDate) : null,
          ]),
        )

        const footerFields = tab === 'plan' ? PLAN_FIELDS : tab === 'schedule' ? RULE_FIELDS : tab === 'overview' ? OVERVIEW_FIELDS : []
        const footerDirty = hasChanges(subset(config, footerFields), subset(draft, footerFields))
        const ruleIssue = tab === 'schedule' && (!/^([01]\d|2[0-3]):[0-5]\d$/.test(schedule.time) ||
          ![ask.timeoutMinutes, ask.remindEveryMinutes].every((value) => Number.isInteger(value) && value >= 1))
          ? '请填写有效时间和大于 0 的整数分钟' : ''
        const footerIssue = tab === 'plan' ? planIssue : ruleIssue
        const showFooter = tab === 'plan' || tab === 'schedule' || (tab === 'overview' && footerDirty)
        const revert = () => setSettings((current) => ({ ...current, draft: { ...current.draft, ...subset(current.config, footerFields) } }))
        const body = tab === 'plan' ? allocation : tab === 'schedule' ? schedulePage : tab === 'account' ? maintenance
          : h('div', { className: 'wh-stack' }, todayPanel, filingWindow, h('div', { className: 'wh-overview' }, calendar, rail))
        return h('div', { className: surfaceClass },
          h('style', null, style),
          h('header', { className: 'wh-top' }, heading,
            h('nav', { className: 'wh-tabs', 'aria-label': '工时填报页面' }, TABS.map(([key, label]) => h('button', {
              type: 'button', key, className: 'wh-tab', 'aria-current': tab === key ? 'page' : undefined,
              onClick: () => { if (tab !== key) setTab(key) },
            }, label))),
            resultPanel ? h('div', { className: 'wh-run-feedback' }, resultPanel) : null,
            !executing ? syncView : null,
          ),
          h('div', { className: 'wh-body', key: tab },
            h('div', { className: 'wh-stack' }, notice(message, /失败|未启动/.test(message) ? 'error' : ''), body),
          ),
          showFooter ? h('footer', { className: 'wh-footer wh-row wh-between' },
            h('span', { className: `wh-muted ${footerIssue && footerDirty ? 'wh-error' : ''}`, role: 'status' },
              footerDirty ? footerIssue || L.dirty : savedAt ? `${L.savedAt} ${savedAt}` : '没有未保存的改动'),
            h('div', { className: 'wh-row' },
              btn('放弃更改', revert, !footerDirty || locked, 'wh-quiet'),
              btn(saveState === L.saving ? L.saving : tab === 'plan' ? '保存分摊' : tab === 'schedule' ? '保存规则' : '保存填报设置',
                () => save(footerFields), !footerDirty || Boolean(footerIssue) || locked, 'wh-primary'),
            ),
          ) : null,
          confirming ? h('div', { className: 'wh-overlay', onClick: () => setConfirming(null) },
            h('div', { className: 'wh-card wh-card-body wh-stack wh-dialog', role: 'dialog', 'aria-modal': true, 'aria-label': '确认真实提交', onClick: (event) => event.stopPropagation() },
              h('h2', { className: 'wh-warning' }, confirming.dates.length === 1 ? `确认提交 ${confirming.dates[0]}？` : `确认提交所选 ${confirming.dates.length} 天？`),
              h('p', null, confirming.dates.join('、')),
              h('ul', { className: 'wh-list' }, rows.map((row, index) => h('li', { key: index }, `${row.project} · ${row.percent}% · ${row.content ?? draft.defaultContent}`))),
              h('div', { className: 'wh-row wh-between' }, btn('取消', () => setConfirming(null)),
                btn('确认提交', () => { const start = confirming.run; setConfirming(null); void start() }, false, 'wh-submit')),
            )) : null,
          diag ? h('div', { className: 'wh-overlay', onClick: () => setDiag(null) },
            h('div', { className: 'wh-card wh-card-body wh-stack wh-dialog wh-diagnostics', role: 'dialog', 'aria-modal': true, 'aria-label': '诊断结果', onClick: (event) => event.stopPropagation() },
              h('h2', null, '诊断结果'), h('pre', null, JSON.stringify(diag, null, 2)),
              h('div', { className: 'wh-row' },
                btn('复制', () => void navigator.clipboard?.writeText(JSON.stringify(diag, null, 2)).catch(() => {})),
                btn('关闭', () => setDiag(null), false, 'wh-primary')),
            )) : null,
        )
      }
    }

    function pemToBytes(pem) {
      const base64 = String(pem).replace(/-----[^-]+-----/g, '').replace(/\s+/g, '')
      const raw = atob(base64)
      const out = new Uint8Array(raw.length)
      for (let i = 0; i < raw.length; i += 1) out[i] = raw.charCodeAt(i)
      return out
    }

    function WorkhourIcon({ size = 16 }) {
      return h('svg', {
        viewBox: '0 0 36 36', width: size, height: size, fill: 'none',
        stroke: 'currentColor', strokeWidth: 2.4, strokeLinecap: 'round',
        strokeLinejoin: 'round', 'aria-hidden': true,
      },
      h('rect', { x: 5, y: 7, width: 26, height: 22, rx: 4 }),
      h('path', { d: 'M5 14h26M12 4v5M24 4v5M13 21.5l3 3 6.5-6.5' }))
    }

    return {
      inject: ['slots', 'locale', 'sessions', 'remote', 'remote.commands'],
      apply(ctx) {
        const WorkhourSection = Section(ctx)
        const WorkhourPanel = () => h('section', {
          'aria-label': L.title,
          style: {
            height: '100%', minHeight: 0, minWidth: 0, boxSizing: 'border-box',
            display: 'flex', flexDirection: 'column', width: '100%', maxWidth: '1008px', margin: '0 auto',
            padding: 'var(--dsh-frame-top-clearance, 24px) clamp(12px, 4vw, 24px) 12px',
          },
        }, h(WorkhourSection, { surface: 'panel' }))

        ctx.effect(() => ctx.locale.register(NS, dict), 'workhour: dictionaries')
        ctx.effect(
          () => ctx.slots.inject('main', () =>
            ctx.slots.register({ name: 'main', key: NS }, WorkhourPanel)),
          'workhour: main panel',
        )
        ctx.effect(
          () => ctx.slots.inject('sidebar.panellist', () =>
            ctx.slots.register({ name: 'sidebar.panellist', id: NS, order: 11, label: () => L.title }, WorkhourIcon)),
          'workhour: sidebar entry',
        )
        ctx.effect(
          () => ctx.slots.inject('settings.section', () =>
            ctx.slots.register(
              { name: 'settings.section', id: NS, order: 130, label: () => L.title, locale: NS },
              WorkhourSection,
            )),
          'workhour: settings page',
        )
      },
    }
  },
})
