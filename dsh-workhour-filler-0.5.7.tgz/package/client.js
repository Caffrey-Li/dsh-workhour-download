// Browser half: the settings page.
//
// Layout follows the order a person actually works in:
//   1. 账号     — 没有配置时就在页面里填，不再依赖系统弹窗
//   2. 默认组合 — 表格 + 明确的「保存」
//   3. 定时
//   4. 补填
//   5. 版本 / 诊断
// Edits stay local until 保存 is pressed, and the footer always says whether
// there are unsaved changes — the previous version saved silently, which read
// as "nothing happened".
window.__ModuleLoader__.load({
  id: 'dsh-workhour-filler',
  factory(require) {
    const React = require('react')
    const h = React.createElement
    const NS = 'workhour'
    const CLIENT_BUILD = '0.5.7'

    const dict = { zh: {}, en: {} }

    const L = {
      title: '工时填报',
      subtitle: '到点自动填表；是否真的提交由下面的开关决定',
      accountSection: '① 账号',
      accountDesc: '账号密码存在本机系统保险箱，不写文件、不进对话记录',
      accountLabel: '账号',
      passwordLabel: '密码',
      accountPlaceholder: '工号或用户名',
      passwordPlaceholder: '登录密码，至少 4 位',
      saveAccount: '保存账号',
      changeAccount: '修改',
      configured: '已配置',
      notConfigured: '未配置',
      planSection: '② 默认组合',
      planDesc: '占比合计必须等于 100，同一个项目只能出现一次',
      colProject: '项目',
      colPercent: '占比',
      colContent: '工作内容',
      addRow: '添加一行',
      remove: '删除',
      total: '合计',
      defaultContent: '默认工作内容',
      defaultContentHint: '留空则用「项目投入」；可以只填空格',
      scheduleSection: '③ 定时',
      enabled: '启用',
      kind: '频率',
      weekday: '工作日（周一至周五）',
      daily: '每天',
      time: '时间',
      policy: '无人应答时',
      askMode: '等我来确认（跳过并提醒）',
      autoMode: '自动按默认执行',
      timeout: '询问超时',
      remind: '提醒间隔',
      minutes: '分钟',
      submitSwitch: '允许真实提交',
      submitOff: '关：只填表，不点提交（安全）',
      submitOn: '开：会真的写进系统',
      install: '安装定时任务',
      uninstall: '卸载定时任务',
      backfillSection: '④ 补填',
      backfillDesc: '已填报的日期不可选；系统只开放最近几天',
      startBackfill: '开始补填',
      pickFirst: '先选日期',
      daysLoading: '正在读系统日历…',
      daysFailed: '读不到日期状态',
      running: '正在处理',
      refresh: '刷新',
      prefill: '预填今天',
      submitToday: '提交今天',
      prefillHint: '只把表单填好、截图留证，不点提交',
      submitHint: '会真的点提交，写进系统',
      diag: '诊断',
      version: '版本',
      checkUpdate: '检查更新',
      doUpdate: '立即更新',
      upToDate: '已是最新版本',
      newVersion: '发现新版本',
      updating: '更新中…',
      updateFailed: '更新失败',
      restartHint: '装完需要重启 DSH',
      save: '保存',
      revert: '撤销改动',
      savedAt: '已保存',
      saving: '保存中…',
      dirty: '有未保存的改动',
      saveFailed: '保存失败',
      noSession: '还没有可用会话，先在聊天里发一条消息。',
      loading: '读取中…',
      confirmSubmit: '确认按默认组合提交今天？',
      confirmBackfill: '确认补填选中的日期？',
      runNow: '立即执行',
      skipFiled: '已填报，跳过',
      done: '完成',
      failed: '失败',
      accountSaved: '账号已保存',
      accountFailed: '账号保存失败',
      encryptFail: '密码加密失败，请刷新页面重试',
    }

    const css = {
      page: { display: 'flex', flexDirection: 'column', gap: '14px', padding: '2px 2px 96px' },
      card: {
        borderRadius: '14px',
        border: '1px solid var(--dsw-alias-border-l1, #e5e6eb)',
        background: 'var(--dsw-alias-bg-layer-1, #fff)',
        boxShadow: '0 1px 2px rgba(17, 24, 39, .04), 0 14px 32px -24px rgba(17, 24, 39, .35)',
        padding: '16px 18px',
        display: 'flex',
        flexDirection: 'column',
        gap: '12px',
      },
      head: { display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: '12px' },
      title: { margin: 0, fontSize: '15px', fontWeight: 600 },
      subtitle: { margin: '3px 0 0', fontSize: '12px', color: 'var(--dsw-alias-label-tertiary, #86909c)' },
      sectionTitle: { fontSize: '13px', fontWeight: 600 },
      sectionDesc: { fontSize: '12px', color: 'var(--dsw-alias-label-tertiary, #86909c)', marginTop: '2px' },
      chips: { display: 'flex', flexWrap: 'wrap', gap: '8px' },
      chip: {
        display: 'inline-flex', alignItems: 'center', gap: '6px', padding: '5px 10px', borderRadius: '999px',
        background: 'var(--dsw-alias-bg-layer-2, #f7f8fa)', border: '1px solid var(--dsw-alias-border-l1, #eceef2)', fontSize: '12px',
      },
      chipLabel: { color: 'var(--dsw-alias-label-tertiary, #86909c)' },
      chipValue: { color: 'var(--dsw-alias-label-primary, #1d2129)', fontWeight: 600 },
      row: { display: 'flex', alignItems: 'flex-end', gap: '10px', flexWrap: 'wrap' },
      field: { display: 'flex', flexDirection: 'column', gap: '5px' },
      fieldLabel: { fontSize: '12px', color: 'var(--dsw-alias-label-tertiary, #86909c)' },
      input: {
        height: '34px', padding: '0 10px', fontSize: '13px', borderRadius: '9px',
        border: '1px solid var(--dsw-alias-border-l2, #dcdfe6)', background: 'var(--dsw-alias-bg-layer-1, #fff)',
        color: 'var(--dsw-alias-label-primary, #1d2129)', outline: 'none',
      },
      button: {
        height: '34px', padding: '0 14px', fontSize: '13px', fontWeight: 500, borderRadius: '9px',
        border: '1px solid var(--dsw-alias-border-l2, #dcdfe6)', background: 'var(--dsw-alias-bg-layer-1, #fff)',
        color: 'var(--dsw-alias-label-primary, #1d2129)', cursor: 'pointer',
      },
      primary: { background: '#165dff', borderColor: '#165dff', color: '#ffffff', boxShadow: '0 6px 14px -8px rgba(22, 93, 255, .75)' },
      primaryDisabled: { background: '#a9c4ff', borderColor: '#a9c4ff', color: '#ffffff', boxShadow: 'none', cursor: 'not-allowed' },
      ghost: { borderColor: 'transparent', background: 'transparent', color: 'var(--dsw-alias-label-secondary, #4e5969)' },
      danger: { borderColor: 'transparent', background: 'transparent', color: 'var(--dsw-alias-state-error-primary, #f53f3f)' },
      muted: { fontSize: '12px', color: 'var(--dsw-alias-label-tertiary, #86909c)' },
      ok: { fontSize: '12px', color: 'var(--dsw-alias-state-success-primary, #00b42a)' },
      warn: { fontSize: '12px', color: 'var(--dsw-alias-state-warning-primary, #ff7d00)' },
      bad: { fontSize: '12px', color: 'var(--dsw-alias-state-error-primary, #f53f3f)' },
      table: { display: 'flex', flexDirection: 'column', gap: '8px' },
      tableHead: { display: 'grid', gridTemplateColumns: '1fr 92px 1fr 72px', gap: '10px', padding: '0 2px' },
      tableRow: { display: 'grid', gridTemplateColumns: '1fr 92px 1fr 72px', gap: '10px', alignItems: 'center' },
      // appearance:none so the native arrow stops hugging the border; the chevron
      // is drawn as a background image inset 10px from the right edge.
      select: {
        height: '34px', padding: '0 34px 0 10px', fontSize: '13px', borderRadius: '9px',
        border: '1px solid var(--dsw-alias-border-l2, #dcdfe6)',
        color: 'var(--dsw-alias-label-primary, #1d2129)', outline: 'none', textOverflow: 'ellipsis',
        appearance: 'none', WebkitAppearance: 'none', MozAppearance: 'none',
        backgroundImage:
          "url(\"data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'><path d='M2 4.5L6 8.5L10 4.5' fill='none' stroke='%2386909c' stroke-width='1.6' stroke-linecap='round' stroke-linejoin='round'/></svg>\")",
        backgroundRepeat: 'no-repeat',
        backgroundPosition: 'right 10px center',
        backgroundColor: 'var(--dsw-alias-bg-layer-1, #fff)',
      },
      deleteCell: { display: 'flex', justifyContent: 'center' },
      tableHeadCell: { fontSize: '12px', color: 'var(--dsw-alias-label-tertiary, #86909c)' },
      chip2: {
        minWidth: '52px', height: '30px', padding: '0 8px', borderRadius: '8px',
        border: '1px solid var(--dsw-alias-border-l2, #dcdfe6)', background: 'var(--dsw-alias-bg-layer-1, #fff)',
        fontSize: '12px', cursor: 'pointer', color: 'var(--dsw-alias-label-primary, #1d2129)',
      },
      chipSelected: { background: '#165dff', borderColor: '#165dff', color: '#ffffff', fontWeight: 600 },
      chipFiled: { background: 'var(--dsw-alias-bg-layer-2, #f2f3f5)', color: 'var(--dsw-alias-label-quaternary, #c9cdd4)', borderColor: 'transparent', cursor: 'not-allowed', textDecoration: 'line-through' },
      progress: { height: '6px', borderRadius: '999px', background: 'var(--dsw-alias-bg-layer-3, #eceef2)', overflow: 'hidden' },
      progressBar: { height: '100%', background: '#165dff', transition: 'width .3s ease' },
      saveBar: {
        position: 'sticky', bottom: '0', marginTop: '2px', display: 'flex', alignItems: 'center',
        justifyContent: 'space-between', gap: '12px', padding: '10px 14px', borderRadius: '12px',
        background: 'var(--dsw-alias-bg-layer-1, #fff)', border: '1px solid var(--dsw-alias-border-l1, #e5e6eb)',
        boxShadow: '0 -6px 20px -18px rgba(17, 24, 39, .5)',
      },
    }

    function Section(ctx) {
      return function WorkhourSection() {
        const [config, setConfig] = React.useState(null)
        const [draft, setDraft] = React.useState(null)
        const [status, setStatus] = React.useState(null)
        const [days, setDays] = React.useState(null)
        const [daysError, setDaysError] = React.useState('')
        const [picked, setPicked] = React.useState([])
        const [job, setJob] = React.useState(null)
        const [busy, setBusy] = React.useState('')
        const [message, setMessage] = React.useState('')
        const [saveState, setSaveState] = React.useState('')
        const [savedAt, setSavedAt] = React.useState('')
        const [creds, setCreds] = React.useState({ account: '', password: '' })
        const [editingAccount, setEditingAccount] = React.useState(false)
        const [update, setUpdate] = React.useState(null)
        const [diag, setDiag] = React.useState(null)
        const mounted = React.useRef(true)

        // A session that another window is writing to refuses the call with
        // "already owned by an active write handle"; try the others before
        // giving up, and remember the one that worked.
        const sessionIds = React.useMemo(() => {
          try {
            return ctx.get('sessions')?.list?.getSnapshot?.()?.ids ?? []
          } catch {
            return []
          }
        }, [])
        const goodSession = React.useRef(null)
        const badSessions = React.useRef(new Set())

        async function callOnce(sessionId, line) {
          const result = await ctx.remote.commands.execute(sessionId, line, [])
          if (!result?.ok) throw new Error(String(result?.error?.message ?? 'command failed'))
          const value = result.value
          const outcome = value?.result ?? value
          const text = typeof outcome === 'string' ? outcome : outcome?.text
          if (outcome && outcome.kind === 'error') throw new Error(String(text))
          return text ? JSON.parse(text) : value
        }

        async function command(line) {
          const candidates = [goodSession.current, ...sessionIds].filter((id) => id && !badSessions.current.has(id))
          if (candidates.length === 0) throw new Error(L.noSession)
          let lastError = null
          for (const id of [...new Set(candidates)]) {
            try {
              const value = await callOnce(id, line)
              goodSession.current = id
              return value
            } catch (error) {
              lastError = error
              // A session held by a chat window or by subagent routing refuses
              // the call; move on to the next one and do not come back.
              if (/owned|write handle|routing/i.test(String(error.message))) {
                badSessions.current.add(id)
                if (goodSession.current === id) goodSession.current = null
                continue
              }
              throw error
            }
          }
          throw lastError ?? new Error(L.noSession)
        }

        const say = (value) => { if (mounted.current) setMessage(value) }

        const load = async () => {
          try {
            const [nextStatus, nextConfig] = await Promise.all([command('/workhour status'), command('/workhour config')])
            if (!mounted.current) return
            setStatus(nextStatus)
            setConfig(nextConfig)
            setDraft(nextConfig)
            setDays(Array.isArray(nextStatus?.days) ? nextStatus.days : [])
          } catch (error) {
            say(error.message)
          }
        }

        React.useEffect(() => {
          mounted.current = true
          void load()
          const onKey = (event) => { if (event.key === 'Escape') setDiag(null) }
          window.addEventListener('keydown', onKey)
          return () => {
            mounted.current = false
            window.removeEventListener('keydown', onKey)
          }
        }, [])

        // Poll the batch while it runs.
        React.useEffect(() => {
          if (!job?.running) return undefined
          const timer = setInterval(async () => {
            try {
              const next = await command('/workhour backfill-status')
              if (!mounted.current) return
              setJob(next)
              if (!next.running) {
                clearInterval(timer)
                void load()
              }
            } catch {
              // keep polling
            }
          }, 1500)
          return () => clearInterval(timer)
        }, [job?.running])

        const dirty = Boolean(config && draft) && JSON.stringify(config) !== JSON.stringify(draft)
        const patch = (field, value) => setDraft((current) => ({ ...(current ?? {}), [field]: value }))

        const save = async () => {
          if (!draft) return
          setSaveState(L.saving)
          try {
            const payload = {
              defaultPlan: draft.defaultPlan ?? [],
              defaultContent: draft.defaultContent ?? '',
              schedule: draft.schedule,
              ask: draft.ask,
              submit: draft.submit,
            }
            const result = await command(`/workhour config ${JSON.stringify(payload)}`)
            if (!mounted.current) return
            if (result?.ok === false) {
              setSaveState(L.saveFailed)
              say(result.reason ?? L.saveFailed)
              return
            }
            setConfig(result.config ?? draft)
            setDraft(result.config ?? draft)
            setSaveState(L.savedAt)
            setSavedAt(new Date().toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' }))
            say('')
          } catch (error) {
            if (!mounted.current) return
            setSaveState(L.saveFailed)
            say(error.message)
          }
        }

        const saveAccount = async () => {
          const account = creds.account.trim()
          if (!account || creds.password.length < 4) {
            say('账号和密码都要填，密码至少 4 位')
            return
          }
          setBusy('account')
          say('')
          try {
            const keyResult = await command('/workhour key')
            const publicKey = keyResult && typeof keyResult.publicKey === 'string' ? keyResult.publicKey : null
            if (!publicKey) {
              throw new Error(`主机没有返回公钥：${JSON.stringify(keyResult).slice(0, 160)}`)
            }
            const enc = new TextEncoder()
            const key = await crypto.subtle.importKey(
              'spki',
              pemToBytes(publicKey),
              { name: 'RSA-OAEP', hash: 'SHA-256' },
              false,
              ['encrypt'],
            )
            const cipher = await crypto.subtle.encrypt({ name: 'RSA-OAEP' }, key, enc.encode(creds.password))
            const secret = btoa(String.fromCharCode(...new Uint8Array(cipher)))
            const result = await command(`/workhour setup ${JSON.stringify({ account, secret })}`)
            if (result?.ok === false) throw new Error(result.reason ?? L.accountFailed)
            setCreds({ account, password: '' })
            setEditingAccount(false)
            say(L.accountSaved)
            setSaveState(L.savedAt)
            setSavedAt(new Date().toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' }))
            await load()
          } catch (error) {
            say(`${L.accountFailed}：${error.message}`)
          } finally {
            if (mounted.current) setBusy('')
          }
        }

        const runNow = async () => {
          if (!draft) return
          setBusy('run')
          say('')
          try {
            if (dirty) await save()
            const result = await command(`/workhour file ${JSON.stringify({ dryRun: !submitEnabled })}`)
            if (result?.ok === false) {
              say(result.reason ?? result.message ?? '执行失败')
            } else {
              say(result?.message ?? (submitEnabled ? '已提交' : '已填好，未提交'))
            }
            await load()
          } catch (error) {
            say(error.message)
          } finally {
            if (mounted.current) setBusy('')
          }
        }

        const act = async (key, line, after) => {
          setBusy(key)
          say('')
          try {
            const value = await command(line)
            if (value && value.ok === false) say(value.reason ?? value.message ?? '操作没有完成')
            if (after) await after(value)
          } catch (error) {
            say(error.message)
          } finally {
            if (mounted.current) setBusy('')
          }
        }

        if (!draft) {
          return h('div', { style: css.page }, h('div', { style: css.card }, h('p', { style: { ...css.muted, margin: 0 } }, message || L.loading)))
        }

        // Nothing else works without credentials, so nothing else is shown: the
        // first screen is the account form and one sentence of explanation.
        if (!status?.account) {
          return h(
            'div',
            { style: css.page },
            h(
              'div',
              { style: css.card },
              h('div', null, h('h2', { style: css.title }, L.title), h('p', { style: css.subtitle }, '先配置账号密码，之后才能同步项目、填报工时。')),
              h(
                'div',
                { style: css.row },
                h('div', { style: { ...css.field, flex: '1 1 180px' } },
                  h('span', { style: css.fieldLabel }, L.accountLabel),
                  h('input', {
                    style: { ...css.input, width: '100%' },
                    value: creds.account,
                    placeholder: L.accountPlaceholder,
                    autoFocus: true,
                    onChange: (event) => setCreds((current) => ({ ...current, account: event.target.value })),
                  }),
                ),
                h('div', { style: { ...css.field, flex: '1 1 180px' } },
                  h('span', { style: css.fieldLabel }, L.passwordLabel),
                  h('input', {
                    style: { ...css.input, width: '100%' },
                    type: 'password',
                    autoComplete: 'off',
                    value: creds.password,
                    placeholder: L.passwordPlaceholder,
                    onChange: (event) => setCreds((current) => ({ ...current, password: event.target.value })),
                  }),
                ),
                h('button', {
                  style: { ...css.button, ...(busy === 'account' ? css.primaryDisabled : css.primary) },
                  disabled: busy === 'account',
                  onClick: saveAccount,
                }, L.saveAccount),
              ),
              h('span', { style: css.muted }, L.accountDesc),
              message ? h('span', { style: /失败|要填/.test(message) ? css.bad : css.ok }, message) : null,
            ),
          )
        }

        const rows = Array.isArray(draft.defaultPlan) ? draft.defaultPlan : []
        const total = rows.reduce((sum, row) => sum + (Number(row.percent) || 0), 0)
        const schedule = draft.schedule ?? { enabled: false, kind: 'weekday', time: '09:05' }
        const ask = draft.ask ?? { mode: 'ask', timeoutMinutes: 10, remindEveryMinutes: 30 }
        const submit = draft.submit ?? { enabled: false }
        const submitEnabled = Boolean(submit.enabled)
        const projectNames = status?.projects ?? []
        const filedDays = new Set((days ?? []).filter((day) => day.filed).map((day) => day.date))
        const selectable = (days ?? []).filter((day) => !day.filed && !day.disabled)
        const todayFiled = status?.today ? filedDays.has(status.today) : Boolean(status?.filedToday)
        const patchRow = (index, key, value) => {
          patch('defaultPlan', rows.map((row, position) => (position === index ? { ...row, [key]: value } : row)))
        }

        return h(
          'div',
          { style: css.page },

          // ---------- header + today's action ----------
          h(
            'div',
            { style: css.card },
            h(
              'div',
              { style: css.head },
              h('div', null, h('h2', { style: css.title }, L.title), h('p', { style: css.subtitle }, L.subtitle)),
              h('span', { style: dirty ? css.warn : css.muted }, dirty ? L.dirty : (saveState === L.savedAt ? `${L.savedAt} ${savedAt}` : '')),
            ),
            h(
              'div',
              { style: css.chips },
              h('span', { style: css.chip }, h('span', { style: css.chipLabel }, '账号'), h('span', { style: css.chipValue }, status?.account ?? L.notConfigured)),
              h('span', { style: css.chip }, h('span', { style: css.chipLabel }, '项目'), h('span', { style: css.chipValue }, String(status?.projectsCount ?? 0))),
              h('span', { style: css.chip }, h('span', { style: css.chipLabel }, '今天'), h('span', { style: css.chipValue }, todayFiled ? '已填报' : '未填报')),
              h('span', { style: css.chip }, h('span', { style: css.chipLabel }, '定时'), h('span', { style: css.chipValue }, status?.scheduleInstalled ? '已安装' : '未安装')),
            ),
            h(
              'div',
              { style: css.row },
              h('button', {
                style: { ...css.button, ...(busy === 'sync' ? css.primaryDisabled : css.primary) },
                disabled: Boolean(busy),
                onClick: () => act('sync', '/workhour sync', async () => { await load(); say('项目已同步') }),
              }, '同步项目'),
              h('button', { style: { ...css.button, ...css.ghost }, disabled: Boolean(busy), onClick: () => { void load() } }, L.refresh),
              h('button', {
                style: { ...css.button, ...css.ghost },
                disabled: Boolean(busy),
                onClick: async () => {
                  setBusy('diag')
                  try {
                    setDiag(await command('/workhour diag'))
                  } catch (error) {
                    say(error.message)
                  } finally {
                    if (mounted.current) setBusy('')
                  }
                },
              }, L.diag),
            ),
            h('span', { style: css.muted }, submitEnabled ? L.submitHint : L.prefillHint),
            message ? h('span', { style: css.ok }, message) : null,
          ),

          // ---------- ① account ----------
          h(
            'div',
            { style: css.card },
            h('div', null, h('div', { style: css.sectionTitle }, L.accountSection), h('div', { style: css.sectionDesc }, L.accountDesc)),
            status?.account && !editingAccount
              ? h(
                  'div',
                  { style: css.row },
                  h('span', { style: { ...css.chipValue, fontSize: '13px' } }, status.account),
                  h('span', { style: css.muted }, status.passwordSaved ? L.configured : '密码未保存'),
                  h('button', { style: { ...css.button, ...css.ghost }, onClick: () => { setEditingAccount(true); setCreds({ account: status.account ?? '', password: '' }) } }, L.changeAccount),
                )
              : h(
                  'div',
                  { style: css.row },
                  h(
                    'div',
                    { style: { ...css.field, flex: '1 1 180px' } },
                    h('span', { style: css.fieldLabel }, L.accountLabel),
                    h('input', {
                      style: { ...css.input, width: '100%' },
                      value: creds.account,
                      placeholder: L.accountPlaceholder,
                      onChange: (event) => setCreds((current) => ({ ...current, account: event.target.value })),
                    }),
                  ),
                  h(
                    'div',
                    { style: { ...css.field, flex: '1 1 180px' } },
                    h('span', { style: css.fieldLabel }, L.passwordLabel),
                    h('input', {
                      style: { ...css.input, width: '100%' },
                      type: 'password',
                      autoComplete: 'off',
                      value: creds.password,
                      placeholder: L.passwordPlaceholder,
                      onChange: (event) => setCreds((current) => ({ ...current, password: event.target.value })),
                    }),
                  ),
                  h('button', {
                    style: { ...css.button, ...(busy === 'account' ? css.primaryDisabled : css.primary) },
                    disabled: busy === 'account',
                    onClick: saveAccount,
                  }, L.saveAccount),
                ),
          ),

          // ---------- ② plan ----------
          h(
            'div',
            { style: css.card },
            h(
              'div',
              { style: css.head },
              h('div', null, h('div', { style: css.sectionTitle }, L.planSection), h('div', { style: css.sectionDesc }, L.planDesc)),
              h('span', { style: total === 100 ? css.ok : css.warn }, `${L.total} ${total}%`),
            ),
            h(
              'div',
              { style: css.table },
              h(
                'div',
                { style: css.tableHead },
                h('span', { style: css.tableHeadCell }, L.colProject),
                h('span', { style: css.tableHeadCell }, L.colPercent),
                h('span', { style: css.tableHeadCell }, L.colContent),
                h('span', null),
              ),
              rows.length === 0
                ? h('div', { style: { ...css.muted, padding: '10px 2px' } }, '还没有默认组合，点下面的「添加一行」')
                : rows.map((row, index) =>
                    h(
                      'div',
                      { style: css.tableRow, key: index },
                      h(
                        'select',
                        {
                          style: { ...css.select, width: '100%' },
                          value: projectNames.includes(row.project) ? row.project : '',
                          onChange: (event) => patchRow(index, 'project', event.target.value),
                        },
                        h('option', { value: '' }, projectNames.length ? '请选择项目' : '先同步项目'),
                        projectNames.map((name) => h('option', { key: name, value: name }, name)),
                        row.project && !projectNames.includes(row.project)
                          ? h('option', { value: row.project }, `${row.project}（不在列表）`)
                          : null,
                      ),
                      h('input', {
                        style: { ...css.input, width: '100%' },
                        type: 'number',
                        min: 1,
                        max: 100,
                        value: row.percent ?? '',
                        onChange: (event) => patchRow(index, 'percent', Number(event.target.value)),
                      }),
                      h('input', {
                        style: { ...css.input, width: '100%' },
                        value: row.content ?? '',
                        placeholder: draft.defaultContent || '项目投入',
                        onChange: (event) => patchRow(index, 'content', event.target.value),
                      }),
                      h('div', { style: css.deleteCell },
                        h('button', {
                          style: { ...css.button, ...css.danger, padding: '0 10px', height: '30px' },
                          onClick: () => patch('defaultPlan', rows.filter((_row, position) => position !== index)),
                        }, L.remove),
                      ),
                    ),
                  ),
            ),
            h('button', {
              style: { ...css.button, alignSelf: 'flex-start' },
              onClick: () => patch('defaultPlan', [...rows, { project: projectNames[0] ?? '', percent: 0, content: '' }]),
            }, L.addRow),
            h(
              'div',
              { style: { ...css.field, maxWidth: '320px' } },
              h('span', { style: css.fieldLabel }, L.defaultContent),
              h('input', {
                style: { ...css.input, width: '100%' },
                value: draft.defaultContent ?? '',
                placeholder: '项目投入',
                onChange: (event) => patch('defaultContent', event.target.value),
              }),
            ),
            h('span', { style: css.muted }, L.defaultContentHint),
          ),

          // ---------- ③ schedule ----------
          h(
            'div',
            { style: css.card },
            h('div', { style: css.sectionTitle }, L.scheduleSection),
            h(
              'div',
              { style: css.row },
              h(
                'label',
                { style: { ...css.chip, cursor: 'pointer' } },
                h('input', { type: 'checkbox', checked: Boolean(schedule.enabled), onChange: (event) => patch('schedule', { ...schedule, enabled: event.target.checked }) }),
                h('span', { style: css.chipLabel }, L.enabled),
              ),
              h(
                'div',
                { style: css.field },
                h('span', { style: css.fieldLabel }, L.kind),
                h('select', {
                  style: { ...css.input, minWidth: '190px' },
                  value: schedule.kind,
                  onChange: (event) => patch('schedule', { ...schedule, kind: event.target.value }),
                }, h('option', { value: 'weekday' }, L.weekday), h('option', { value: 'daily' }, L.daily)),
              ),
              h(
                'div',
                { style: css.field },
                h('span', { style: css.fieldLabel }, L.time),
                h('input', {
                  style: { ...css.input, width: '110px' },
                  type: 'time',
                  value: schedule.time ?? '09:05',
                  onChange: (event) => patch('schedule', { ...schedule, time: event.target.value }),
                }),
              ),
            ),
            h(
              'div',
              { style: css.row },
              h(
                'div',
                { style: css.field },
                h('span', { style: css.fieldLabel }, L.policy),
                h('select', {
                  style: { ...css.input, minWidth: '220px' },
                  value: ask.mode,
                  onChange: (event) => patch('ask', { ...ask, mode: event.target.value }),
                }, h('option', { value: 'ask' }, L.askMode), h('option', { value: 'auto' }, L.autoMode)),
              ),
              h(
                'div',
                { style: css.field },
                h('span', { style: css.fieldLabel }, L.timeout),
                h('div', { style: { display: 'flex', alignItems: 'center', gap: '6px' } },
                  h('input', {
                    style: { ...css.input, width: '76px' },
                    type: 'number', min: 1,
                    value: ask.timeoutMinutes ?? 10,
                    onChange: (event) => patch('ask', { ...ask, timeoutMinutes: Number(event.target.value) }),
                  }),
                  h('span', { style: css.muted }, L.minutes),
                ),
              ),
              h(
                'div',
                { style: css.field },
                h('span', { style: css.fieldLabel }, L.remind),
                h('div', { style: { display: 'flex', alignItems: 'center', gap: '6px' } },
                  h('input', {
                    style: { ...css.input, width: '76px' },
                    type: 'number', min: 1,
                    value: ask.remindEveryMinutes ?? 30,
                    onChange: (event) => patch('ask', { ...ask, remindEveryMinutes: Number(event.target.value) }),
                  }),
                  h('span', { style: css.muted }, L.minutes),
                ),
              ),
            ),
            h(
              'label',
              { style: { ...css.chip, cursor: 'pointer', alignSelf: 'flex-start' } },
              h('input', { type: 'checkbox', checked: submitEnabled, onChange: (event) => patch('submit', { ...submit, enabled: event.target.checked }) }),
              h('span', { style: submitEnabled ? { ...css.chipValue, color: 'var(--dsw-alias-state-error-primary, #f53f3f)' } : css.chipLabel }, `${L.submitSwitch} · ${submitEnabled ? L.submitOn : L.submitOff}`),
            ),
            h(
              'div',
              { style: css.row },
              h('button', {
                style: css.button,
                disabled: Boolean(busy),
                onClick: () => act('install', '/workhour schedule {"action":"install"}', load),
              }, L.install),
              h('button', {
                style: css.button,
                disabled: Boolean(busy),
                onClick: () => act('uninstall', '/workhour schedule {"action":"uninstall"}', load),
              }, L.uninstall),
            ),
          ),

          // ---------- ④ backfill ----------
          h(
            'div',
            { style: css.card },
            h(
              'div',
              { style: css.head },
              h('div', null, h('div', { style: css.sectionTitle }, L.backfillSection), h('div', { style: css.sectionDesc }, L.backfillDesc)),
              days === null ? h('span', { style: css.muted }, L.daysLoading) : h('span', { style: css.muted }, `${selectable.length} 天可补填`),
            ),
            daysError ? h('span', { style: css.warn }, `${L.daysFailed}：${daysError}`) : null,
            h(
              'div',
              { style: { display: 'flex', flexWrap: 'wrap', gap: '8px' } },
              (days ?? []).map((day) =>
                h('button', {
                  key: day.date,
                  disabled: day.filed || day.disabled || Boolean(job?.running),
                  title: day.filed ? L.skipFiled : day.date,
                  style: { ...css.chip2, ...(day.filed || day.disabled ? css.chipFiled : {}), ...(picked.includes(day.date) ? css.chipSelected : {}) },
                  onClick: () => setPicked((current) => (current.includes(day.date) ? current.filter((value) => value !== day.date) : [...current, day.date].sort())),
                }, day.date.slice(-2)),
              ),
            ),
            job
              ? h(
                  'div',
                  { style: { display: 'flex', flexDirection: 'column', gap: '8px' } },
                  h('div', { style: css.progress },
                    h('div', { style: { ...css.progressBar, width: `${job.total ? Math.round(((job.running ? job.done : job.total) / job.total) * 100) : 0}%` } }),
                  ),
                  h('span', { style: css.muted }, job.running ? `${L.running} ${job.current ?? ''} · ${job.done}/${job.total}` : `${L.done} ${(job.results ?? []).filter((row) => row.ok).length}/${job.total}`),
                  h('div', { style: { display: 'flex', flexDirection: 'column', gap: '4px' } },
                    (job.results ?? []).map((result, index) =>
                      h('span', { key: index, style: result.ok ? css.ok : css.bad },
                        `${result.date ?? ''} ${result.skipped ? L.skipFiled : result.ok ? L.done : `${L.failed}：${result.message ?? ''}`}`),
                    ),
                  ),
                )
              : null,
            h('button', {
              style: { ...css.button, ...(picked.length === 0 || job?.running ? css.primaryDisabled : css.primary), alignSelf: 'flex-start' },
              disabled: Boolean(busy) || Boolean(job?.running) || picked.length === 0,
              onClick: async () => {
                if (!window.confirm(L.confirmBackfill)) return
                say('')
                try {
                  const started = await command(`/workhour backfill ${JSON.stringify({ dates: picked, dryRun: !submitEnabled })}`)
                  if (started?.busy) { say(started.reason ?? ''); return }
                  setJob({ running: true, total: started.total, done: 0, current: picked[0], results: [] })
                  setPicked([])
                } catch (error) {
                  say(error.message)
                }
              },
            }, `${L.startBackfill}${picked.length ? ` ${picked.length} 天` : ''}`),
          ),

          // ---------- version ----------
          h(
            'div',
            { style: css.card },
            h(
              'div',
              { style: css.head },
              h('div', null,
                h('div', { style: css.sectionTitle }, `${L.version} v${status?.version ?? '—'} · 界面 ${CLIENT_BUILD}`),
                h('div', { style: css.sectionDesc },
                  update?.diag ? '诊断结果已弹出'
                    : update === null ? '检查是否有新版本'
                      : update.error ? `${L.updateFailed}：${update.error}`
                        : update.busy ? L.updating
                          : update.newer === false ? L.upToDate
                            : `${L.newVersion} v${update.latest}${update.done ? ` · ${L.restartHint}` : ''}`),
              ),
              h(
                'div',
                { style: { display: 'flex', gap: '8px' } },
                update && update.newer
                  ? h('button', {
                      style: { ...css.button, ...css.primary },
                      disabled: Boolean(busy) || Boolean(update.busy),
                      onClick: async () => {
                        setUpdate({ ...update, busy: true })
                        try {
                          const result = await command('/workhour update')
                          setUpdate({ ...update, busy: false, done: Boolean(result?.ok), error: result?.ok ? null : (result?.error?.message ?? '安装失败') })
                        } catch (error) {
                          setUpdate({ ...update, busy: false, error: error.message })
                        }
                      },
                    }, L.doUpdate)
                  : null,
                h('button', {
                  style: css.button,
                  disabled: Boolean(busy) || Boolean(update?.busy),
                  onClick: async () => {
                    setBusy('update-check')
                    try {
                      const result = await command('/workhour update-check')
                      setUpdate({ ...result, error: null })
                    } catch (error) {
                      setUpdate({ error: error.message })
                    } finally {
                      if (mounted.current) setBusy('')
                    }
                  },
                }, L.checkUpdate),
              ),
            ),
          ),

          // ---------- diagnostics ----------
          diag
            ? h(
                'div',
                {
                  style: {
                    position: 'fixed', inset: 0, zIndex: 3000, background: 'rgba(15, 18, 24, .45)',
                    display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '24px',
                  },
                  onClick: () => setDiag(null),
                },
                h(
                  'div',
                  {
                    style: {
                      width: 'min(720px, 100%)', maxHeight: 'calc(100vh - 96px)', display: 'flex', flexDirection: 'column',
                      background: 'var(--dsw-alias-bg-layer-1, #fff)', borderRadius: '14px',
                      border: '1px solid var(--dsw-alias-border-l1, #e5e6eb)', boxShadow: '0 24px 60px -20px rgba(17,24,39,.45)',
                      overflow: 'hidden',
                    },
                    onClick: (event) => event.stopPropagation(),
                  },
                  h(
                    'div',
                    { style: { display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '14px 16px', borderBottom: '1px solid var(--dsw-alias-border-l1, #eceef2)' } },
                    h('strong', { style: { fontSize: '14px' } }, '诊断结果'),
                    h('button', { style: { ...css.button, ...css.ghost }, onClick: () => setDiag(null) }, '关闭'),
                  ),
                  h(
                    'pre',
                    {
                      style: {
                        margin: 0, padding: '14px 16px', fontSize: '12px', lineHeight: 1.55, overflow: 'auto',
                        maxHeight: 'calc(100vh - 200px)', whiteSpace: 'pre-wrap', wordBreak: 'break-word',
                        color: 'var(--dsw-alias-label-primary, #1d2129)',
                      },
                    },
                    JSON.stringify(diag, null, 2),
                  ),
                  h(
                    'div',
                    { style: { display: 'flex', justifyContent: 'flex-end', gap: '8px', padding: '12px 16px', borderTop: '1px solid var(--dsw-alias-border-l1, #eceef2)' } },
                    h('button', {
                      style: css.button,
                      onClick: () => {
                        void navigator.clipboard?.writeText(JSON.stringify(diag, null, 2)).catch(() => {})
                      },
                    }, '复制'),
                    h('button', { style: { ...css.button, ...css.primary }, onClick: () => setDiag(null) }, '知道了'),
                  ),
                ),
              )
            : null,

          // ---------- sticky save bar ----------
          h(
            'div',
            { style: css.saveBar },
            h('span', { style: dirty ? css.warn : css.muted },
              dirty ? L.dirty : (saveState === L.savedAt ? `${L.savedAt} ${savedAt}` : (saveState || '没有未保存的改动'))),
            h(
              'div',
              { style: { display: 'flex', gap: '8px' } },
              dirty
                ? h('button', { style: { ...css.button, ...css.ghost }, onClick: () => setDraft(config) }, L.revert)
                : null,
              h('button', {
                style: { ...css.button, ...(dirty && saveState !== L.saving ? css.button : css.primaryDisabled) },
                disabled: !dirty || saveState === L.saving,
                onClick: save,
              }, saveState === L.saving ? L.saving : L.save),
              h('button', {
                style: { ...css.button, ...(busy === 'run' || job?.running ? css.primaryDisabled : css.primary) },
                disabled: Boolean(busy) || Boolean(job?.running),
                onClick: () => {
                  if (submitEnabled && !window.confirm(L.confirmSubmit)) return
                  void runNow()
                },
              }, busy === 'run' ? '执行中…' : L.runNow),
            ),
          ),
        )
      }
    }

    function pemToBytes(pem) {
      const base64 = String(pem).replace(/-----[^-]+-----/g, '').replace(/\s+/g, '')
      const raw = atob(base64)
      const out = new Uint8Array(raw.length)
      for (let i = 0; i < raw.length; i += 1) out[i] = raw.charCodeAt(i)
      return out
    }

    return {
      inject: ['slots', 'locale', 'sessions', 'remote', 'remote.commands'],
      apply(ctx) {
        ctx.effect(() => ctx.locale.register(NS, dict), 'workhour: dictionaries')
        ctx.effect(
          () => ctx.slots.inject('settings.section', () =>
            ctx.slots.register(
              { name: 'settings.section', id: 'workhour', order: 130, label: () => L.title, locale: NS },
              Section(ctx),
            )),
          'workhour: settings page',
        )
      },
    }
  },
})
