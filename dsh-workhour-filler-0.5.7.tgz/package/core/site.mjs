// Everything that knows the internal site's shape lives here: addressing,
// sign-in and the small helpers the flows share.
//
// The page is a Vue 2 + Vant single-page app (router in hash mode), so
// navigation changes location.hash instead of loading a document, and the
// layout is mobile-first with a `.van-*` component tree.
import fs from 'node:fs'
import path from 'node:path'
import { files, ensureDirs, timestamp } from './paths.mjs'

export const BASE = process.env.WORKHOUR_BASE || 'https://eis.goldwind.com/qmxm/app/'
export const ROUTES = {
  login: '#/login',
  home: '#/home',
  addDay: '#/add-day-hours',
  addMonth: '#/add-month-hours',
  list: '#/work-hour-list',
}

export function url(hash) {
  return `${BASE}${hash}`
}

export async function go(page, hash) {
  const target = url(hash)
  if (page.url().includes(`#${hash.replace(/^#/, '')}`)) return
  await page.goto(target, { waitUntil: 'domcontentloaded' })
  await settle(page)
}

// The SPA paints late and toasts float over the layout; a short quiet period
// after navigation is cheaper than guessing at every selector's timing.
export async function settle(page, ms = 900) {
  await page.waitForLoadState('domcontentloaded').catch(() => {})
  await page.waitForTimeout(ms)
}

export async function loginVisible(page) {
  return (await page.locator('input[placeholder="用户名"]').count()) > 0
}

export async function isLoggedIn(page) {
  if (await loginVisible(page)) return false
  const hash = new URL(page.url()).hash
  return hash !== '' && hash !== ROUTES.login
}

export async function login(page, { account, password }) {
  await go(page, ROUTES.login)
  if (!(await loginVisible(page))) return { ok: true, already: true }

  await page.locator('input[placeholder="用户名"]').fill(account)
  await page.locator('input[placeholder="密码"]').fill(password)
  await page.locator('button:has-text("登录")').first().click()

  const deadline = Date.now() + 25_000
  while (Date.now() < deadline) {
    if (!(await loginVisible(page))) {
      await settle(page, 600)
      return { ok: true, already: false }
    }
    const error = await readToast(page)
    if (error) return { ok: false, reason: error }
    await page.waitForTimeout(400)
  }
  return { ok: false, reason: '登录超时：25 秒内页面没有离开登录页' }
}

export async function readToast(page) {
  const toast = page.locator('.van-toast__text, .van-notify__text, .van-dialog__message')
  const count = await toast.count()
  if (!count) return null
  const text = (await toast.first().innerText().catch(() => '')).trim()
  return text || null
}

// Saves the rendered DOM plus a screenshot of a step, so a selector that stops
// matching the site can be diagnosed months later without a browser.
export async function capture(page, name) {
  ensureDirs()
  const stamp = timestamp()
  const dir = files.explore()
  const html = await page.content().catch(() => '')
  const htmlPath = path.join(dir, `${stamp}-${name}.html`)
  fs.writeFileSync(htmlPath, html, { mode: 0o600 })
  const shot = path.join(dir, `${stamp}-${name}.png`)
  await page.screenshot({ path: shot }).catch(() => {})
  return { html: htmlPath, shot }
}

// Text of every visible control on the page, which is how the flaky parts of
// the site (a picker, a calendar) are located without hard-coding structure.
export async function visibleText(page) {
  return page.evaluate(() => {
    const out = []
    const walk = (node) => {
      for (const child of node.children) {
        const style = getComputedStyle(child)
        if (style.display === 'none' || style.visibility === 'hidden') continue
        if (child.children.length === 0) {
          const text = (child.textContent || '').trim()
          if (text) out.push(text)
        } else {
          walk(child)
        }
      }
    }
    walk(document.body)
    return out
  })
}
