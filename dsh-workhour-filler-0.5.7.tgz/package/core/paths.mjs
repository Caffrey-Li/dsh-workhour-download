// Resolves every on-disk location the plugin uses.
// The host plugin, the launchd runner and the CLI all share this module so a
// scheduled run and a click in the settings page read the same files.
import os from 'node:os'
import path from 'node:path'
import fs from 'node:fs'

export function home() {
  return process.env.DSH_WORKHOUR_HOME || path.join(os.homedir(), '.dsh-workhour')
}

export const files = {
  config: () => path.join(home(), 'config.json'),
  state: () => path.join(home(), 'state.json'),
  history: () => path.join(home(), 'history.jsonl'),
  chromeProfile: () => path.join(home(), 'chrome-profile'),
  screenshots: () => path.join(home(), 'screenshots'),
  logs: () => path.join(home(), 'logs'),
  explore: () => path.join(home(), 'explore'),
}

export function ensureDirs() {
  for (const dir of [home(), files.chromeProfile(), files.screenshots(), files.logs(), files.explore()]) {
    fs.mkdirSync(dir, { recursive: true, mode: 0o700 })
  }
}

export function timestamp(date = new Date()) {
  const pad = (n) => String(n).padStart(2, '0')
  return `${date.getFullYear()}${pad(date.getMonth() + 1)}${pad(date.getDate())}-${pad(date.getHours())}${pad(date.getMinutes())}${pad(date.getSeconds())}`
}

export function isoDay(date = new Date()) {
  const pad = (n) => String(n).padStart(2, '0')
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`
}

export function hhmm(date = new Date()) {
  const pad = (n) => String(n).padStart(2, '0')
  return `${pad(date.getHours())}:${pad(date.getMinutes())}`
}
