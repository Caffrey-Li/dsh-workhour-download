// Self-update: read a version manifest from the public download host, compare it
// with the running package, and hand the selected tarball to DSH's plugin
// manager. The tarball stays encrypted on that host, so the same password that
// guards the download page also guards an update.
import crypto from 'node:crypto'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'

export const DEFAULT_MANIFEST = 'https://caffrey-li.github.io/dsh-workhour-download/latest.json'

export function currentVersion() {
  try {
    return JSON.parse(fs.readFileSync(new URL('../package.json', import.meta.url), 'utf8')).version
  } catch {
    return '0.0.0'
  }
}

// Only the dotted numbers are compared; a prerelease sorts before its release.
export function compareVersions(left, right) {
  const parse = (value) => String(value ?? '0').split('-')[0].split('.').map((part) => Number(part) || 0)
  const a = parse(left)
  const b = parse(right)
  for (let index = 0; index < Math.max(a.length, b.length); index += 1) {
    const diff = (a[index] ?? 0) - (b[index] ?? 0)
    if (diff !== 0) return diff
  }
  const aPre = String(left).includes('-')
  const bPre = String(right).includes('-')
  if (aPre === bPre) return 0
  return aPre ? -1 : 1
}

export async function fetchManifest(url = DEFAULT_MANIFEST) {
  const response = await fetch(url, { signal: AbortSignal.timeout(15_000), headers: { 'cache-control': 'no-cache' } })
  if (!response.ok) throw new Error(`更新清单读取失败：HTTP ${response.status}`)
  const manifest = await response.json()
  if (!manifest?.version || !manifest?.file) throw new Error('更新清单格式不对（缺 version 或 file）')
  return manifest
}

export async function checkForUpdate(url = DEFAULT_MANIFEST) {
  const manifest = await fetchManifest(url)
  const current = currentVersion()
  return {
    current,
    latest: manifest.version,
    newer: compareVersions(manifest.version, current) > 0,
    notes: manifest.notes ?? null,
    releasedAt: manifest.releasedAt ?? null,
    encrypted: Boolean(manifest.enc),
    manifest,
  }
}

// What the plugin manager should install: a plain tarball URL when the manifest
// offers one, else the decrypted local file from the encrypted payload.
export function installSpec(manifest) {
  for (const candidate of [manifest?.channel, manifest?.tgz]) {
    if (typeof candidate === 'string' && /^https?:/.test(candidate)) return candidate
  }
  return null
}

export async function downloadPackage(manifest, password) {
  const response = await fetch(manifest.file, { signal: AbortSignal.timeout(120_000) })
  if (!response.ok) throw new Error(`安装包下载失败：HTTP ${response.status}`)
  const payload = Buffer.from(await response.arrayBuffer())

  let bytes = payload
  if (manifest.enc) {
    if (!password) throw new Error('安装包是加密的，需要下载密码')
    const salt = Buffer.from(manifest.enc.salt, 'base64')
    const iv = Buffer.from(manifest.enc.iv, 'base64')
    const key = crypto.pbkdf2Sync(password, salt, Number(manifest.enc.iterations ?? 210_000), 32, 'sha256')
    const body = payload.subarray(0, payload.length - 16)
    const tag = payload.subarray(payload.length - 16)
    const decipher = crypto.createDecipheriv('aes-256-gcm', key, iv)
    decipher.setAuthTag(tag)
    try {
      bytes = Buffer.concat([decipher.update(body), decipher.final()])
    } catch {
      throw new Error('下载密码不对，安装包解不开')
    }
  }

  const target = path.join(os.tmpdir(), `dsh-workhour-filler-${manifest.version}.tgz`)
  fs.writeFileSync(target, bytes, { mode: 0o600 })
  return target
}
