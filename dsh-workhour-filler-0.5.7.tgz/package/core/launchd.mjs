// The scheduled job, on both systems.
//
// macOS:  a LaunchAgent that wakes the tick every five minutes.
// Windows: a Task Scheduler entry doing the same.
//
// The tick itself decides whether this wake-up should file anything, so the
// schedule in config.json can change without touching either registration.
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { execFile } from 'node:child_process'
import { promisify } from 'node:util'
import { deploy, deployedRoot } from './deploy.mjs'

const run = promisify(execFile)
export const LABEL = 'com.dsh.workhour'
export const WIN_TASK = 'DSH-Workhour-Filler'
const INTERVAL_SECONDS = 300

const isWindows = () => process.platform === 'win32'

function agentsDir() {
  return path.join(os.homedir(), 'Library', 'LaunchAgents')
}

function plistPath() {
  return path.join(agentsDir(), `${LABEL}.plist`)
}

// Prefer a stable, shell-visible node over whatever binary happened to start
// the install (a version manager's node can vanish on the next upgrade).
async function nodePath() {
  const candidates = ['/opt/homebrew/bin/node', '/usr/local/bin/node', path.join(os.homedir(), '.local', 'bin', 'node')]
  for (const candidate of candidates) {
    if (fs.existsSync(candidate)) return candidate
  }
  if (isWindows()) {
    const fromPath = await run('where', ['node']).then((result) => result.stdout.split(/\r?\n/)[0]?.trim()).catch(() => '')
    if (fromPath && fs.existsSync(fromPath)) return fromPath
  }
  if (/node(\.exe)?$/i.test(path.basename(process.execPath))) return process.execPath
  // No standalone node: DSH's own Electron binary can run the script as node.
  return process.execPath
}

function tickPath(root = process.cwd()) {
  return path.join(root, 'bin', 'tick.mjs')
}

// --- Windows --------------------------------------------------------------

async function windowsCreate(deployed, node) {
  const wrapper = path.join(deployed, 'run-tick.cmd')
  const logDir = path.join(os.homedir(), '.dsh-workhour', 'logs')
  fs.mkdirSync(logDir, { recursive: true })
  // Electron needs this flag to behave as node; a standalone node ignores it.
  fs.writeFileSync(
    wrapper,
    [
      '@echo off',
      'set ELECTRON_RUN_AS_NODE=1',
      `"${node}" "${path.join(deployed, 'bin', 'tick.mjs')}" >> "${path.join(logDir, 'task.out.log')}" 2>&1`,
      '',
    ].join('\r\n'),
    { mode: 0o644 },
  )
  // The task repeats every five minutes; tick decides what to do.
  await run('schtasks', ['/Create', '/F', '/SC', 'MINUTE', '/MO', '5', '/TN', WIN_TASK, '/TR', `"${wrapper}"`])
  return wrapper
}

async function windowsStatus() {
  try {
    await run('schtasks', ['/Query', '/TN', WIN_TASK])
    return true
  } catch {
    return false
  }
}

// --- public API -----------------------------------------------------------

export function status() {
  if (isWindows()) {
    // The synchronous face of the Windows check keeps callers simple; the
    // detailed answer comes from schtasks through `query()` when needed.
    return { installed: fs.existsSync(path.join(deployedRoot(), 'run-tick.cmd')), path: WIN_TASK, platform: 'win32' }
  }
  const file = plistPath()
  if (!fs.existsSync(file)) return { installed: false, path: file, platform: process.platform }
  return { installed: true, path: file, content: fs.readFileSync(file, 'utf8'), platform: process.platform }
}

export async function query() {
  if (!isWindows()) return { installed: status().installed, path: plistPath() }
  const installed = await windowsStatus()
  return { installed, path: WIN_TASK }
}

export async function install(root) {
  const node = await nodePath()
  const deployed = deploy(root)
  const script = tickPath(deployed)
  if (!fs.existsSync(script)) throw new Error(`找不到 ${script}`)

  if (isWindows()) {
    const wrapper = await windowsCreate(deployed, node)
    return { installed: true, path: WIN_TASK, deployed, wrapper, platform: 'win32' }
  }

  const plist = `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key><string>${LABEL}</string>
  <key>ProgramArguments</key>
  <array>
    <string>${node}</string>
    <string>${script}</string>
  </array>
  <key>WorkingDirectory</key><string>${deployed}</string>
  <key>EnvironmentVariables</key>
  <dict>
    <key>PATH</key><string>/usr/local/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin</string>
    <key>ELECTRON_RUN_AS_NODE</key><string>1</string>
  </dict>
  <key>StartInterval</key><integer>${INTERVAL_SECONDS}</integer>
  <key>RunAtLoad</key><false/>
  <key>StandardOutPath</key><string>${path.join(os.homedir(), '.dsh-workhour', 'logs', 'launchd.out.log')}</string>
  <key>StandardErrorPath</key><string>${path.join(os.homedir(), '.dsh-workhour', 'logs', 'launchd.err.log')}</string>
</dict>
</plist>
`
  fs.mkdirSync(agentsDir(), { recursive: true })
  fs.writeFileSync(plistPath(), plist, { mode: 0o644 })
  await run('launchctl', ['bootout', `gui/${process.getuid()}`, plistPath()]).catch(() => {})
  await run('launchctl', ['bootstrap', `gui/${process.getuid()}`, plistPath()])
  return { installed: true, path: plistPath(), deployed, platform: 'darwin' }
}

export async function uninstall() {
  if (isWindows()) {
    await run('schtasks', ['/Delete', '/TN', WIN_TASK, '/F']).catch(() => {})
    const wrapper = path.join(deployedRoot(), 'run-tick.cmd')
    try {
      fs.unlinkSync(wrapper)
    } catch {
      // already gone
    }
    return { installed: false, path: WIN_TASK, platform: 'win32' }
  }
  if (process.platform !== 'darwin') return { installed: false }
  await run('launchctl', ['bootout', `gui/${process.getuid()}`, plistPath()]).catch(() => {})
  if (fs.existsSync(plistPath())) fs.unlinkSync(plistPath())
  return { installed: false, path: plistPath(), platform: 'darwin' }
}
