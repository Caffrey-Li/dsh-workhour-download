// Ties the pieces together: one place decides whether a day is already filed,
// runs a filing, and (for the scheduled path) asks the user first.
import { open } from './browser.mjs'
import { readConfig } from './config.mjs'
import { readState, updateState, findSubmission, recordRun } from './store.mjs'
import { getPassword } from './keychain.mjs'
import { dayKey, listBackfillableDays } from './policy.mjs'
import { notify, ask, choose, prompt, openApp } from './notify.mjs'
import { calendarMarks, fileDay, ensureSignedIn, validatePlan } from './flow.mjs'
import { hhmm } from './paths.mjs'

const TITLE = 'DSH 工时填报'

export async function withSession(fn, { headless = true } = {}) {
  const state = readState()
  if (!state.account) throw new Error('还没有配置账号：先运行 node bin/setup.mjs')
  const password = await getPassword(state.account)
  if (!password) throw new Error(`钥匙串里没有 ${state.account} 的密码：先运行 node bin/setup.mjs`)
  const browser = await open({ headless })
  try {
    await ensureSignedIn(browser.page, { account: state.account, password })
    return await fn(browser.page)
  } finally {
    await browser.close()
  }
}

export function describeFiled(date) {
  const local = findSubmission(date)
  if (local?.time) return `当天已在 ${local.time} 提交过`
  return '当天已提交过（系统日历上已有标记）'
}

// Reads the site's own calendar marks for the month; the dot is the site's
// statement that this person filed that day, which beats any local log.
export async function filedOn(page, date) {
  const marks = await calendarMarks(page)
  const day = Number(dayKey(date).slice(-2))
  return { filed: Boolean(marks[day]?.dot), dot: marks[day]?.dot ?? null, marks }
}

export async function runDay({ date, plan, dryRun, headless = true, skipIfFiled = true }) {
  const config = readConfig()
  // 安全模式：没显式开启 submit.enabled 时，永远只填表不提交。
  const effectiveDryRun = dryRun === undefined ? !config.submit?.enabled : Boolean(dryRun) || !config.submit?.enabled
  return withSession(async (page) => {
    const status = await filedOn(page, date)
    if (status.filed && skipIfFiled) {
      return { ok: true, skipped: true, reason: describeFiled(dayKey(date)), date: dayKey(date), dot: status.dot }
    }
    const rows = validatePlan(plan, config.defaultContent)
    const attempts = effectiveDryRun ? 1 : 1 + Math.max(0, Number(config.retry?.times ?? 1))
    let result
    for (let attempt = 1; attempt <= attempts; attempt += 1) {
      result = await fileDay({ page, date: dayKey(date), plan: rows, submitIt: !effectiveDryRun, label: `day-${dayKey(date)}-try${attempt}` })
      if (result.ok) break
      recordRun({ date: dayKey(date), plan: rows, mode: 'attempt', ok: false, attempt, message: result.message, screenshot: result.screenshot })
      if (attempt < attempts) {
        // Never submit twice blindly: ask the site whether the day is filed now.
        const state = await filedOn(page, date).catch(() => ({ filed: false }))
        if (state.filed) {
          result = { ok: true, message: '提交成功（重试前系统已显示已提交）' }
          break
        }
        await page.reload({ waitUntil: 'domcontentloaded' }).catch(() => {})
      }
    }
    recordRun({ date: dayKey(date), plan: rows, mode: effectiveDryRun ? 'dry-run' : 'submit', ok: result.ok, message: result.message, screenshot: result.screenshot })
    return { ...result, date: dayKey(date), rows, dryRun: effectiveDryRun, submitEnabled: Boolean(config.submit?.enabled) }
  }, { headless })
}

// --- scheduled path -------------------------------------------------------

function planSummary(rows) {
  return rows.map((row) => `${row.project} ${row.percent}%`).join('，')
}

async function askCustomPlan(projects, config) {
  const count = await choose({
    title: TITLE,
    message: '要填几个项目？',
    options: ['1', '2', '3', '4', '5'],
  })
  if (!count) return null
  const rows = []
  let remaining = 100
  for (let index = 0; index < Number(count[0]); index += 1) {
    const picked = await choose({ title: TITLE, message: `第 ${index + 1} 个项目`, options: projects })
    if (!picked) return null
    const percentText = await prompt({
      title: TITLE,
      message: `「${picked[0]}」的投入百分比（剩余 ${remaining}%）`,
      defaultValue: String(index === Number(count[0]) - 1 ? remaining : Math.floor(remaining / 2)),
    })
    if (percentText === null) return null
    const percent = Number(percentText)
    if (!Number.isInteger(percent) || percent < 1 || percent > remaining) {
      await notify(TITLE, `百分比不合法：${percentText}`)
      return null
    }
    remaining -= percent
    const content = await prompt({ title: TITLE, message: '工作内容', defaultValue: config.defaultContent })
    if (content === null) return null
    rows.push({ project: picked[0], percent, content: content.length ? content : config.defaultContent })
  }
  return rows
}

export async function runScheduled({ now = new Date(), force = false, quietIfFiled = true } = {}) {
  const config = readConfig()
  const state = readState()
  const date = dayKey(now)

  if (!state.account) {
    await notify(TITLE, '还没有配置账号密码，定时任务无法执行')
    return { ok: false, reason: 'no-credentials' }
  }
  if (!config.defaultPlan?.length) {
    await notify(TITLE, '还没有配置默认填报组合，定时任务无法执行')
    return { ok: false, reason: 'no-default-plan' }
  }

  const plan = validatePlan(config.defaultPlan, config.defaultContent)
  const result = await withSession(async (page) => {
    const status = await filedOn(page, now)
    if (status.filed) return { ok: true, skipped: true, reason: describeFiled(date) }

    const answer = await ask({
      title: TITLE,
      message: `今天（${date}）还没填报。\n\n默认组合：${planSummary(plan)}\n\n按默认执行吗？`,
      buttons: ['跳过', '自定义', '按默认执行'],
      defaultButton: '按默认执行',
      timeoutSeconds: Math.max(1, Number(config.ask.timeoutMinutes || 10)) * 60,
    })

    if (answer === null) {
      if (config.ask.mode === 'auto') {
        await notify(TITLE, '等待超时，按配置自动按默认执行')
      } else {
        await notify(TITLE, `等待超时，今天（${date}）还没有填报`)
        return { ok: false, skipped: true, reason: '询问超时，未执行' }
      }
    } else if (answer === '跳过') {
      await notify(TITLE, `已跳过，今天（${date}）还没有填报`)
      return { ok: false, skipped: true, reason: '用户选择跳过' }
    } else if (answer === '自定义') {
      const custom = await askCustomPlan(state.projects?.length ? state.projects : plan.map((row) => row.project), config)
      if (!custom) {
        await notify(TITLE, '自定义填报已取消')
        return { ok: false, skipped: true, reason: '自定义被取消' }
      }
      const rows = validatePlan(custom, config.defaultContent)
      const filed = await fileDay({ page, date, plan: rows, submitIt: true, label: `scheduled-custom-${date}` })
      recordRun({ date, plan: rows, mode: 'scheduled-custom', ok: filed.ok, message: filed.message, screenshot: filed.screenshot })
      await notify(TITLE, filed.ok ? `已按自定义提交 ${date}（${planSummary(rows)}）` : `提交失败：${filed.message}`)
      return { ...filed, date, mode: 'custom' }
    }

    const safe = !config.submit?.enabled
    const filed = await fileDay({ page, date, plan, submitIt: !safe, label: `scheduled-${date}` })
    recordRun({ date, plan, mode: safe ? 'scheduled-dry-run' : 'scheduled', ok: filed.ok, message: filed.message, screenshot: filed.screenshot })
    await notify(
      TITLE,
      safe
        ? `已填好 ${date}（${planSummary(plan)}），安全模式未提交，请打开页面点提交`
        : filed.ok
          ? `已提交 ${date}（${planSummary(plan)}）`
          : `提交失败：${filed.message}`,
    )
    return { ...filed, date, mode: safe ? 'dry-run' : 'default' }
  })

  if (force) return result
  return result
}

export async function remindOnly(date = new Date()) {
  const config = readConfig()
  const key = dayKey(date)
  const local = findSubmission(key)
  if (local) return { ok: true, done: true }
  await notify(TITLE, `今天（${key}）还没有填报。打开 DSH 说「工时填报」即可处理。`, { sound: config.notify.sound })
  return { ok: true, reminded: true }
}

export { openApp, hhmm }

// One browser session for a whole backfill batch: opening a session per day
// would double the runtime and the login cost.
export async function runBackfillBatch({ dates, plan, dryRun, onProgress, headless = true }) {
  const config = readConfig()
  const rows = validatePlan(plan, config.defaultContent)
  const safe = dryRun === undefined ? !config.submit?.enabled : Boolean(dryRun) || !config.submit?.enabled

  return withSession(async (page) => {
    const results = []
    for (const [index, value] of dates.entries()) {
      onProgress?.({ index, total: dates.length, date: value })
      const date = new Date(`${value}T00:00:00`)
      const status = await filedOn(page, date).catch(() => ({ filed: false }))
      if (status.filed) {
        results.push({ date: value, ok: true, skipped: true, reason: describeFiled(value) })
        continue
      }
      const result = await fileDay({ page, date: value, plan: rows, submitIt: !safe, label: `backfill-${value}` })
      recordRun({ date: value, plan: rows, mode: safe ? 'dry-run' : 'backfill', ok: result.ok, message: result.message, screenshot: result.screenshot })
      results.push({ date: value, ...result })
    }
    return results
  }, { headless })
}

// Which days in the site's own window already carry a mark.
//
// Reading it needs a browser round trip (~15 s), so the last answer is kept and
// served while a fresh one is fetched: the page paints instantly and the next
// load is exact.
const DAY_CACHE_MS = 10 * 60_000

export function cachedDayStates() {
  const state = readState()
  const cache = state.daysCache
  if (!cache || !Array.isArray(cache.days)) return null
  return { days: cache.days, at: cache.at, stale: Date.now() - new Date(cache.at).getTime() > DAY_CACHE_MS }
}

export async function dayStates({ headless = true, force = false } = {}) {
  if (!force) {
    const cache = cachedDayStates()
    if (cache && !cache.stale) return cache.days
  }
  const config = readConfig()
  const days = listBackfillableDays(config.backfill?.days ?? 7)
  const rows = await withSession(async (page) => {
    const marks = await calendarMarks(page)
    return days.map((date) => {
      const day = Number(dayKey(date).slice(-2))
      const mark = marks[day] ?? {}
      return { date: dayKey(date), filed: Boolean(mark.dot), dot: mark.dot ?? null, disabled: Boolean(mark.disabled) }
    })
  }, { headless })
  updateState({ daysCache: { at: new Date().toISOString(), days: rows } })
  return rows
}
