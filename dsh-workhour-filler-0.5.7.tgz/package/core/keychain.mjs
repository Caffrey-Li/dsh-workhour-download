// Password storage, one API over two operating systems.
//
// macOS: the login keychain (`security`).
// Windows: DPAPI through PowerShell — the blob is encrypted for the current
// user on this machine, and another account cannot read it.
//
// Neither path ever writes the password in clear text to disk. The value does
// pass through a process argument or a pipe for a few milliseconds, which is
// the same caveat as `security -w`; a local attacker with the same account can
// read the password eventually either way.
import { execFile, spawn } from 'node:child_process'
import { promisify } from 'node:util'
import fs from 'node:fs'
import path from 'node:path'
import { home } from './paths.mjs'

const run = promisify(execFile)
const SERVICE = 'dsh-workhour'
const PS = ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command']

export function backend() {
  if (process.platform === 'darwin') return 'keychain'
  if (process.platform === 'win32') return 'dpapi'
  return 'none'
}

export function available() {
  return backend() !== 'none'
}

function vaultFile() {
  return path.join(home(), 'credentials.json')
}

function readVault() {
  try {
    return JSON.parse(fs.readFileSync(vaultFile(), 'utf8'))
  } catch {
    return {}
  }
}

function writeVault(value) {
  fs.mkdirSync(path.dirname(vaultFile()), { recursive: true, mode: 0o700 })
  const tmp = `${vaultFile()}.${process.pid}.tmp`
  fs.writeFileSync(tmp, JSON.stringify(value, null, 2), { mode: 0o600 })
  fs.renameSync(tmp, vaultFile())
}

// Feeds a value on stdin so it never shows up in a process listing.
function powershellWithInput(script, input) {
  return new Promise((resolve, reject) => {
    const child = spawn('powershell.exe', [...PS, script], { windowsHide: true })
    let stdout = ''
    let stderr = ''
    child.stdout.on('data', (chunk) => { stdout += chunk })
    child.stderr.on('data', (chunk) => { stderr += chunk })
    child.on('error', reject)
    child.on('close', (code) => {
      if (code === 0) resolve(stdout)
      else reject(new Error(stderr.trim() || `powershell exited with ${code}`))
    })
    child.stdin.end(String(input ?? ''), 'utf8')
  })
}

// --- macOS keychain -------------------------------------------------------

// `security -w` hex-encodes a value that is not plain ASCII, which silently
// corrupts a non-English password. The stored value is therefore a small JSON
// envelope with base64 inside; a legacy raw value still reads back unchanged.
function wrap(value) {
  return JSON.stringify({ v: 1, b64: Buffer.from(value, 'utf8').toString('base64') })
}

function unwrap(raw) {
  const value = raw.replace(/\n$/, '')
  try {
    const parsed = JSON.parse(value)
    if (parsed && parsed.v === 1 && typeof parsed.b64 === 'string') {
      return Buffer.from(parsed.b64, 'base64').toString('utf8')
    }
  } catch {
    // a plain value written before the envelope existed
  }
  return value
}

async function macGet(account) {
  try {
    const { stdout } = await run('security', ['find-generic-password', '-s', SERVICE, '-a', account, '-w'])
    return unwrap(stdout)
  } catch {
    return null
  }
}

// --- Windows DPAPI --------------------------------------------------------

const DPAPI_ENCRYPT = `
$ErrorActionPreference = 'Stop'
$plain = [Console]::In.ReadToEnd()
$secure = ConvertTo-SecureString -String $plain -AsPlainText -Force
[Console]::Out.Write((ConvertFrom-SecureString -SecureString $secure))
`

const DPAPI_DECRYPT = `
$ErrorActionPreference = 'Stop'
$hex = [Console]::In.ReadToEnd()
$secure = ConvertTo-SecureString -String $hex.Trim()
$bstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
try { [Console]::Out.Write([Runtime.InteropServices.Marshal]::PtrToStringBSTR($bstr)) }
finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr) }
`

async function winGet(account) {
  const blob = readVault()[account]
  if (typeof blob !== 'string' || !blob) return null
  try {
    const out = await powershellWithInput(DPAPI_DECRYPT, blob)
    return out.length ? out : null
  } catch {
    return null
  }
}

// --- public API -----------------------------------------------------------

export async function setPassword(account, password) {
  const kind = backend()
  if (kind === 'keychain') {
    await run('security', ['add-generic-password', '-U', '-s', SERVICE, '-a', account, '-w', wrap(password)])
    return
  }
  if (kind === 'dpapi') {
    const blob = await powershellWithInput(DPAPI_ENCRYPT, password)
    const vault = readVault()
    vault[account] = blob.trim()
    writeVault(vault)
    return
  }
  throw new Error('当前系统没有可用的密码存储（需要 macOS 钥匙串或 Windows DPAPI）')
}

export async function getPassword(account) {
  const kind = backend()
  if (kind === 'keychain') return macGet(account)
  if (kind === 'dpapi') return winGet(account)
  return null
}

export async function hasPassword(account) {
  return (await getPassword(account)) !== null
}

export async function deletePassword(account) {
  const kind = backend()
  if (kind === 'keychain') {
    try {
      await run('security', ['delete-generic-password', '-s', SERVICE, '-a', account])
    } catch {
      // already gone
    }
    return
  }
  if (kind === 'dpapi') {
    const vault = readVault()
    delete vault[account]
    writeVault(vault)
  }
}
