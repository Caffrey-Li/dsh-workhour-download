// One JSON file is the source of truth for settings, so the settings page, the
// agent tools and the launchd runner always agree. The DSH profile's cordis
// config only decides whether the plugin is mounted.
import { readJson, writeJson } from './store.mjs'
import { files } from './paths.mjs'

export const DEFAULT_CONTENT = '项目投入'

export const DEFAULTS = {
  version: 1,
  defaultPlan: [],
  defaultContent: DEFAULT_CONTENT,
  schedule: {
    enabled: false,
    kind: 'weekday', // weekday | daily
    time: '09:05',
  },
  ask: {
    mode: 'ask', // ask | auto
    timeoutMinutes: 10,
    remindEveryMinutes: 30,
  },
  notify: {
    macos: true,
    sound: false,
  },
  backfill: {
    scope: 'currentMonth',
    days: 7,
  },
  retry: {
    times: 1,
  },
  // Safety first: until this is turned on deliberately, every run stops after
  // the form is filled and never clicks 提交.
  submit: {
    enabled: false,
  },
  browser: {
    headless: true,
    slowMo: 0,
  },
}

function merge(base, patch) {
  const out = { ...base }
  for (const [key, value] of Object.entries(patch ?? {})) {
    if (value && typeof value === 'object' && !Array.isArray(value) && base[key] && typeof base[key] === 'object') {
      out[key] = merge(base[key], value)
    } else if (value !== undefined) {
      out[key] = value
    }
  }
  return out
}

export function readConfig() {
  return merge(DEFAULTS, readJson(files.config(), {}))
}

export function writeConfig(patch) {
  const next = merge(readConfig(), patch)
  writeJson(files.config(), next)
  return next
}

export function validatePlan(plan, content) {
  if (!Array.isArray(plan) || plan.length === 0) throw new Error('默认填报组合至少要有 1 个项目')
  const seen = new Set()
  let total = 0
  const rows = plan.map((row, index) => {
    const project = String(row.project ?? '').trim()
    if (!project) throw new Error(`第 ${index + 1} 行没有项目名`)
    if (seen.has(project)) throw new Error(`项目「${project}」重复了`)
    seen.add(project)
    const percent = Number(row.percent)
    if (!Number.isInteger(percent) || percent < 1 || percent > 100) {
      throw new Error(`第 ${index + 1} 行占比必须是 1~100 的整数`)
    }
    total += percent
    const text = row.content === undefined ? content ?? DEFAULT_CONTENT : String(row.content)
    if (!text.length) throw new Error(`第 ${index + 1} 行工作内容不能为空`)
    if (text.length > 2000) throw new Error(`第 ${index + 1} 行工作内容超过 2000 字`)
    return { project, percent, content: text }
  })
  if (total !== 100) throw new Error(`占比合计必须等于 100，当前是 ${total}`)
  return rows
}
