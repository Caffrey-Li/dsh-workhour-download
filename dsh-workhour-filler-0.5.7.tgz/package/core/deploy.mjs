// The scheduled job must not depend on where DSH happened to install the
// plugin: pnpm keeps packages in a content-addressed store, and a profile
// reinstall moves them. A launchd job therefore runs a copy under
// ~/Library/Application Support, refreshed every time the schedule is installed.
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'

const COPY = ['bin', 'core', 'agents', 'package.json']

// The scheduled job must not depend on where DSH installed the plugin, so it
// runs a copy in the user's application-data folder on whichever system this is.
export function deployedRoot() {
  if (process.platform === 'win32') {
    const base = process.env.LOCALAPPDATA ?? path.join(os.homedir(), 'AppData', 'Local')
    return path.join(base, 'dsh-workhour', 'app')
  }
  if (process.platform === 'darwin') {
    return path.join(os.homedir(), 'Library', 'Application Support', 'dsh-workhour', 'app')
  }
  const base = process.env.XDG_DATA_HOME ?? path.join(os.homedir(), '.local', 'share')
  return path.join(base, 'dsh-workhour', 'app')
}

export function deploy(root) {
  const target = deployedRoot()
  fs.rmSync(target, { recursive: true, force: true })
  fs.mkdirSync(target, { recursive: true, mode: 0o755 })

  for (const entry of COPY) {
    const from = path.join(root, entry)
    if (!fs.existsSync(from)) continue
    fs.cpSync(from, path.join(target, entry), { recursive: true })
  }

  // Dependencies are copied too (about 13 MB): pnpm's relative links inside
  // node_modules keep pointing at the copied store, so the deployed job does
  // not care what happens to the plugin's own install later.
  const modules = path.join(root, 'node_modules')
  if (fs.existsSync(modules)) {
    try {
      fs.cpSync(modules, path.join(target, 'node_modules'), { recursive: true, verbatimSymlinks: true })
    } catch {
      // Windows junctions cannot be copied verbatim; dereference them instead.
      fs.rmSync(path.join(target, 'node_modules'), { recursive: true, force: true })
      fs.cpSync(modules, path.join(target, 'node_modules'), { recursive: true, dereference: true })
    }
  }

  return target
}
