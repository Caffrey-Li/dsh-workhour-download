// Small JSON / JSONL helpers. Everything is written atomically so a crash in a
// scheduled run cannot leave a half-written state file behind.
import fs from 'node:fs'
import path from 'node:path'
import { files } from './paths.mjs'

export function readJson(file, fallback) {
  try {
    return JSON.parse(fs.readFileSync(file, 'utf8'))
  } catch {
    return fallback
  }
}

export function writeJson(file, value) {
  fs.mkdirSync(path.dirname(file), { recursive: true, mode: 0o700 })
  const tmp = `${file}.${process.pid}.tmp`
  fs.writeFileSync(tmp, JSON.stringify(value, null, 2), { mode: 0o600 })
  fs.renameSync(tmp, file)
}

export function appendJsonl(file, entry) {
  fs.mkdirSync(path.dirname(file), { recursive: true, mode: 0o700 })
  fs.appendFileSync(file, `${JSON.stringify(entry)}\n`, { mode: 0o600 })
}

export function readJsonl(file) {
  let text = ''
  try {
    text = fs.readFileSync(file, 'utf8')
  } catch {
    return []
  }
  const out = []
  for (const line of text.split('\n')) {
    if (!line.trim()) continue
    try {
      out.push(JSON.parse(line))
    } catch {
      // skip a corrupted trailing line
    }
  }
  return out
}

// --- state ---------------------------------------------------------------

const DEFAULT_STATE = {
  version: 1,
  account: null,
  projects: [],
  projectsSyncedAt: null,
  lastRun: null,
  lastScheduleInstall: null,
}

export function readState() {
  return { ...DEFAULT_STATE, ...readJson(files.state(), {}) }
}

export function updateState(patch) {
  const next = { ...readState(), ...patch }
  writeJson(files.state(), next)
  return next
}

// --- history -------------------------------------------------------------

export function history(limit = 200) {
  const all = readJsonl(files.history())
  return limit ? all.slice(-limit) : all
}

export function recordRun(entry) {
  appendJsonl(files.history(), { at: new Date().toISOString(), ...entry })
}

export function findSubmission(date) {
  return history(0)
    .reverse()
    .find((entry) => entry.date === date && entry.ok === true && entry.mode !== 'dry-run')
}
