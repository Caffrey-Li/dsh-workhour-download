// Calendar rules: which days a scheduled run should fire on, and whether today
// already has a filing.
//
// v1 treats a workday as Monday to Friday. Public holidays and make-up workdays
// are a v1.1 item (they need a maintained holiday calendar).

export function today() {
  return new Date()
}

export function dayKey(date = new Date()) {
  const pad = (n) => String(n).padStart(2, '0')
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`
}

export function isWorkday(date = new Date()) {
  const day = date.getDay()
  return day >= 1 && day <= 5
}

export function parseClock(value) {
  const match = /^(\d{1,2}):(\d{2})$/.exec(String(value ?? '').trim())
  if (!match) throw new Error(`时间格式应为 HH:mm，收到「${value}」`)
  const hour = Number(match[1])
  const minute = Number(match[2])
  if (hour > 23 || minute > 59) throw new Error(`时间不合法：${value}`)
  return { hour, minute }
}

export function minutesNow(date = new Date()) {
  return date.getHours() * 60 + date.getMinutes()
}

export function shouldFire(config, date = new Date()) {
  if (!config.schedule?.enabled) return { fire: false, reason: '定时任务未开启' }
  if (config.schedule.kind === 'weekday' && !isWorkday(date)) {
    return { fire: false, reason: '今天不是工作日' }
  }
  const { hour, minute } = parseClock(config.schedule.time)
  const target = hour * 60 + minute
  if (minutesNow(date) < target) return { fire: false, reason: `未到 ${config.schedule.time}` }
  return { fire: true }
}

export function isCurrentMonth(date) {
  const now = new Date()
  return date.getFullYear() === now.getFullYear() && date.getMonth() === now.getMonth()
}

// The site itself only enables the last few days on its calendar (seven at the
// time of writing), so both limits are enforced here instead of failing later
// on a disabled cell.
export function backfillWindow(days = 7, now = new Date()) {
  const end = new Date(now.getFullYear(), now.getMonth(), now.getDate())
  const start = new Date(end)
  start.setDate(start.getDate() - (Math.max(1, days) - 1))
  const boundedStart = start.getMonth() === end.getMonth() ? start : new Date(end.getFullYear(), end.getMonth(), 1)
  return { start: boundedStart, end }
}

export function assertBackfillable(date, days = 7, now = new Date()) {
  if (date > now) throw new Error('不能填报未来的日期')
  if (!isCurrentMonth(date)) throw new Error('补填只支持当月日期')
  const { start } = backfillWindow(days, now)
  const day = new Date(date.getFullYear(), date.getMonth(), date.getDate())
  if (day < start) {
    throw new Error(`系统只允许补最近 ${days} 天（最早 ${start.getFullYear()}-${String(start.getMonth() + 1).padStart(2, '0')}-${String(start.getDate()).padStart(2, '0')}）`)
  }
  return date
}

export function daysInCurrentMonthLeft() {
  const now = new Date()
  const out = []
  for (let day = now.getDate(); day <= new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate(); day += 1) {
    out.push(new Date(now.getFullYear(), now.getMonth(), day))
  }
  return out
}

export function listBackfillableDays(days = 7, now = new Date()) {
  const { start, end } = backfillWindow(days, now)
  const out = []
  for (let date = new Date(start); date <= end; date.setDate(date.getDate() + 1)) {
    out.push(new Date(date))
  }
  return out
}
