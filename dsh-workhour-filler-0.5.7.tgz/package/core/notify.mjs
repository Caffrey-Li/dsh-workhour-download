// System surfaces for the unattended path: a notification for the outcome and
// a dialog for the "run the default plan?" question.
//
// macOS uses osascript. Windows uses PowerShell + WinForms; values travel on
// stdin as JSON so no quoting can break the script.
import { execFile, spawn } from 'node:child_process'
import { promisify } from 'node:util'
import fs from 'node:fs'
import path from 'node:path'
import { home } from './paths.mjs'

const run = promisify(execFile)
const PS = ['-NoProfile', '-NonInteractive', '-STA', '-ExecutionPolicy', 'Bypass', '-Command']

// An Electron host can start with a PATH that lacks System32, so the absolute
// location is tried before the bare name.
let resolvedPowershell
export function powershellPath() {
  if (resolvedPowershell !== undefined) return resolvedPowershell
  const candidates = [
    process.env.SystemRoot ? path.join(process.env.SystemRoot, 'System32', 'WindowsPowerShell', 'v1.0', 'powershell.exe') : '',
    'C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe',
    'powershell.exe',
  ].filter(Boolean)
  resolvedPowershell = candidates.find((candidate) => candidate === 'powershell.exe' || fs.existsSync(candidate)) ?? 'powershell.exe'
  return resolvedPowershell
}
const APP = 'DeepSeek Harness'

const isWindows = () => process.platform === 'win32'

// Prefix for every AppleScript dialog: try to raise the window, but never let a
// denied Automation permission stop the dialog itself.
const RAISE = `try\n  tell application "System Events" to activate\nend try\n`


function noteLog(title, message) {
  try {
    const dir = path.join(home(), 'logs')
    fs.mkdirSync(dir, { recursive: true })
    fs.appendFileSync(path.join(dir, 'notifications.log'), `${new Date().toISOString()} ${title} | ${message}\n`)
  } catch {
    // a lost log line must not break the run
  }
}

function powershell(script, payload) {
  return new Promise((resolve) => {
    const child = spawn(powershellPath(), [...PS, script], { windowsHide: true })
    let out = ''
    child.stdout.on('data', (chunk) => { out += chunk })
    child.on('error', () => resolve(''))
    child.on('close', () => resolve(out))
    child.stdin.end(JSON.stringify(payload ?? {}), 'utf8')
  })
}

export async function powershellWorks() {
  if (!isWindows()) return { ok: true, path: null }
  const out = await powershell(`Write-Output ('ok ' + $PSVersionTable.PSVersion.ToString())`, {})
  return { ok: out.startsWith('ok'), path: powershellPath(), output: out.trim().slice(0, 80) }
}

const PS_DIALOG = `
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
$cfg = [Console]::In.ReadToEnd() | ConvertFrom-Json
$form = New-Object System.Windows.Forms.Form
$form.Text = $cfg.title
$form.ClientSize = New-Object System.Drawing.Size(520, 250)
$form.StartPosition = 'CenterScreen'
$form.FormBorderStyle = 'FixedDialog'
$form.MaximizeBox = $false
$form.MinimizeBox = $false
$form.TopMost = $true
$label = New-Object System.Windows.Forms.Label
$label.Text = $cfg.message
$label.AutoSize = $false
$label.Size = New-Object System.Drawing.Size(480, 150)
$label.Location = New-Object System.Drawing.Point(20, 18)
$form.Controls.Add($label)
$script:answer = ''
$x = 20
foreach ($b in $cfg.buttons) {
  $btn = New-Object System.Windows.Forms.Button
  $btn.Text = [string]$b
  $btn.Tag = [string]$b
  $w = [Math]::Max(96, ([string]$b).Length * 14 + 28)
  $btn.Size = New-Object System.Drawing.Size($w, 32)
  $btn.Location = New-Object System.Drawing.Point($x, 190)
  $x += $w + 10
  $btn.Add_Click({ $script:answer = [string]$this.Tag; $form.Close() })
  $form.Controls.Add($btn)
}
if ([int]$cfg.timeoutSeconds -gt 0) {
  $timer = New-Object System.Windows.Forms.Timer
  $timer.Interval = [int]$cfg.timeoutSeconds * 1000
  $timer.Add_Tick({ $form.Close() })
  $timer.Start()
}
[void]$form.ShowDialog()
[Console]::Out.Write($script:answer)
`

const PS_INPUT = `
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
$cfg = [Console]::In.ReadToEnd() | ConvertFrom-Json
$form = New-Object System.Windows.Forms.Form
$form.Text = $cfg.title
$form.ClientSize = New-Object System.Drawing.Size(480, 190)
$form.StartPosition = 'CenterScreen'
$form.FormBorderStyle = 'FixedDialog'
$form.MaximizeBox = $false
$form.MinimizeBox = $false
$form.TopMost = $true
$label = New-Object System.Windows.Forms.Label
$label.Text = $cfg.message
$label.AutoSize = $false
$label.Size = New-Object System.Drawing.Size(440, 60)
$label.Location = New-Object System.Drawing.Point(20, 16)
$form.Controls.Add($label)
$box = New-Object System.Windows.Forms.TextBox
$box.Text = [string]$cfg.value
$box.Size = New-Object System.Drawing.Size(440, 26)
$box.Location = New-Object System.Drawing.Point(20, 82)
if ($cfg.hidden) { $box.UseSystemPasswordChar = $true }
$form.Controls.Add($box)
$ok = New-Object System.Windows.Forms.Button
$ok.Text = '确定'
$ok.DialogResult = [System.Windows.Forms.DialogResult]::OK
$ok.Location = New-Object System.Drawing.Point(280, 130)
$cancel = New-Object System.Windows.Forms.Button
$cancel.Text = '取消'
$cancel.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
$cancel.Location = New-Object System.Drawing.Point(380, 130)
$form.Controls.Add($ok)
$form.Controls.Add($cancel)
$form.AcceptButton = $ok
$form.CancelButton = $cancel
if ($form.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) { [Console]::Out.Write($box.Text) } else { [Console]::Out.Write('__CANCELLED__') }
`

const PS_CHOOSE = `
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
$cfg = [Console]::In.ReadToEnd() | ConvertFrom-Json
$form = New-Object System.Windows.Forms.Form
$form.Text = $cfg.title
$form.ClientSize = New-Object System.Drawing.Size(480, 320)
$form.StartPosition = 'CenterScreen'
$form.FormBorderStyle = 'FixedDialog'
$form.MaximizeBox = $false
$form.MinimizeBox = $false
$form.TopMost = $true
$label = New-Object System.Windows.Forms.Label
$label.Text = $cfg.message
$label.AutoSize = $false
$label.Size = New-Object System.Drawing.Size(440, 40)
$label.Location = New-Object System.Drawing.Point(20, 12)
$form.Controls.Add($label)
$list = New-Object System.Windows.Forms.ListBox
$list.Size = New-Object System.Drawing.Size(440, 190)
$list.Location = New-Object System.Drawing.Point(20, 56)
$list.SelectionMode = if ($cfg.multiple) { 'MultiExtended' } else { 'One' }
foreach ($o in $cfg.options) { [void]$list.Items.Add([string]$o) }
$form.Controls.Add($list)
$ok = New-Object System.Windows.Forms.Button
$ok.Text = '确定'
$ok.Location = New-Object System.Drawing.Point(280, 262)
$ok.Add_Click({ $form.Close() })
$cancel = New-Object System.Windows.Forms.Button
$cancel.Text = '取消'
$cancel.Location = New-Object System.Drawing.Point(380, 262)
$cancel.Add_Click({ $script:cancelled = $true; $form.Close() })
$script:cancelled = $false
$form.Controls.Add($ok)
$form.Controls.Add($cancel)
[void]$form.ShowDialog()
if ($script:cancelled) { [Console]::Out.Write('__CANCELLED__') }
else { [Console]::Out.Write(($list.SelectedItems | ForEach-Object { [string]$_ }) -join "\`n") }
`

const PS_TOAST = `
$ErrorActionPreference = 'Stop'
$cfg = [Console]::In.ReadToEnd() | ConvertFrom-Json
try {
  [Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType = WindowsRuntime] | Out-Null
  [Windows.Data.Xml.Dom.XmlDocument, Windows.Data.Xml.Dom.XmlDocument, ContentType = WindowsRuntime] | Out-Null
  $template = [Windows.UI.Notifications.ToastNotificationManager]::GetTemplateContent([Windows.UI.Notifications.ToastTemplateType]::ToastText02)
  $texts = $template.GetElementsByTagName('text')
  $texts.Item(0).AppendChild($template.CreateTextNode([string]$cfg.title)) | Out-Null
  $texts.Item(1).AppendChild($template.CreateTextNode([string]$cfg.message)) | Out-Null
  $toast = [Windows.UI.Notifications.ToastNotification]::new($template)
  [Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier('DSH 工时填报').Show($toast)
  [Console]::Out.Write('ok')
} catch { [Console]::Out.Write('failed') }
`

// --- public API -----------------------------------------------------------

export async function notify(title, message, { sound = false } = {}) {
  noteLog(title, message)
  if (process.platform === 'darwin') {
    const script = `display notification ${JSON.stringify(message)} with title ${JSON.stringify(title)}${sound ? ' sound name "Ping"' : ''}`
    await run('osascript', ['-e', script]).catch(() => {})
    return
  }
  if (isWindows()) {
    await powershell(PS_TOAST, { title, message })
  }
}

// Returns the chosen button label, or null when the dialog timed out or was
// closed without a choice.
export async function ask({ title, message, buttons = ['取消', '确定'], defaultButton, timeoutSeconds = 0 }) {
  if (process.platform === 'darwin') {
    const buttonList = `{${buttons.map((label) => JSON.stringify(label)).join(', ')}}`
    const parts = [
      `display dialog ${JSON.stringify(message)}`,
      `buttons ${buttonList}`,
      defaultButton ? `default button ${JSON.stringify(defaultButton)}` : '',
      timeoutSeconds > 0 ? `giving up after ${timeoutSeconds}` : '',
      `with title ${JSON.stringify(title)}`,
    ].filter(Boolean)
    try {
      const { stdout } = await run('osascript', ['-e', RAISE + parts.join('\n')])
      if (stdout.includes('gave up:true')) return null
      return stdout.match(/button returned:([^,]+)/)?.[1] ?? null
    } catch {
      return null
    }
  }
  if (isWindows()) {
    const out = await powershell(PS_DIALOG, { title, message, buttons, defaultButton: defaultButton ?? null, timeoutSeconds })
    const answer = out.trim()
    return answer.length ? answer : null
  }
  return null
}

export async function choose({ title, message, options, multiple = false }) {
  if (process.platform === 'darwin') {
    const list = `{${options.map((option) => JSON.stringify(option)).join(', ')}}`
    const script = [
      `set picked to choose from list ${list} with prompt ${JSON.stringify(message)}`,
      multiple ? 'with multiple selections allowed' : '',
      `with title ${JSON.stringify(title)}`,
      'OK button name "确定" cancel button name "取消"',
      'if picked is false then',
      'return ""',
      'end if',
      'set AppleScript\'s text item delimiters to "\\n"',
      'return picked as text',
    ].join('\n')
    try {
      const { stdout } = await run('osascript', ['-e', RAISE + script])
      const value = stdout.trim()
      return value ? value.split('\n') : null
    } catch {
      return null
    }
  }
  if (isWindows()) {
    const out = await powershell(PS_CHOOSE, { title, message, options, multiple })
    if (out.includes('__CANCELLED__')) return null
    const lines = out.split(/\r?\n/).map((line) => line.trim()).filter(Boolean)
    return lines.length ? lines : null
  }
  return null
}

export async function prompt({ title, message, defaultValue = '', hidden = false }) {
  if (process.platform === 'darwin') {
    const parts = [
      `display dialog ${JSON.stringify(message)}`,
      `default answer ${JSON.stringify(defaultValue)}`,
      hidden ? 'with hidden answer' : '',
      'buttons {"取消","确定"} default button "确定"',
      `with title ${JSON.stringify(title)}`,
    ].filter(Boolean)
    try {
      const { stdout } = await run('osascript', ['-e', RAISE + parts.join('\n')])
      return stdout.match(/text returned:([\s\S]*?)(?:, button returned|$)/)?.[1] ?? null
    } catch {
      return null
    }
  }
  if (isWindows()) {
    const out = await powershell(PS_INPUT, { title, message, value: defaultValue, hidden })
    if (out.includes('__CANCELLED__')) return null
    return out.replace(/\r?\n$/, '')
  }
  return null
}

export async function openApp() {
  if (process.platform === 'darwin') {
    await run('open', ['-a', APP]).catch(() => {})
    return
  }
  if (isWindows()) {
    await run('cmd', ['/c', 'start', '', APP]).catch(() => {})
  }
}
