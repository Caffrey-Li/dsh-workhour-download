// One persistent, invisible Chrome per machine.
//
// The browser runs from the user's own Chrome binary but with a dedicated
// profile directory, so the user's open Chrome windows, tabs and sessions are
// never touched and no `--remote-debugging-port` restart is required.
import fs from 'node:fs'
import path from 'node:path'
import { ensureDirs, files, home } from './paths.mjs'

// Loaded lazily: a folder install without node_modules must still activate the
// plugin, so the settings page can explain what is missing instead of the whole
// bundle failing to import.
let chromium
async function loadPlaywright() {
  if (chromium) return chromium
  try {
    ;({ chromium } = await import('playwright-core'))
    return chromium
  } catch (error) {
    throw new Error(
      `缺少 playwright-core：${error?.message ?? error}\n` +
        'Windows 用户请重新下载 zip 安装包（里面已带 node_modules），解压后整个文件夹一起用，不要删掉其中的 node_modules。',
    )
  }
}

const CANDIDATES = [
  process.env.CHROME_PATH,
  '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
  '/Applications/Chromium.app/Contents/MacOS/Chromium',
  '/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge',
  '/Applications/Brave Browser.app/Contents/MacOS/Brave Browser',
  'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
  'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
  '/usr/bin/google-chrome',
  '/usr/bin/chromium',
]

export function findChrome() {
  for (const candidate of CANDIDATES) {
    if (candidate && fs.existsSync(candidate)) return candidate
  }
  throw new Error('没有找到 Chrome。请安装 Google Chrome，或设置 CHROME_PATH 指向浏览器可执行文件。')
}

// The internal site is a mobile-first Vant page; a phone-sized viewport keeps
// every control on the layout the design was made for.
export const VIEWPORT = { width: 430, height: 932 }

// One Chrome at a time: a second launch on the same profile fails with a lock
// error, which used to surface as an empty day list in the settings page.
const LOCK_STALE_MS = 3 * 60_000
const LOCK_WAIT_MS = 90_000

function lockFile() {
  return path.join(home(), 'browser.lock')
}

async function acquireLock() {
  const file = lockFile()
  const deadline = Date.now() + LOCK_WAIT_MS
  for (;;) {
    try {
      const fd = fs.openSync(file, 'wx')
      fs.writeSync(fd, JSON.stringify({ pid: process.pid, at: Date.now() }))
      fs.closeSync(fd)
      return
    } catch {
      try {
        const info = JSON.parse(fs.readFileSync(file, 'utf8'))
        const age = Date.now() - Number(info.at ?? 0)
        const alive = info.pid && (() => {
          try {
            process.kill(info.pid, 0)
            return true
          } catch {
            return false
          }
        })()
        if (age > LOCK_STALE_MS || !alive) {
          fs.unlinkSync(file)
          continue
        }
      } catch {
        try {
          fs.unlinkSync(file)
        } catch {
          // raced with another cleaner
        }
        continue
      }
      if (Date.now() > deadline) throw new Error('另一个填报任务正在运行（浏览器占用中），请稍后再试')
      await new Promise((resolve) => setTimeout(resolve, 500))
    }
  }
}

function releaseLock() {
  try {
    fs.unlinkSync(lockFile())
  } catch {
    // already gone
  }
}

export async function open({ headless = true, slowMo = 0 } = {}) {
  ensureDirs()
  await acquireLock()
  const chromium = await loadPlaywright()
  const context = await chromium.launchPersistentContext(files.chromeProfile(), {
    executablePath: findChrome(),
    headless,
    slowMo,
    viewport: VIEWPORT,
    deviceScaleFactor: 2,
    locale: 'zh-CN',
    timezoneId: 'Asia/Shanghai',
    args: [
      '--no-first-run',
      '--no-default-browser-check',
      '--no-sandbox',
      '--disable-blink-features=AutomationControlled',
      '--hide-crash-restore-bubble',
    ],
  })
  const page = context.pages()[0] ?? (await context.newPage())
  page.setDefaultTimeout(20_000)
  return {
    context,
    page,
    async close() {
      try {
        await context.close()
      } finally {
        releaseLock()
      }
    },
  }
}

export async function screenshot(page, name) {
  ensureDirs()
  const file = path.join(files.screenshots(), `${name}.png`)
  await page.screenshot({ path: file, fullPage: false })
  return file
}
