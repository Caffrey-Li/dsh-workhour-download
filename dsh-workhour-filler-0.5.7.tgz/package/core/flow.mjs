// The filing flow itself: sign in, pick a date, fill one or more project rows,
// submit, and read back what the site kept.
//
// Selectors come from the rendered Vant component tree (captured under
// ~/.dsh-workhour/explore/). They are deliberately structural — name attributes
// and Vant class names — instead of positional, because the site adds and
// removes cards without renaming anything.
import fs from 'node:fs'
import path from 'node:path'
import { files, isoDay, hhmm, timestamp } from './paths.mjs'
import { login, go, settle, capture, ROUTES, readToast } from './site.mjs'

const PROJECT_CARD = '.van-card'
const CELL = '.van-cell--clickable'

export async function ensureSignedIn(page, creds) {
  const result = await login(page, creds)
  if (!result.ok) throw new Error(`登录失败：${result.reason}`)
  return result
}

// --- projects -------------------------------------------------------------

export async function syncProjects(page) {
  await go(page, ROUTES.addDay)
  await settle(page, 1000)
  await openProjectPicker(page, 0)
  const projects = await page.locator('.van-picker-column__item .van-ellipsis').allInnerTexts()
  await cancelPicker(page)
  const unique = [...new Set(projects.map((name) => name.trim()).filter(Boolean))]
  if (!unique.length) throw new Error('项目列表为空：项目选择器里没有读到任何项目')
  return unique
}

function projectCard(page, index) {
  return page.locator(PROJECT_CARD, { hasText: '项目信息' }).nth(index)
}

async function openProjectPicker(page, index) {
  await projectCard(page, index).locator('input[name="projectName"]').click()
  await page.waitForSelector('.van-picker__confirm', { state: 'visible' })
  await settle(page, 400)
}

async function chooseProject(page, name) {
  const item = page.locator('.van-picker-column__item', { hasText: name }).first()
  if (!(await item.count())) throw new Error(`项目选择器里没有「${name}」`)
  await item.click()
  await settle(page, 300)
  await page.locator('.van-picker__confirm').click()
  await settle(page, 500)
}

async function cancelPicker(page) {
  await page.locator('.van-picker__cancel').click().catch(() => {})
  await settle(page, 300)
}

// --- date -----------------------------------------------------------------

export async function openCalendar(page) {
  await page.locator(CELL, { hasText: '填报日期' }).first().click()
  await page.waitForSelector('.van-calendar__days', { state: 'visible' })
  await settle(page, 500)
}

// The grid also renders the tail of the previous month and the head of the
// next one, so a bare day number is ambiguous. Day 1 is the cell carrying an
// inline margin-left; every later day follows it in DOM order.
async function dayOneOffset(page) {
  return page.evaluate(() => {
    const cells = [...document.querySelectorAll('.van-calendar__month .van-calendar__day')]
    const index = cells.findIndex((cell) => cell.style && cell.style.marginLeft)
    return index === -1 ? 0 : index
  })
}

export async function pickDay(page, date) {
  const target = date instanceof Date ? date : new Date(`${date}T00:00:00`)
  const day = target.getDate()
  const offset = await dayOneOffset(page)
  const cell = page.locator('.van-calendar__month .van-calendar__day').nth(offset + day - 1)
  if (!(await cell.count())) throw new Error(`日历里没有 ${day} 号`)
  if ((await cell.getAttribute('class') ?? '').includes('disabled')) {
    throw new Error(`日历里的 ${day} 号不可选（可能超出可填报范围）`)
  }
  await cell.click()
  await settle(page, 600)
  const value = await page.locator('input[name="reportingDateTime"]').inputValue()
  if (!value.includes(`${target.getMonth() + 1}`) || !value.includes(String(day))) {
    // Vant writes yyyy/mm/dd into the field; a mismatch means the click missed.
    throw new Error(`填报日期没有写入（字段值为「${value}」）`)
  }
  return value
}

// Days the site already shows a coloured dot for: `approved` means the day was
// filed and approved, any other dot class means filed but still in process.
export async function calendarMarks(page) {
  await openCalendar(page)
  const marks = await page.evaluate(() => {
    const cells = [...document.querySelectorAll('.van-calendar__month .van-calendar__day')]
    const start = cells.findIndex((cell) => cell.style && cell.style.marginLeft)
    const out = {}
    for (const cell of cells.slice(start === -1 ? 0 : start)) {
      const day = parseInt(cell.textContent, 10)
      if (!Number.isFinite(day) || out[day] !== undefined) continue
      const dot = cell.querySelector('.status-box .dot')
      out[day] = {
        disabled: cell.classList.contains('van-calendar__day--disabled'),
        dot: dot ? [...dot.classList].filter((name) => name !== 'dot').join(' ') || 'filed' : null,
      }
      if (day >= 31) break
    }
    return out
  })
  await page.locator('.van-popup__close-icon').click().catch(() => {})
  await settle(page, 400)
  return marks
}

// --- rows -----------------------------------------------------------------

export function validatePlan(plan) {
  if (!Array.isArray(plan) || plan.length === 0) throw new Error('至少需要一个项目')
  const seen = new Set()
  let total = 0
  for (const [index, row] of plan.entries()) {
    const name = String(row.project ?? '').trim()
    if (!name) throw new Error(`第 ${index + 1} 行没有选择项目`)
    if (seen.has(name)) throw new Error(`项目「${name}」重复了，同一个项目只能填一次`)
    seen.add(name)
    const percent = Number(row.percent)
    if (!Number.isInteger(percent) || percent < 1 || percent > 100) {
      throw new Error(`第 ${index + 1} 行的投入百分比必须是 1~100 的整数`)
    }
    total += percent
    if (String(row.content ?? '').trim() === '' && !String(row.content ?? '').length) {
      throw new Error(`第 ${index + 1} 行的工作内容不能为空（可以填空格）`)
    }
    if (String(row.content ?? '').length > 2000) throw new Error(`第 ${index + 1} 行的工作内容超过 2000 字`)
  }
  if (total !== 100) throw new Error(`所有项目投入百分比合计必须等于 100，当前为 ${total}`)
  return plan
}

async function ensureRowCount(page, count) {
  const current = await page.locator(PROJECT_CARD, { hasText: '项目信息' }).count()
  for (let index = current; index < count; index += 1) {
    await page.locator('button.add-btn').first().click()
    await settle(page, 500)
  }
  const after = await page.locator(PROJECT_CARD, { hasText: '项目信息' }).count()
  if (after < count) throw new Error(`点「添加更多」后只有 ${after} 个项目行，需要 ${count} 行`)
}

export async function fillPlan(page, plan) {
  validatePlan(plan)
  await ensureRowCount(page, plan.length)
  for (const [index, row] of plan.entries()) {
    const card = projectCard(page, index)
    await openProjectPicker(page, index)
    await chooseProject(page, String(row.project).trim())
    const chosen = await card.locator('input[name="projectName"]').inputValue()
    if (!chosen) throw new Error(`第 ${index + 1} 行项目没有写入`)
    await card.locator('input[name="workTimePercent"]').fill(String(row.percent))
    await card.locator('textarea[name="workContent"]').fill(String(row.content))
    await settle(page, 200)
  }
}

// The page reports the outcome in a two-second toast, then — because it expects
// to live inside the company's app shell — fails to close its own window and
// shows a modal. Both messages are read here, and the modal is dismissed so the
// next run starts on a clean page.
export async function submit(page) {
  const before = await page.locator('input[name="reportingDateTime"]').inputValue()
  await page.locator('.button-fixed-container button').click()
  const deadline = Date.now() + 20_000
  let result = { ok: false, message: `提交后 20 秒没有看到结果（日期字段仍为 ${before}）` }
  while (Date.now() < deadline) {
    if (await pageIsBlank(page)) {
      // After a successful save the page tries to close its own window and
      // empties itself in a plain browser; the calendar check decides the truth.
      result = { ok: false, message: '提交后页面被清空（站点尝试关闭窗口）', blanked: true }
      break
    }
    const toast = await readToast(page)
    if (toast) {
      if (/提交成功/.test(toast)) {
        result = { ok: true, message: '提交成功' }
      } else if (/关闭窗口失败/.test(toast)) {
        // Only reachable after a successful save.
        result = { ok: true, message: '提交成功（页面提示关闭窗口失败，可忽略）' }
      } else {
        result = { ok: false, message: toast }
      }
      break
    }
    const hash = new URL(page.url()).hash
    if (hash && hash !== ROUTES.addDay) {
      result = { ok: true, message: `已跳转到 ${hash}` }
      break
    }
    await page.waitForTimeout(250)
  }
  await dismissDialogs(page)
  return result
}

async function dismissDialogs(page) {
  const confirm = page.locator('.van-dialog__confirm, .van-dialog button:has-text("确认")')
  if (await confirm.count().catch(() => 0)) {
    await confirm.first().click().catch(() => {})
    await settle(page, 300)
  }
}

// --- one complete filing --------------------------------------------------

export async function fileDay({ page, date, plan, submitIt = true, label = 'run' }) {
  await go(page, ROUTES.addDay)
  await settle(page, 1000)
  // A fresh page can carry rows from an earlier click in the same session.
  await page.reload({ waitUntil: 'domcontentloaded' })
  await settle(page, 1500)

  await openCalendar(page)
  await pickDay(page, date)
  await fillPlan(page, plan)

  const shot = await capture(page, `${label}-filled`)
  if (!submitIt) return { ok: true, dryRun: true, screenshot: shot.shot, html: shot.html }

  const result = await submit(page)
  const after = await capture(page, `${label}-submitted`)

  // The toast can be missed (the page may blank itself), so the site's own
  // calendar is the authority on whether the day is filed.
  let filed = false
  try {
    if (!(await page.evaluate(() => document.querySelectorAll('.van-calendar__day').length).catch(() => 0))) {
      await go(page, ROUTES.addDay)
      await settle(page, 1200)
    }
    const marks = await calendarMarks(page)
    filed = Boolean(marks[new Date(`${date}T00:00:00`).getDate()]?.dot)
  } catch {
    filed = result.ok
  }
  const ok = result.ok || filed
  const message = ok
    ? result.ok
      ? result.message
      : '提交成功（系统日历上已标记）'
    : result.message
  return { ok, message, screenshot: after.shot, html: after.html, date, blanked: Boolean(result.blanked) }
}

export function record(entry) {
  const line = { at: new Date().toISOString(), time: hhmm(), ...entry }
  fs.appendFileSync(files.history(), `${JSON.stringify(line)}\n`, { mode: 0o600 })
  return line
}

export { isoDay, timestamp }
