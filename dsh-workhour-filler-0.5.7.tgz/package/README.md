# 工时填报（DSH 插件）

把「每天在内部系统里点日期、选项目、填占比和内容、点提交」这件事交给 DeepSeek Harness。

- **不打扰你**：自动化跑在独立 profile 的无窗口 Chrome 里，你正在用的 Chrome 窗口和标签页完全不受影响，不需要开远程调试端口。
- **密码不落盘**：登录密码存在 macOS 钥匙串（`service: dsh-workhour`），配置文件、日志、聊天记录里都没有明文。
- **两种定时**：装一个 launchd LaunchAgent，DSH 关着也能按时跑；或在设置页里手动执行。
- **当天去重**：先看系统日历上那天有没有「已填报」圆点，再看本地记录，已提交就提示「当天已在 09:53 提交过」。
- **补填**：当月多选日期，用默认组合或自定义组合依次补。
- **失败留证**：每次执行都存截图和 DOM 到 `~/.dsh-workhour/explore/`。

## 默认是安全模式：只填表，不提交

装好后 `submit.enabled = false`。每次执行会登录、选日期、选项目、填占比和内容，**停在提交前**，把截图留在 `~/.dsh-workhour/explore/`，然后告诉你「已填好，请打开页面点提交」。

要真的让它自己提交，必须在设置页打开「允许真实提交」开关（或 `workhour_configure` 传 `{"submit":{"enabled":true}}`）。这个开关是刻意做成默认关闭的：自动往生产系统写数据，应该由你亲手打开。

## 安装

### 1. 装插件

打开下载页，输入访问密码，下载 `dsh-workhour-filler-<版本>.tgz`：

> https://caffrey-li.github.io/dsh-workhour-download/

然后 DeepSeek Harness → 设置 → **插件** → **新增插件** → 选这个 `.tgz` 文件。

> desktop profile 只能由 DSH 应用自己安装，命令行 `dsh plugin --profile desktop add` 会被拒绝（这是 DSH 的限制，不是插件的问题）。

装好是**完全空白**的：没有账号、没有密码、没有默认组合、没有任何项目或个人数据。

### 2. 设置页在哪

设置 → **工时填报**（macOS 按 `⌘ ,`，或点左下角头像「Caffrey」→「设置」）。页面里能改默认组合、定时、安全开关，能同步项目、预填/提交当天、批量补填。

### 3. 重启一次 DSH

插件的"界面那一半"是在页面加载时载入的，装完插件要重启一次 DeepSeek Harness 才会出现设置页。重启后：**按 ⌘ ,（或点侧边栏底部齿轮）打开设置 → 左侧列表里的「工时填报」**。

### 4. 首次配置

在任意会话里说：

> 帮我配置工时填报

插件会弹出系统对话框要账号和密码（密码框是隐藏输入），直接写进钥匙串。或者点设置 → 工时填报 → 用设置页里的按钮。

然后同步一次项目列表：

> 同步一下我的工时项目

### 5. 设默认组合和定时

在设置页（设置 → 工时填报）里填：

- **默认组合**：项目 + 占比 + 工作内容，占比合计必须正好 100，项目不能重复
- **定时**：启用、工作日/每天、时间（例如 09:05）
- **无人应答时**：`等我来确认（跳过并提醒）` 或 `自动按默认提交`；询问超时默认 10 分钟，提醒间隔默认 30 分钟
- 点「安装定时任务」写入 `~/Library/LaunchAgents/com.dsh.workhour.plist`

## 在线更新

设置页底部有版本号、「检查更新」和「立即更新」。检查读的是公开下载站的 `latest.json`：

```
https://caffrey-li.github.io/dsh-workhour-download/latest.json
```

发现新版本时，插件会下载加密的安装包、用你输过的下载密码在本地解密（密码记在钥匙串的 `__download__` 条目），再交给 DSH 的插件管理器安装。装完**重启 DSH** 才会运行新版本。

也可以直接说：「检查一下工时填报有没有新版本」/「把工时填报更新到最新」。

## 对话框弹不出来时（Windows 常见）

首次配置默认走系统对话框。如果机器上 PowerShell 被策略限制、弹不出窗口，「设置账号密码」会显示原因而不是静默失败（0.3.6 起）。绕过办法：

```bat
:: 在插件文件夹里，密码从键盘输入（不回显、不进历史记录）
node bin\setup.mjs 你的工号 --password-stdin

:: 或者
node bin\setup.mjs 你的工号 --password 你的密码
```

也可以点设置页底部的「**诊断**」，它会检查密码存储后端、Chrome 路径、playwright、PowerShell、定时任务，把那段 JSON 发出来就能定位。

## 命令行（排查用）

```sh
cd <插件目录>
node bin/file.mjs status                      # 本月日历上哪些天已提交
node bin/file.mjs day --date 2026-11-13 --dry-run   # 只填不提交，留截图
node bin/file.mjs sync                        # 重新拉项目列表
node bin/file.mjs backfill --dates 2026-11-11,2026-11-12 --dry-run
node bin/file.mjs config                      # 看当前配置
node bin/file.mjs schedule status|install|uninstall
```

## 数据放在哪

| 路径 | 内容 |
|---|---|
| `~/.dsh-workhour/config.json` | 默认组合、定时规则、询问策略（不含密码） |
| `~/.dsh-workhour/state.json` | 账号名、已同步的项目列表 |
| `~/.dsh-workhour/history.jsonl` | 每次执行的结果、时间、截图路径 |
| `~/.dsh-workhour/chrome-profile/` | 浏览器 cookie，能省掉重复登录 |
| `~/.dsh-workhour/explore/` | 截图 + 页面 DOM，出问题时拿来看 |
| 钥匙串 `dsh-workhour` | 登录密码 |

## 提交成功后页面会变空

站点在保存成功后会让页面「关闭窗口」；在普通浏览器里这一步失败，页面会变空白。插件因此不靠提示语判断成功，而是**提交后重新打开日历，看那天有没有标记点**（`approved` = 已通过，`pending` = 待审批）。判断逻辑在 `core/flow.mjs` 的 `fileDay`。

## WorkBuddy（以及其他支持 MCP 的宿主）

插件自带一个零依赖的 MCP 服务器（`agents/mcp/server.mjs`），WorkBuddy、Claude Desktop、Codex 都能用。

**WorkBuddy** 不读用户级 `mcp.json`，它从「插件市场」加载 MCP。所以注册方式是写一个本地市场：

```sh
node agents/install-workbuddy.mjs            # 安装 / 更新
node agents/install-workbuddy.mjs --print    # 只打印会写什么
node agents/install-workbuddy.mjs --remove   # 卸载
```

它会：

1. 在 `~/.workbuddy/plugins/marketplaces/local-workhour/` 写一个只含本插件的 marketplace
2. 把 `local-workhour` 注册进 `~/.workbuddy/plugins/known_marketplaces.json`（原文件备份为 `.bak-workhour`）

然后**完全退出并重开 WorkBuddy** → 左侧「专家 · 技能 · 连接器」→ 找到 **workhour-mcp** 并启用 → 问「工时填报现在什么状态？」。

**Claude Desktop / Codex** 这类读 `mcpServers` 配置的宿主，用 `--print` 输出的 `.mcp.json` 内容直接粘贴即可。

> 会开浏览器的工具（同步项目、填报、补填）单次可能 15–60 秒，宿主的 MCP 超时要设到 60 秒以上。

## 飞书豆包（MCP 服务地址 + 技能）

豆包要的是**一个 URL**，所以插件还提供一个 HTTP 版的 MCP 服务：

```sh
node agents/mcp/http.mjs          # http://127.0.0.1:7788/mcp
node agents/mcp/http.mjs --host 0.0.0.0   # 允许内网/穿透访问
```

启动时打印令牌（首次自动生成，存 `~/.dsh-workhour/mcp-token`）。豆包里填：

| 字段 | 值 |
|---|---|
| MCP 服务地址 | `http://<机器>:7788/mcp?token=<令牌>` |
| 请求头（如有） | `Authorization: Bearer <令牌>` |
| 技能 | 上传 `agents/doubao/skill.md` |

⚠️ 飞书是云端服务，访问不到 `127.0.0.1` 和公司内网。要么把服务跑在内网机器上，要么用 cloudflared/frp 做内网穿透——真正登录填表的永远是那台能访问 `eis.goldwind.com` 的机器。

详见 [agents/doubao/README.md](agents/doubao/README.md)。

## Windows

要求：Windows 10/11、Node.js 22+、本机装有 Google Chrome。

1. 下载页点「下载 zip」，解压得到 `dsh-workhour-filler-<版本>` 文件夹。**这个 zip 自带 `node_modules`**（约 6 MB）：文件夹是通过 `link:` 装的，pnpm 不会给链接目录装依赖，所以依赖必须在包里
2. DSH → 设置 → 插件 → 新增插件 → **选那个文件夹**（选 .tgz 会报 `ERR_PNPM_INVALID_PACKAGE_NAME`：pnpm 把文件名当成 registry 包名了）→ 重启 DSH
3. 会话里说「配置工时填报」录账号密码，说「同步一下我的工时项目」
4. 设置 → 工时填报 → 填默认组合 → 点「安装定时任务」

平台差异（同一套界面和命令，底层自动切换）：

| | macOS | Windows |
|---|---|---|
| 密码 | 登录钥匙串（`security`） | DPAPI 用户级加密，密文在 `%APPDATA%\dsh-workhour\credentials.json` |
| 定时 | LaunchAgent `com.dsh.workhour`，每 5 分钟唤醒 | 任务计划程序 `DSH-Workhour-Filler`，每 5 分钟唤醒 |
| 弹窗/通知 | `osascript` | PowerShell + WinForms / Toast |
| 定时副本 | `~/Library/Application Support/dsh-workhour/app` | `%LOCALAPPDATA%\dsh-workhour\app` |
| 环境自检 | `node bin/doctor.mjs` | `node bin\doctor.mjs`，或双击 `install\install.cmd` |

> Windows 部分是按 macOS 的实现逐项对齐写的，**尚未在真机上端到端验证**（开发机是 macOS）。第一次跑请在 Windows 上执行 `node bin\doctor.mjs`，把输出发回。

## 已知限制（v0.1）

- 只支持 macOS。Windows 与 WorkBuddy 在后续版本。
- 「工作日」就是周一到周五，**不跳法定节假日和调休**（需要维护节假日日历）。
- 补填受系统限制：日历上只有**最近 7 天**可选（站点自己的规则，不是插件的），且只限当月。插件会先按这个窗口校验，不会等到点了才发现选不了。
- 网页改版会导致选择器失效；`node bin/file.mjs day --dry-run` 是重新校准的入口，截图和 DOM 都留在 `~/.dsh-workhour/explore/`。
- 密码在写入钥匙串的瞬间会作为 `security` 命令的参数出现几毫秒（同用户进程可见）；比存明文文件安全得多，但不是零暴露。

## 免责

这是个人效率工具：它替你在系统里提交工时。提交内容由你的默认组合决定，出错时先在设置页用 dry-run 验证。
