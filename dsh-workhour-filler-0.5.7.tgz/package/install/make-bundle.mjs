// Builds the password-protected download page and the update manifest.
//
//   node install/make-bundle.mjs <tarball> <password> [outDir]
//
// Writes into outDir:
//   index.html                       the page (encrypted payload inline)
//   latest.json                      what the plugin's 检查更新 reads
//   dsh-workhour-filler-<v>.tgz.enc  the same payload, for in-app updates
//
// The payload is encrypted with the password, so the host can be public.
import crypto from 'node:crypto'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const ITERATIONS = 210_000
const [, , tarball, password, outArg] = process.argv
if (!tarball || !password) {
  console.error('用法: node install/make-bundle.mjs <tarball> <password> [outDir]')
  process.exit(1)
}

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'))
const outDir = outArg ?? path.join(root, 'download-page')
fs.mkdirSync(outDir, { recursive: true })

const data = fs.readFileSync(tarball)
const salt = crypto.randomBytes(16)
const iv = crypto.randomBytes(12)
const key = crypto.pbkdf2Sync(password, salt, ITERATIONS, 32, 'sha256')
const cipher = crypto.createCipheriv('aes-256-gcm', key, iv)
const encrypted = Buffer.concat([cipher.update(data), cipher.final()])
const blob = Buffer.concat([encrypted, cipher.getAuthTag()])

const name = path.basename(tarball)
// A plain tarball next to the encrypted one: DSH's 添加插件 accepts an https
// address, so this is the one-step install path. It carries the same bytes as
// the public zip, so it exposes nothing the zip does not.
fs.copyFileSync(tarball, path.join(outDir, name))
// The fixed address: it always serves the newest build, so one install is enough
// and 检查更新 can reinstall from the same spec. pnpm re-fetches it (verified:
// same URL, new content → new version installed).
fs.copyFileSync(tarball, path.join(outDir, 'latest.tgz'))
// Windows users cannot install a .tgz by filename (pnpm reads it as a registry
// name), so the same package also ships as a zip that extracts to a folder they
// can pick with 新增插件 → 选择文件夹.
const zipName = `dsh-workhour-filler-${pkg.version}.zip`
try {
  const { execFileSync } = await import('node:child_process')
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'workhour-zip-'))
  execFileSync('tar', ['-xzf', path.resolve(tarball), '-C', tmp])
  // Flat archive: Windows Explorer's "Extract All" already creates a folder named
  // after the zip, so a top-level folder inside would nest it twice
  // (…\dsh-workhour-filler-x\dsh-workhour-filler-x\package.json) and the folder a
  // user picks would have no package.json in it.
  const folder = path.join(tmp, 'package')
  // A folder install is a pnpm link, and pnpm does not install the dependencies
  // of a linked folder. The zip therefore carries node_modules itself so the
  // extracted directory runs with no network and no pnpm.
  const modules = path.join(root, 'node_modules')
  if (fs.existsSync(modules)) {
    fs.cpSync(modules, path.join(folder, 'node_modules'), { recursive: true, dereference: true })
  }
  execFileSync('zip', ['-qr', path.join(outDir, zipName), '.'], { cwd: folder })
  fs.rmSync(tmp, { recursive: true, force: true })
} catch (error) {
  console.warn(`跳过 zip 生成：${error.message}`)
}
const encName = `dsh-workhour-filler-${pkg.version}.tgz.enc`
fs.writeFileSync(path.join(outDir, encName), blob, { mode: 0o644 })

const sha = crypto.createHash('sha256').update(data).digest('hex').slice(0, 16)
const author = {
  name: process.env.AUTHOR_NAME ?? '围脖安扣',
  login: process.env.AUTHOR_LOGIN ?? 'Caffrey-Li',
}
let avatar = ''
try {
  const bytes = fs.readFileSync(path.join(root, 'install', 'avatar.png'))
  const isJpeg = bytes[0] === 0xff && bytes[1] === 0xd8
  avatar = `data:image/${isJpeg ? 'jpeg' : 'png'};base64,${bytes.toString('base64')}`
} catch {
  avatar = 'https://avatars.githubusercontent.com/u/264446519?v=4'
}
const template = fs.readFileSync(path.join(root, 'install', 'download.template.html'), 'utf8')
const html = template
  .replaceAll('__PAYLOAD__', blob.toString('base64'))
  .replaceAll('__SALT__', salt.toString('base64'))
  .replaceAll('__IV__', iv.toString('base64'))
  .replaceAll('__ITERATIONS__', String(ITERATIONS))
  .replaceAll('__FILENAME__', name)
  .replaceAll('__SHA__', sha)
  .replaceAll('__SIZE__', `${(data.length / 1024).toFixed(0)} KB`)
  .replaceAll('__ZIP__', zipName)
  .replaceAll('__TGZ__', name)
  .replaceAll('__TGZ_URL__', `https://caffrey-li.github.io/dsh-workhour-download/${name}`)
  .replaceAll('__VERSION__', pkg.version)
  .replaceAll('__AVATAR__', avatar)
  .replaceAll('__AUTHOR_NAME__', author.name)
  .replaceAll('__AUTHOR_LOGIN__', author.login)
fs.writeFileSync(path.join(outDir, 'index.html'), html)

// The plugin reads this: a newer version, the encrypted file, and the parameters
// needed to open it with the password the user already has.
const manifest = {
  name: pkg.name,
  version: pkg.version,
  file: `https://caffrey-li.github.io/dsh-workhour-download/${encName}`,
  // Self-update installs this plain tarball URL: the plugin manager keeps it as
  // the profile dependency, so the address survives restarts (a temp file does
  // not). The manual download page still uses the encrypted `file`.
  channel: 'https://caffrey-li.github.io/dsh-workhour-download/latest.tgz',
  tgz: `https://caffrey-li.github.io/dsh-workhour-download/${name}`,
  sha256: crypto.createHash('sha256').update(data).digest('hex'),
  size: data.length,
  releasedAt: new Date().toISOString(),
  notes: `工时填报 v${pkg.version}`,
  enc: { salt: salt.toString('base64'), iv: iv.toString('base64'), iterations: ITERATIONS },
}
fs.writeFileSync(path.join(outDir, 'latest.json'), `${JSON.stringify(manifest, null, 2)}\n`)

console.log(JSON.stringify({ ok: true, outDir, version: pkg.version, page: 'index.html', manifest: 'latest.json', encrypted: encName, zip: fs.existsSync(path.join(outDir, zipName)) ? zipName : null }, null, 2))
