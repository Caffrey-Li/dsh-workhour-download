@echo off
rem 双击运行即可：调用同目录下的 install.ps1
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"
pause
