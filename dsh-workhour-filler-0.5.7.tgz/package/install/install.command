#!/bin/bash
# 一键安装：检查环境 → 打印「Add plugin」地址 → 提示下一步。
# 插件安装只能由 DSH 应用自己完成（desktop profile 被应用独占）。
set -u

echo "== DSH 工时填报 安装助手 =="
echo

fail=0

if [[ "$(uname -s)" != "Darwin" ]]; then
  echo "✗ 第一版只支持 macOS（当前：$(uname -s)）"
  fail=1
else
  echo "✓ macOS $(sw_vers -productVersion)"
fi

if [[ -x "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome" ]]; then
  echo "✓ Google Chrome 已安装"
else
  echo "✗ 没找到 Google Chrome，自动化需要一个本地浏览器"
  fail=1
fi

if command -v node >/dev/null 2>&1; then
  version="$(node -v)"
  major="${version#v}"
  major="${major%%.*}"
  if [[ "$major" -ge 22 ]]; then
    echo "✓ Node.js $version"
  else
    echo "✗ Node.js 需要 22 或更高（当前 $version）"
    fail=1
  fi
else
  echo "✗ 没找到 Node.js，请先安装 Node.js 22+"
  fail=1
fi

if security find-generic-password -s dsh-workhour >/dev/null 2>&1; then
  echo "✓ 钥匙串里已经有工时填报的密码"
else
  echo "· 钥匙串里还没有密码：装好插件后，在会话里说「配置工时填报」即可录入"
fi

echo
if [[ "$fail" -ne 0 ]]; then
  echo "有前置条件没满足，先处理上面的 ✗ 再来。"
  exit 1
fi

cat <<'EOF'
接下来三步：

1) 打开 DeepSeek Harness → 设置 → Plugins → Add plugin，
   粘贴：github:Caffrey-Li/dsh-workhour-filler#v0.1.0

2) 在任意会话里说：配置工时填报
   （会弹出系统对话框要账号和密码，密码写进钥匙串）

3) 在会话里说：同步一下我的工时项目
   然后打开 设置 → 工时填报，填默认组合、定时规则，点「安装定时任务」

排查：node bin/file.mjs status / day --dry-run / schedule status
EOF
