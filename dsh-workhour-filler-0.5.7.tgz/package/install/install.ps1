<#
    一键安装助手（Windows）

    用法：右键「使用 PowerShell 运行」，或在 PowerShell 里：
        powershell -ExecutionPolicy Bypass -File .\install.ps1

    只做环境检查并打印步骤；插件安装由 DeepSeek Harness 自己完成。
#>

$ErrorActionPreference = 'Stop'

Write-Host '== DSH 工时填报 安装助手（Windows） ==' -ForegroundColor Cyan
Write-Host ''

$fail = $false

Write-Host ("✓ Windows {0}" -f [System.Environment]::OSVersion.Version) -ForegroundColor Green

$chrome = @(
    "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
    "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe",
    "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe"
) | Where-Object { Test-Path $_ } | Select-Object -First 1
if ($chrome) {
    Write-Host "✓ Google Chrome: $chrome" -ForegroundColor Green
} else {
    Write-Host '✗ 没找到 Google Chrome，自动化需要一个本地浏览器' -ForegroundColor Red
    $fail = $true
}

$node = Get-Command node -ErrorAction SilentlyContinue
if ($node) {
    $version = (& node -v).Trim()
    $major = [int]($version.TrimStart('v').Split('.')[0])
    if ($major -ge 22) {
        Write-Host "✓ Node.js $version" -ForegroundColor Green
    } else {
        Write-Host "✗ Node.js 需要 22 或更高（当前 $version）" -ForegroundColor Red
        $fail = $true
    }
} else {
    Write-Host '✗ 没找到 Node.js，请先安装 Node.js 22+' -ForegroundColor Red
    $fail = $true
}

$vault = Join-Path $env:APPDATA 'dsh-workhour\credentials.json'
if (Test-Path $vault) {
    Write-Host '✓ 已经保存过登录密码（DPAPI 加密）' -ForegroundColor Green
} else {
    Write-Host '· 还没有保存密码：装好插件后在会话里说「配置工时填报」即可录入' -ForegroundColor Yellow
}

Write-Host ''
if ($fail) {
    Write-Host '有前置条件没满足，先处理上面的 ✗ 再来。' -ForegroundColor Red
    exit 1
}

@'
接下来三步：

1) 打开下载页，输入访问密码，下载 dsh-workhour-filler-<版本>.tgz
   https://caffrey-li.github.io/dsh-workhour-download/

2) 打开 DeepSeek Harness → 设置 → 插件 → 新增插件 → 选择刚下载的 .tgz
   装完重启一次 DSH。

3) 在任意会话里说：配置工时填报
   （会弹出输入框要账号和密码，密码用 DPAPI 加密保存，不落明文）
   再说：同步一下我的工时项目
   最后到 设置 → 工时填报 里填默认组合、定时规则，点「安装定时任务」
   （Windows 上它创建的是任务计划程序里的 DSH-Workhour-Filler，每 5 分钟检查一次）

排查：node bin\doctor.mjs
'@ | Write-Host
