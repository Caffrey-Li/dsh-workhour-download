#!/bin/bash
# 把源码推到私有仓库，把加密下载页推到公开仓库的 gh-pages 分支。
#
#   ./install/deploy.sh <私有仓库名> <公开下载仓库名>
#
# 两个仓库都要先在 GitHub 上建好（私有 / 公开），本机已配置 GitHub SSH key。
set -euo pipefail

PRIVATE_REPO=${1:-dsh-workhour-filler}
PUBLIC_REPO=${2:-dsh-workhour-download}
OWNER=${GITHUB_OWNER:-Caffrey-Li}
ROOT="$(cd "$(dirname "$0")/.." && pwd)"

cd "$ROOT"

echo "== 1/3 私有源码仓库 =="
if ! git remote get-url origin >/dev/null 2>&1; then
  git remote add origin "git@github.com:$OWNER/$PRIVATE_REPO.git"
fi
git branch -M main
git push -u origin main

echo "== 2/3 生成下载页 + 更新清单 =="
TGZ=$(ls dsh-workhour-filler-*.tgz 2>/dev/null | head -1 || true)
[ -n "$TGZ" ] || TGZ=$(npm pack --silent | tail -1)
echo "包：$TGZ"
node install/make-bundle.mjs "$TGZ" "${DOWNLOAD_PASSWORD:?设置 DOWNLOAD_PASSWORD}" download-page

echo "== 3/3 公开下载页 =="
TMP=$(mktemp -d)
cp -R download-page/. "$TMP/"
cat > "$TMP/README.md" <<'MD'
# 工时填报插件 · 下载页

访问页面需要密码（加密载荷，没有密码解不开）。

本仓库只放这个下载页，源码在私有仓库里。
MD
(
  cd "$TMP"
  git init -q
  git checkout -q -b gh-pages
  git add -A
  git -c user.name="deploy" -c user.email="deploy@local" commit -qm "下载页"
  git push -f "git@github.com:$OWNER/$PUBLIC_REPO.git" gh-pages
)
rm -rf "$TMP"

echo
echo "推完了。"
echo "  源码：https://github.com/$OWNER/$PRIVATE_REPO"
echo "  下载页：https://$OWNER.github.io/$PUBLIC_REPO/  （若打不开，到该仓库 Settings → Pages 选 gh-pages 分支）"
