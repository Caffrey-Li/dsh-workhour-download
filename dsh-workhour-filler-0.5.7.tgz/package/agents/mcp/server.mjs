#!/usr/bin/env node
// stdio transport for the MCP toolset — WorkBuddy, Claude Desktop, Codex.
//
//   node agents/mcp/server.mjs
//
// Hosts that only accept an MCP service URL (飞书豆包 and friends) use the HTTP
// transport instead: agents/mcp/http.mjs.
import readline from 'node:readline'
import { TOOLS, VERSION, callTool } from './tools.mjs'

const NAME = 'workhour'

function send(message) {
  process.stdout.write(`${JSON.stringify(message)}\n`)
}
const ok = (id, value) => send({ jsonrpc: '2.0', id, result: value })
const fail = (id, code, message) => send({ jsonrpc: '2.0', id, error: { code, message } })
const text = (value) => (typeof value === 'string' ? value : JSON.stringify(value, null, 2))

const rl = readline.createInterface({ input: process.stdin, crlfDelay: Infinity })

rl.on('line', async (line) => {
  let message
  try {
    message = JSON.parse(line)
  } catch {
    return
  }
  if (!message || message.jsonrpc !== '2.0') return
  const { id, method, params } = message

  if (method === 'initialize') {
    ok(id, {
      protocolVersion: params?.protocolVersion || '2024-11-05',
      capabilities: { tools: {} },
      serverInfo: { name: NAME, version: VERSION },
    })
    return
  }
  if (method === 'notifications/initialized' || method === 'initialized') return
  if (method === 'ping') {
    ok(id, {})
    return
  }
  if (method === 'tools/list') {
    ok(id, { tools: TOOLS })
    return
  }
  if (method === 'tools/call') {
    const name = params?.name
    try {
      const value = await callTool(name, params?.arguments ?? {})
      ok(id, { content: [{ type: 'text', text: text(value) }] })
    } catch (error) {
      ok(id, { content: [{ type: 'text', text: `工时填报出错：${error?.message ?? error}` }], isError: true })
    }
    return
  }
  if (id !== undefined) fail(id, -32601, `Method not found: ${method}`)
})

process.on('SIGINT', () => process.exit(0))
process.on('SIGTERM', () => process.exit(0))
