#!/usr/bin/env node
// HTTP transport for the same MCP toolset — for hosts that take an MCP service
// URL instead of a local command (飞书豆包, Coze, other cloud agents).
//
//   node agents/mcp/http.mjs [--port 7788] [--host 127.0.0.1]
//
// Endpoints
//   POST /mcp     JSON-RPC (initialize, tools/list, tools/call, ping)
//   GET  /health  liveness probe
//
// Auth: a bearer token, generated once and kept in ~/.dsh-workhour/mcp-token.
// Pass it as `Authorization: Bearer <token>` or `?token=<token>`.
//
// The browser work still happens on this machine: the host calls in, this
// process logs in to the intranet site and files the hours. Keep the computer
// awake and the VPN connected while it is used.
import crypto from 'node:crypto'
import fs from 'node:fs'
import http from 'node:http'
import path from 'node:path'
import { TOOLS, VERSION, callTool } from './tools.mjs'
import { home } from '../../core/paths.mjs'

const NAME = 'workhour'

function arg(name, fallback) {
  const index = process.argv.indexOf(`--${name}`)
  return index > -1 ? process.argv[index + 1] : fallback
}

const port = Number(arg('port', process.env.WORKHOUR_MCP_PORT ?? 7788))
const host = arg('host', process.env.WORKHOUR_MCP_HOST ?? '127.0.0.1')

function tokenFile() {
  return path.join(home(), 'mcp-token')
}

function loadToken() {
  const fromEnv = process.env.WORKHOUR_MCP_TOKEN
  if (fromEnv) return fromEnv
  try {
    const existing = fs.readFileSync(tokenFile(), 'utf8').trim()
    if (existing) return existing
  } catch {
    // generate below
  }
  const token = crypto.randomBytes(24).toString('hex')
  fs.mkdirSync(home(), { recursive: true, mode: 0o700 })
  fs.writeFileSync(tokenFile(), token, { mode: 0o600 })
  return token
}

const TOKEN = loadToken()

function authorized(request, url) {
  if (!TOKEN) return true
  const header = request.headers.authorization ?? ''
  if (header.startsWith('Bearer ') && header.slice(7).trim() === TOKEN) return true
  const query = url.searchParams.get('token')
  return query !== null && query === TOKEN
}

const text = (value) => (typeof value === 'string' ? value : JSON.stringify(value, null, 2))

async function handleRpc(message) {
  const { id, method, params } = message
  const reply = (result) => ({ jsonrpc: '2.0', id, result })
  const failure = (code, msg) => ({ jsonrpc: '2.0', id, error: { code, message: msg } })

  if (method === 'initialize') {
    return reply({
      protocolVersion: params?.protocolVersion || '2024-11-05',
      capabilities: { tools: {} },
      serverInfo: { name: NAME, version: VERSION },
    })
  }
  if (method === 'notifications/initialized' || method === 'initialized') return null
  if (method === 'ping') return reply({})
  if (method === 'tools/list') return reply({ tools: TOOLS })
  if (method === 'tools/call') {
    try {
      const value = await callTool(params?.name, params?.arguments ?? {})
      return reply({ content: [{ type: 'text', text: text(value) }] })
    } catch (error) {
      return reply({ content: [{ type: 'text', text: `工时填报出错：${error?.message ?? error}` }], isError: true })
    }
  }
  if (id === undefined) return null
  return failure(-32601, `Method not found: ${method}`)
}

function readBody(request) {
  return new Promise((resolve, reject) => {
    let body = ''
    request.on('data', (chunk) => {
      body += chunk
      if (body.length > 2_000_000) reject(new Error('请求体过大'))
    })
    request.on('end', () => resolve(body))
    request.on('error', reject)
  })
}

const server = http.createServer(async (request, response) => {
  const url = new URL(request.url ?? '/', `http://${request.headers.host ?? 'localhost'}`)
  const cors = {
    'access-control-allow-origin': '*',
    'access-control-allow-headers': 'authorization,content-type,accept,mcp-protocol-version,mcp-session-id',
    'access-control-allow-methods': 'POST,GET,OPTIONS',
  }

  if (request.method === 'OPTIONS') {
    response.writeHead(204, cors)
    response.end()
    return
  }

  if (url.pathname === '/health' || url.pathname === '/') {
    response.writeHead(200, { 'content-type': 'application/json', ...cors })
    response.end(JSON.stringify({ ok: true, name: NAME, version: VERSION, tools: TOOLS.length }))
    return
  }

  if (url.pathname !== '/mcp') {
    response.writeHead(404, { 'content-type': 'application/json', ...cors })
    response.end(JSON.stringify({ error: 'not found' }))
    return
  }

  if (!authorized(request, url)) {
    response.writeHead(401, { 'content-type': 'application/json', ...cors })
    response.end(JSON.stringify({ error: 'unauthorized: pass Authorization: Bearer <token>' }))
    return
  }

  // Streamable HTTP clients may open a GET stream; answer with an empty SSE
  // stream they can keep, and close it after the first comment.
  if (request.method === 'GET') {
    response.writeHead(200, {
      'content-type': 'text/event-stream',
      'cache-control': 'no-cache',
      connection: 'keep-alive',
      ...cors,
    })
    response.write(': connected\n\n')
    const timer = setInterval(() => response.write(': ping\n\n'), 15_000)
    request.on('close', () => clearInterval(timer))
    return
  }

  if (request.method !== 'POST') {
    response.writeHead(405, { 'content-type': 'application/json', allow: 'POST,GET,OPTIONS', ...cors })
    response.end(JSON.stringify({ error: 'method not allowed' }))
    return
  }

  let payload
  try {
    payload = JSON.parse(await readBody(request))
  } catch (error) {
    response.writeHead(400, { 'content-type': 'application/json', ...cors })
    response.end(JSON.stringify({ jsonrpc: '2.0', id: null, error: { code: -32700, message: `parse error: ${error.message}` } }))
    return
  }

  const messages = Array.isArray(payload) ? payload : [payload]
  const replies = []
  for (const message of messages) {
    if (!message || message.jsonrpc !== '2.0') continue
    const reply = await handleRpc(message)
    if (reply) replies.push(reply)
  }

  if (replies.length === 0) {
    response.writeHead(202, cors)
    response.end()
    return
  }

  response.writeHead(200, { 'content-type': 'application/json', ...cors })
  response.end(JSON.stringify(Array.isArray(payload) ? replies : replies[0]))
})

server.listen(port, host, () => {
  const shown = host === '0.0.0.0' ? '<本机 IP>' : host
  console.log(`工时填报 MCP 服务已启动`)
  console.log(`  地址：http://${shown}:${port}/mcp`)
  console.log(`  健康检查：http://${shown}:${port}/health`)
  console.log(`  令牌：${TOKEN}`)
  console.log(`  （请求头 Authorization: Bearer <令牌>，或 ?token=<令牌>）`)
  console.log(`  工具：${TOOLS.map((tool) => tool.name).join(', ')}`)
  if (host === '127.0.0.1') {
    console.log('  只监听本机。要让云端宿主访问，用 --host 0.0.0.0 并配内网穿透/公网地址。')
  }
})

process.on('SIGINT', () => process.exit(0))
process.on('SIGTERM', () => process.exit(0))
