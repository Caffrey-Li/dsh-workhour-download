// The toolset shared by the stdio transport (WorkBuddy, Claude Desktop, Codex)
// and the HTTP transport (hosts that only accept an MCP service URL, such as
// 飞书豆包). One list, one implementation.
import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'

const HERE = path.dirname(fileURLToPath(import.meta.url))
const ROOT = path.resolve(HERE, '..', '..')

// pathToFileURL, not a bare path: on Windows an absolute path is not a valid
// module specifier and the import would fail with ERR_UNSUPPORTED_ESM_URL_SCHEME.
const core = (name) => import(pathToFileURL(path.join(ROOT, 'core', name)).href)

export const ROOT_DIR = ROOT

const { readConfig, writeConfig, validatePlan } = await core('config.mjs')
const { readState, updateState, history, findSubmission } = await core('store.mjs')
const { dayKey, listBackfillableDays, assertBackfillable } = await core('policy.mjs')
const runner = await core('runner.mjs')
const { syncProjects } = await core('flow.mjs')
const keychain = await core('keychain.mjs')
const { prompt } = await core('notify.mjs')
const launchd = await core('launchd.mjs')

export const VERSION = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8')).version

export const TOOLS = [
  {
    name: 'workhour_status',
    description:
      '工时填报状态：账号是否已配置、可填报项目、今天是否已提交、默认组合、定时规则。不打开浏览器，很快。',
    inputSchema: { type: 'object', properties: {}, additionalProperties: false },
  },
  {
    name: 'workhour_setup',
    description:
      '首次配置账号密码。不给参数时弹系统对话框（密码隐藏输入）；宿主没有对话框能力时，可以传 account + password 直接写入系统保险箱。',
    inputSchema: {
      type: 'object',
      properties: {
        account: { type: 'string', description: '登录账号；与 password 一起传可跳过对话框' },
        password: { type: 'string', description: '登录密码；只在没有对话框能力时使用' },
      },
      additionalProperties: false,
    },
  },
  {
    name: 'workhour_sync_projects',
    description: '登录内部系统并重新读取本人可填报的项目列表（需要打开浏览器，约 15–30 秒）。',
    inputSchema: { type: 'object', properties: {}, additionalProperties: false },
  },
  {
    name: 'workhour_days',
    description: '当月可补填窗口内每一天是否已填报（读系统日历标记），用于决定补填哪些日期。约 15–30 秒。',
    inputSchema: { type: 'object', properties: {}, additionalProperties: false },
  },
  {
    name: 'workhour_file',
    description:
      '为某一天填报工时。不传 date 即今天；不传 plan 用默认组合。plan 是 [{project, percent, content}]，percent 为 1~100 整数且合计必须等于 100，项目不能重复。默认只填表不提交，除非 submit.enabled 打开。',
    inputSchema: {
      type: 'object',
      properties: {
        date: { type: 'string', description: 'YYYY-MM-DD，默认今天' },
        plan: { type: 'array', items: { type: 'object' }, description: '填报组合' },
        dryRun: { type: 'boolean', description: '只填表不提交' },
      },
      additionalProperties: false,
    },
  },
  {
    name: 'workhour_backfill',
    description: '补填当月内多个日期，按默认组合或给定 plan 依次填报，已填报的日期自动跳过。',
    inputSchema: {
      type: 'object',
      properties: {
        dates: { type: 'array', items: { type: 'string' }, description: 'YYYY-MM-DD 列表，仅限当月可填窗口内' },
        plan: { type: 'array', items: { type: 'object' } },
        dryRun: { type: 'boolean' },
      },
      required: ['dates'],
      additionalProperties: false,
    },
  },
  {
    name: 'workhour_configure',
    description:
      '修改配置：defaultPlan、defaultContent、schedule {enabled,kind:weekday|daily,time:"HH:mm"}、ask {mode:"ask"|"auto",timeoutMinutes,remindEveryMinutes}、submit {enabled}。',
    inputSchema: {
      type: 'object',
      properties: {
        defaultPlan: { type: 'array', items: { type: 'object' } },
        defaultContent: { type: 'string' },
        schedule: { type: 'object' },
        ask: { type: 'object' },
        submit: { type: 'object' },
      },
      additionalProperties: false,
    },
  },
  {
    name: 'workhour_schedule',
    description: '安装、卸载或查看定时任务（macOS 用 LaunchAgent，Windows 用任务计划程序）。',
    inputSchema: {
      type: 'object',
      properties: { action: { type: 'string', enum: ['status', 'install', 'uninstall'] } },
      additionalProperties: false,
    },
  },
  {
    name: 'workhour_history',
    description: '最近的执行记录。',
    inputSchema: {
      type: 'object',
      properties: { limit: { type: 'integer', minimum: 1, maximum: 200 } },
      additionalProperties: false,
    },
  },
]

function send(message) {
  process.stdout.write(`${JSON.stringify(message)}\n`)
}
const ok = (id, value) => send({ jsonrpc: '2.0', id, result: value })
const fail = (id, code, message) => send({ jsonrpc: '2.0', id, error: { code, message } })
const text = (value) => (typeof value === 'string' ? value : JSON.stringify(value, null, 2))

export async function status() {
  const config = readConfig()
  const state = readState()
  const today = dayKey()
  const cached = runner.cachedDayStates()
  return {
    account: state.account ?? null,
    passwordSaved: state.account ? await keychain.hasPassword(state.account) : false,
    projects: state.projects ?? [],
    projectsSyncedAt: state.projectsSyncedAt ?? null,
    today,
    filedToday: findSubmission(today) ?? null,
    days: cached?.days ?? listBackfillableDays(config.backfill?.days ?? 7).map((date) => ({ date: dayKey(date), filed: false })),
    defaultPlan: config.defaultPlan,
    defaultContent: config.defaultContent,
    schedule: config.schedule,
    ask: config.ask,
    submit: config.submit,
    scheduleInstalled: (await launchd.query().catch(() => ({ installed: false }))).installed,
    platform: process.platform,
  }
}

export async function setup(args = {}) {
  if (typeof args.account === 'string' && args.account.trim() && typeof args.password === 'string' && args.password.length > 0) {
    await keychain.setPassword(args.account.trim(), args.password)
    updateState({ account: args.account.trim() })
    return { ok: true, account: args.account.trim(), via: 'arguments' }
  }
  const state = readState()
  const account = await prompt({
    title: '工时填报',
    message: '请输入登录账号（工号或用户名）',
    defaultValue: state.account ?? '',
  })
  if (!account) throw new Error('未输入账号')
  const password = await prompt({ title: '工时填报', message: '请输入登录密码（隐藏输入，写入系统保险箱）', hidden: true })
  if (!password || password.length < 4) throw new Error('密码为空或太短')
  await keychain.setPassword(account, password)
  updateState({ account })
  return { ok: true, account }
}

export async function configure(patch) {
  const next = { ...(patch ?? {}) }
  if (next.defaultPlan) next.defaultPlan = validatePlan(next.defaultPlan, next.defaultContent ?? readConfig().defaultContent)
  return { ok: true, config: writeConfig(next) }
}

export async function callTool(name, args = {}) {
  const config = readConfig()
  switch (name) {
    case 'workhour_status':
      return status()
    case 'workhour_setup':
      return setup(args)
    case 'workhour_sync_projects': {
      const projects = await runner.withSession((page) => syncProjects(page))
      updateState({ projects, projectsSyncedAt: new Date().toISOString() })
      return { ok: true, count: projects.length, projects }
    }
    case 'workhour_days':
      return { days: await runner.dayStates({ force: true }) }
    case 'workhour_file':
      return runner.runDay({
        date: args.date ? new Date(`${args.date}T00:00:00`) : new Date(),
        plan: validatePlan(args.plan ?? config.defaultPlan, config.defaultContent),
        dryRun: args.dryRun,
      })
    case 'workhour_backfill': {
      if (!Array.isArray(args.dates) || args.dates.length === 0) throw new Error('dates 不能为空')
      const plan = validatePlan(args.plan ?? config.defaultPlan, config.defaultContent)
      const results = []
      for (const value of args.dates) {
        assertBackfillable(new Date(`${value}T00:00:00`), config.backfill?.days ?? 7)
        results.push({ date: value, ...(await runner.runDay({ date: new Date(`${value}T00:00:00`), plan, dryRun: args.dryRun, skipIfFiled: true })) })
      }
      return { ok: results.every((row) => row.ok || row.skipped), results }
    }
    case 'workhour_configure':
      return configure(args)
    case 'workhour_schedule': {
      const action = args.action ?? 'status'
      if (action === 'install') return { ok: true, ...(await launchd.install(ROOT)) }
      if (action === 'uninstall') return { ok: true, ...(await launchd.uninstall()) }
      return { ok: true, ...(await launchd.query().catch(() => launchd.status())) }
    }
    case 'workhour_history':
      return { today: dayKey(), entries: history(Number(args.limit ?? 20)) }
    default:
      throw new Error(`Unknown tool: ${name}`)
  }
}

