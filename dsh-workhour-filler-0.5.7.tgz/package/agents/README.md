# MCP 入口（WorkBuddy / Claude Desktop / Codex）

`mcp/server.mjs` 是一个零依赖的 stdio MCP 服务器，直接复用插件 `core/` 里的实现，
所以和 DSH 插件共享同一份配置与钥匙串（macOS）/ DPAPI（Windows）。

## 注册

```sh
node agents/install-workbuddy.mjs          # 写入 ~/.workbuddy/mcp.json
node agents/install-workbuddy.mjs --print  # 只打印
```

写入的条目形如：

```json
{
  "mcpServers": {
    "workhour": {
      "command": "/usr/local/bin/node",
      "args": ["/绝对路径/agents/mcp/server.mjs"],
      "env": {}
    }
  }
}
```

换机器、换 Node 版本后重跑一次安装脚本即可（它会把绝对路径刷新成当前 node）。

## 工具

| 工具 | 说明 |
|---|---|
| `workhour_status` | 账号、项目、今日状态、默认组合、定时规则（不开浏览器，秒回） |
| `workhour_setup` | 弹系统对话框录入账号密码 |
| `workhour_sync_projects` | 重新拉取项目列表（约 15–30 秒） |
| `workhour_days` | 当月可填窗口内每天的填报状态 |
| `workhour_file` | 填报某一天（默认只填不提交） |
| `workhour_backfill` | 批量补填多个日期 |
| `workhour_configure` | 改默认组合 / 定时 / 提交开关 |
| `workhour_schedule` | 安装、卸载、查看定时任务 |
| `workhour_history` | 最近执行记录 |

## 注意

- 服务器进程需要能启动无窗口 Chrome，和 DSH 插件一样依赖本机安装的 Google Chrome。
- 数据目录与 DSH 插件共用：macOS `~/.dsh-workhour`，Windows `%USERPROFILE%\\.dsh-workhour`。
