#!/usr/bin/env node
// Registers this plugin's MCP server with WorkBuddy.
//
// WorkBuddy does not read a user-level mcp.json. It loads MCP servers from
// plugin marketplaces, so this writes a small local marketplace and points
// WorkBuddy's marketplace index at it.
//
//   node agents/install-workbuddy.mjs            # 安装 / 更新
//   node agents/install-workbuddy.mjs --print    # 只打印会写什么
//   node agents/install-workbuddy.mjs --remove   # 卸载
//
// Existing marketplaces are kept; only "local-workhour" is written.
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const HERE = path.dirname(fileURLToPath(import.meta.url))
const SERVER = path.resolve(HERE, 'mcp', 'server.mjs')
const VERSION = (() => {
  try {
    return JSON.parse(fs.readFileSync(path.resolve(HERE, '..', 'package.json'), 'utf8')).version
  } catch {
    return '0.0.0'
  }
})()

const argv = process.argv.slice(2)
const printOnly = argv.includes('--print')
const remove = argv.includes('--remove')

const workbuddyHome = process.env.WORKBUDDY_HOME || path.join(os.homedir(), '.workbuddy')
const indexFile = path.join(workbuddyHome, 'plugins', 'known_marketplaces.json')
const marketplaceDir = path.join(workbuddyHome, 'plugins', 'marketplaces', 'local-workhour')
const pluginDir = path.join(marketplaceDir, 'mcps', 'workhour-mcp')

const marketplace = {
  name: 'local-workhour',
  description: '本机安装的工时填报 MCP：把工时填报插件的能力提供给 WorkBuddy。',
  owner: { name: 'Caffrey-Li' },
  metadata: { version: '1.0.0' },
  plugins: [
    {
      name: 'workhour-mcp',
      description: '工时填报：查状态、同步项目、填/补填工时（默认只填不提交）。',
      source: './mcps/workhour-mcp',
      category: 'mcp-app',
      version: VERSION,
    },
  ],
}

const pluginManifest = {
  name: 'workhour-mcp',
  version: VERSION,
  description: '工时填报 MCP：账号密码存系统保险箱，填报走无窗口 Chrome，默认只填表不提交。',
  author: { name: 'Caffrey-Li' },
  category: 'mcp-app',
  keywords: ['workhour', 'mcp-app', 'stdio'],
  workbuddy: { runtimeOwner: 'agent-cli' },
}

const mcp = {
  mcpServers: {
    workhour: {
      type: 'stdio',
      command: process.execPath,
      args: [SERVER],
      defer_loading: false,
    },
  },
}

const indexEntry = {
  manifestName: 'local-workhour',
  type: 'directory',
  source: { source: 'directory', path: marketplaceDir },
  installLocation: marketplaceDir,
  description: 'Local marketplace for the workhour MCP',
  lastUpdated: new Date().toISOString(),
  autoUpdate: false,
  isBuiltIn: false,
}

if (printOnly) {
  console.log(
    JSON.stringify(
      { files: { 'marketplace.json': marketplace, 'plugin.json': pluginManifest, '.mcp.json': mcp }, indexEntry },
      null,
      2,
    ),
  )
  process.exit(0)
}

if (!fs.existsSync(indexFile)) {
  console.error(`没找到 WorkBuddy 的插件索引：${indexFile}\n先打开一次 WorkBuddy，或设置 WORKBUDDY_HOME。`)
  process.exit(1)
}

const readIndex = () => {
  const parsed = JSON.parse(fs.readFileSync(indexFile, 'utf8'))
  if (!parsed || typeof parsed !== 'object') throw new Error('known_marketplaces.json 不是对象')
  return parsed
}

if (remove) {
  const index = readIndex()
  delete index['local-workhour']
  fs.copyFileSync(indexFile, `${indexFile}.bak-workhour`)
  fs.writeFileSync(indexFile, `${JSON.stringify(index, null, 2)}\n`)
  fs.rmSync(marketplaceDir, { recursive: true, force: true })
  console.log('已卸载 local-workhour，重启 WorkBuddy 生效。')
  process.exit(0)
}

fs.mkdirSync(path.join(marketplaceDir, '.codebuddy-plugin'), { recursive: true })
fs.mkdirSync(path.join(pluginDir, '.codebuddy-plugin'), { recursive: true })
fs.writeFileSync(path.join(marketplaceDir, '.codebuddy-plugin', 'marketplace.json'), `${JSON.stringify(marketplace, null, 2)}\n`)
fs.writeFileSync(path.join(pluginDir, '.codebuddy-plugin', 'plugin.json'), `${JSON.stringify(pluginManifest, null, 2)}\n`)
fs.writeFileSync(path.join(pluginDir, '.mcp.json'), `${JSON.stringify(mcp, null, 2)}\n`)

const index = readIndex()
index['local-workhour'] = indexEntry
fs.copyFileSync(indexFile, `${indexFile}.bak-workhour`)
fs.writeFileSync(indexFile, `${JSON.stringify(index, null, 2)}\n`)

console.log(`已写入本地 marketplace：${marketplaceDir}`)
console.log(`已注册到：${indexFile}（原文件备份 ${path.basename(indexFile)}.bak-workhour）`)
console.log(`
接下来：
1. 完全退出并重开 WorkBuddy
2. 打开左侧「专家 · 技能 · 连接器」，在插件/连接器列表里找到「workhour-mcp」并启用
3. 问一句：工时填报现在什么状态？

注意：
- 服务器用 ${process.execPath} 启动；换机器或重装 Node 后重跑本脚本。
- 会开浏览器的操作（同步项目、填报、补填）单次 15–60 秒。
`)
