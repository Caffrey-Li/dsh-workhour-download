# 飞书豆包接入

飞书豆包的插件要求两样东西：**一个 MCP 服务地址** 和 **一个技能说明**。这个目录里就是给它的那份。

## 1. 起 MCP 服务

在装了本插件的机器上：

```sh
node agents/mcp/http.mjs                 # 只监听 127.0.0.1:7788
node agents/mcp/http.mjs --port 8899     # 换端口
node agents/mcp/http.mjs --host 0.0.0.0  # 让同网段/内网穿透访问
```

启动后会打印：

```
地址：http://127.0.0.1:7788/mcp
健康检查：http://127.0.0.1:7788/health
令牌：xxxxxxxx
```

令牌第一次启动时生成，存在 `~/.dsh-workhour/mcp-token`（权限 600）。也可以用环境变量指定：

```sh
WORKHOUR_MCP_TOKEN=你的令牌 node agents/mcp/http.mjs
```

请求两种带法都行：`Authorization: Bearer <令牌>` 或 `?token=<令牌>`。

## 2. 在豆包里填

| 字段 | 填什么 |
|---|---|
| 服务地址 | `http://<这台机器>：7788/mcp`（带令牌参数时写成 `.../mcp?token=<令牌>`） |
| 鉴权 | 如果有独立的「请求头」配置，用 `Authorization: Bearer <令牌>` |
| 技能 | 上传 `skill.md`（或用它的技能编辑器粘贴内容） |

> 飞书是云端服务，**它访问不到你本机的 127.0.0.1，也访问不到公司内网**。所以两种做法：
>
> - **内网自建**：把服务跑在一台公司内网机器上，`--host 0.0.0.0`，让飞书的私有化部署/内网代理能访问
> - **内网穿透**：本机开隧道（cloudflared / frp / ngrok），把公网地址填进去；这台机器必须保持开机、连着 VPN
>
> 无论哪种，真正登录和填表都发生在**这台能访问内网的机器**上，豆包只是发起指令。

## 3. 验证

```sh
# 健康检查（不需要令牌）
curl http://127.0.0.1:7788/health

# 列工具
curl -s -X POST http://127.0.0.1:7788/mcp \
  -H "authorization: Bearer <令牌>" -H 'content-type: application/json' \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/list"}'

# 查状态
curl -s -X POST http://127.0.0.1:7788/mcp \
  -H "authorization: Bearer <令牌>" -H 'content-type: application/json' \
  -d '{"jsonrpc":"2.0","id":2,"method":"tools/call","params":{"name":"workhour_status","arguments":{}}}'
```

## 工具与约束

和 WorkBuddy 那套完全一致（9 个工具，同一份实现）。安全约束写在 `skill.md` 里，最重要的是两条：

- **不要在对话里索要密码**：`workhour_setup` 会在本机弹输入框
- **默认只填不提交**：要提交必须用户明确说，并先打开 `submit.enabled`

## 超时

`workhour_sync_projects` / `workhour_file` / `workhour_backfill` / `workhour_days` 会开无头 Chrome，单次 15–60 秒。豆包那边的工具超时如果短于 60 秒，会把成功的调用判成失败。
