// Host half of the 工时填报 plugin.
//
// It exposes one set of operations to two callers: the agent (as tools) and the
// settings page (as slash commands, the only Host action surface a third-party
// client plugin can reach). Both call the same core modules, so a filing
// started from chat, from the settings page or from launchd behaves the same.
import fs from 'node:fs'
import path from 'node:path'
import { execFile } from 'node:child_process'
import { generateKeyPairSync, privateDecrypt, constants as cryptoConstants } from 'node:crypto'
import { fileURLToPath } from 'node:url'
import { files } from './core/paths.mjs'
import { readConfig, writeConfig, validatePlan } from './core/config.mjs'
import { readState, updateState, history, findSubmission } from './core/store.mjs'
import { dayKey, shouldFire, listBackfillableDays, assertBackfillable } from './core/policy.mjs'
import { runDay, runScheduled, withSession, runBackfillBatch, dayStates, cachedDayStates } from './core/runner.mjs'
import { syncProjects } from './core/flow.mjs'
import { findChrome } from './core/browser.mjs'
import * as launchd from './core/launchd.mjs'
import { ask, prompt, notify, powershellWorks, powershellPath } from './core/notify.mjs'
import { setPassword, hasPassword, getPassword, deletePassword } from './core/keychain.mjs'
import { checkForUpdate, downloadPackage, installSpec, currentVersion, DEFAULT_MANIFEST } from './core/update.mjs'

// The plugin directory itself: launchd must be pointed at this copy, not at the
// directory DSH happened to start in.
const PLUGIN_ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)))

export const name = 'workhour'
export const inject = ['tools', 'commands']

// Settings the settings page may edit. Nothing secret lives here: the password
// stays in the keychain. Schema is optional at load time so the plugin still
// runs (config.json only) if the schema package is not resolvable.
let Schema
for (const specifier of ['@deepseek-ai/schemastery', 'schemastery']) {
  try {
    Schema = (await import(specifier)).default
    break
  } catch {
    Schema = undefined
  }
}

const SCHEMA_FIELDS = {
  defaultContent: Schema?.string().default('项目投入').volatile(),
  defaultPlan: Schema?.array(
    Schema.object({
      project: Schema.string(),
      percent: Schema.number().step(1).min(1).max(100),
      content: Schema.string(),
    }),
  ).default([]).volatile(),
  schedule: Schema?.object({
    enabled: Schema.boolean().default(false),
    kind: Schema.union(['weekday', 'daily']).default('weekday'),
    time: Schema.string().default('09:05'),
  }).default({ enabled: false, kind: 'weekday', time: '09:05' }).volatile(),
  update: Schema?.object({
    manifestUrl: Schema.string().default(DEFAULT_MANIFEST),
  }).default({ manifestUrl: DEFAULT_MANIFEST }).volatile(),
  submit: Schema?.object({
    enabled: Schema.boolean().default(false),
  }).default({ enabled: false }).volatile(),
  ask: Schema?.object({
    mode: Schema.union(['ask', 'auto']).default('ask'),
    timeoutMinutes: Schema.number().step(1).min(1).default(10),
    remindEveryMinutes: Schema.number().step(1).min(1).default(30),
  }).default({ mode: 'ask', timeoutMinutes: 10, remindEveryMinutes: 30 }).volatile(),
}

export const Config = Schema ? Schema.object(SCHEMA_FIELDS) : undefined

// defineTool validates the definition; the plain object keeps the plugin
// loadable in a runtime that does not publish the tool package.
let defineTool = (options) => options
for (const specifier of ['@deepseek-ai/dsh-tools', 'dsh-tools']) {
  try {
    ;({ defineTool } = await import(specifier))
    break
  } catch {
    // try the next specifier, then keep the plain-object fallback
  }
}

const NS = 'workhour'

// A short-lived RSA keypair so the settings page can hand over a password
// without the plaintext ever appearing in a command line or the transcript.
// The key rotates after each use.
let secretKey = null
let publicKeyPem = null
function ensureKeyPair() {
  if (!secretKey) {
    const { publicKey, privateKey } = generateKeyPairSync('rsa', {
      modulusLength: 2048,
      publicKeyEncoding: { type: 'spki', format: 'pem' },
      privateKeyEncoding: { type: 'pkcs8', format: 'pem' },
    })
    secretKey = privateKey
    publicKeyPem = publicKey
  }
  return publicKeyPem
}
function decryptSecret(encoded) {
  if (!secretKey) throw new Error('密钥已失效，请刷新页面后重试')
  const plain = privateDecrypt(
    { key: secretKey, padding: cryptoConstants.RSA_PKCS1_OAEP_PADDING, oaepHash: 'sha256' },
    Buffer.from(encoded, 'base64'),
  )
  const value = plain.toString('utf8')
  secretKey = null
  publicKeyPem = null
  return value
}

function text(value) {
  return typeof value === 'string' ? value : JSON.stringify(value, null, 2)
}

function statusSummary() {
  const config = readConfig()
  const state = readState()
  const today = dayKey()
  return {
    account: state.account ?? null,
    passwordSaved: null,
    projects: state.projects ?? [],
    projectsCount: state.projects?.length ?? 0,
    projectsSyncedAt: state.projectsSyncedAt ?? null,
    backfillDays: listBackfillableDays(config.backfill?.days ?? 7).map((date) => dayKey(date)),
    today,
    filedToday: findSubmission(today) ?? null,
    defaultPlan: config.defaultPlan,
    schedule: config.schedule,
    scheduleGate: shouldFire(config),
    submitEnabled: Boolean(config.submit?.enabled),
    ask: config.ask,
    launchd: launchd.status().installed,
    version: currentVersion(),
  }
}

async function opStatus() {
  const summary = statusSummary()
  summary.passwordSaved = summary.account ? await hasPassword(summary.account) : false
  summary.scheduleInstalled = (await launchd.query().catch(() => ({ installed: summary.launchd }))).installed
  summary.platform = process.platform
  summary.daysCacheAt = readState().daysCache?.at ?? null
  // The page paints from this: the cached calendar read, else the plain window.
  const cached = cachedDayStates()
  const configured = readConfig()
  summary.days = cached?.days ?? listBackfillableDays(configured.backfill?.days ?? 7).map((date) => ({ date: dayKey(date), filed: false, dot: null, disabled: false }))
  summary.daysStale = cached ? cached.stale : true
  return summary
}

// Account and password are typed into native dialogs: the macOS secure field
// hides the password, and the value goes straight into the keychain.
async function opSetupAccount(creds) {
  if (creds && typeof creds.account === 'string' && creds.account.trim()) {
    const account = creds.account.trim()
    const password = typeof creds.secret === 'string' && creds.secret
      ? decryptSecret(creds.secret)
      : typeof creds.password === 'string' ? creds.password : ''
    if (!password || password.length < 4) return { ok: false, reason: '密码为空或太短' }
    await setPassword(account, password)
    updateState({ account })
    return { ok: true, account, passwordSaved: true, via: creds.secret ? 'page' : 'arguments' }
  }
  const state = readState()
  const account = await prompt({
    title: 'DSH 工时填报',
    message: '请输入工时填报系统的登录账号（工号或用户名）',
    defaultValue: state.account ?? '',
  })
  if (!account) return { ok: false, reason: '未输入账号' }
  const password = await prompt({
    title: 'DSH 工时填报',
    message: '请输入登录密码。密码写入 macOS 钥匙串，不会存成明文文件。',
    hidden: true,
  })
  if (!password || password.length < 4) return { ok: false, reason: '密码为空或太短' }
  await setPassword(account, password)
  updateState({ account })
  return { ok: true, account, passwordSaved: true }
}

// One call that answers "why did nothing happen" on a fresh machine.
async function opDiag() {
  const config = readConfig()
  const state = readState()
  const out = {
    version: currentVersion(),
    platform: process.platform,
    dataDir: files.state().replace(/[\\/][^\\/]+$/, ''),
    account: state.account ?? null,
    passwordSaved: state.account ? await hasPassword(state.account) : false,
    secretBackend: (await import('./core/keychain.mjs')).backend(),
  }
  try {
    out.chrome = findChrome()
  } catch (error) {
    out.chrome = `未找到：${error.message}`
  }
  try {
    out.playwright = Boolean(await import('playwright-core'))
  } catch (error) {
    out.playwright = `未加载：${error.message}`
  }
  if (process.platform === 'win32') {
    out.powershell = { path: powershellPath(), ...(await powershellWorks()) }
  } else if (process.platform === 'darwin') {
    out.osascript = await new Promise((resolve) => {
      execFile('osascript', ['-e', 'return 1'], (error) => resolve(!error))
    })
  }
  out.schedule = await launchd.query().catch((error) => ({ error: error.message }))
  out.scheduleEnabled = Boolean(config.schedule?.enabled)
  return out
}

// Removes everything this machine holds about the user: the stored password,
// the account, the project cache, the browser profile (its cookies are a login),
// screenshots and history. The plugin goes back to a fresh install.
async function opReset(ctx) {
  const state = readState()
  const removed = []
  if (state.account) {
    await deletePassword(state.account)
    removed.push('钥匙串密码')
  }
  updateState({ account: null, projects: [], projectsSyncedAt: null, daysCache: null, run: null, lastRun: null })
  removed.push('账号与项目缓存')

  writeConfig({
    defaultPlan: [],
    defaultContent: '项目投入',
    schedule: { enabled: false, kind: 'weekday', time: '09:05' },
    ask: { mode: 'ask', timeoutMinutes: 10, remindEveryMinutes: 30 },
    submit: { enabled: false },
  })
  await saveToEntry(ctx, {
    defaultPlan: [],
    defaultContent: '项目投入',
    schedule: { enabled: false, kind: 'weekday', time: '09:05' },
    ask: { mode: 'ask', timeoutMinutes: 10, remindEveryMinutes: 30 },
    submit: { enabled: false },
  })
  removed.push('默认组合与定时配置')

  for (const target of [files.chromeProfile(), files.history(), files.explore()]) {
    try {
      fs.rmSync(target, { recursive: true, force: true })
      fs.mkdirSync(target, { recursive: true, mode: 0o700 })
    } catch {
      // best effort
    }
  }
  removed.push('浏览器登录态、截图与历史记录')

  await launchd.uninstall().catch(() => {})
  return { ok: true, removed }
}

async function opSyncProjects() {
  const projects = await withSession((page) => syncProjects(page))
  updateState({ projects, projectsSyncedAt: new Date().toISOString() })
  return { ok: true, count: projects.length, projects }
}

async function opFile({ date, plan, dryRun = false, skipIfFiled = true }) {
  const config = readConfig()
  const rows = validatePlan(plan ?? config.defaultPlan, config.defaultContent)
  const target = date ? new Date(`${date}T00:00:00`) : new Date()
  return runDay({ date: target, plan: rows, dryRun, skipIfFiled })
}

// Progress for the batch the settings page starts; the page polls this.
let backfillJob = { running: false, total: 0, done: 0, current: null, results: [], startedAt: null, finishedAt: null, dryRun: null }

async function opBackfillStatus() {
  return { ...backfillJob }
}

function startBackfill({ dates, plan, dryRun }) {
  if (backfillJob.running) return { ok: false, busy: true, reason: '已经在补填，请等当前批次结束', job: { ...backfillJob } }
  const list = Array.isArray(dates) ? dates.filter(Boolean) : []
  if (!list.length) throw new Error('dates 不能为空')
  const config = readConfig()
  const rows = validatePlan(plan ?? config.defaultPlan, config.defaultContent)
  for (const value of list) assertBackfillable(new Date(`${value}T00:00:00`), config.backfill?.days ?? 7)

  backfillJob = { running: true, total: list.length, done: 0, current: list[0], results: [], startedAt: new Date().toISOString(), finishedAt: null, dryRun: dryRun ?? !config.submit?.enabled }

  void (async () => {
    try {
      const results = await runBackfillBatch({
        dates: list,
        plan: rows,
        dryRun: backfillJob.dryRun,
        onProgress: ({ index, date }) => {
          backfillJob.done = index
          backfillJob.current = date
        },
      })
      backfillJob.results = results
      const failed = results.filter((row) => !row.ok).length
      await notify('DSH 工时填报', `补填完成：${results.length - failed} 个成功，${failed} 个失败`, { sound: true })
    } catch (error) {
      backfillJob.results = [{ error: error.message }]
      await notify('DSH 工时填报', `补填中断：${error.message}`)
    } finally {
      backfillJob.running = false
      backfillJob.current = null
      backfillJob.finishedAt = new Date().toISOString()
    }
  })()

  return { ok: true, started: true, total: list.length, dryRun: backfillJob.dryRun }
}

function resultView(rows) {
  const succeeded = rows.filter((row) => row.ok && !row.skipped).length
  const skipped = rows.filter((row) => row.skipped).length
  const failed = rows.filter((row) => !row.ok).length
  return {
    type: 'stack',
    children: [
      { type: 'metric', label: '成功', value: String(succeeded), tone: succeeded ? 'good' : undefined },
      { type: 'metric', label: '已填报跳过', value: String(skipped) },
      { type: 'metric', label: '失败', value: String(failed), tone: failed ? 'bad' : 'good' },
      {
        type: 'table',
        columns: [{ key: 'date', label: '日期' }, { key: 'result', label: '结果' }],
        rows: rows.map((row) => [
          String(row.date ?? ''),
          row.skipped ? '已填报，跳过' : row.ok ? '完成' : `失败：${String(row.message ?? '').slice(0, 60)}`,
        ]),
      },
    ],
  }
}

async function opBackfill({ dates, plan, dryRun = false }) {
  const config = readConfig()
  const rows = validatePlan(plan ?? config.defaultPlan, config.defaultContent)
  if (!Array.isArray(dates) || dates.length === 0) throw new Error('dates 不能为空')
  const results = []
  for (const value of dates) {
    const date = new Date(`${value}T00:00:00`)
    assertBackfillable(date, config.backfill?.days ?? 7)
    results.push({ date: value, ...(await runDay({ date, plan: rows, dryRun, skipIfFiled: true })) })
  }
  return { ok: results.every((row) => row.ok || row.skipped), results, view: resultView(results) }
}

// Both stores are written: config.json (what the launchd runner reads) and the
// Cordis entry config (what the settings page binds to). Writing only one would
// make the page show something different from what the schedule actually uses.
async function saveToEntry(ctx, patch) {
  const entry = ctx?.fiber?.entry
  const editor = ctx?.get?.('configEditor')
  if (!entry || !editor) return { saved: false, reason: '当前 profile 不能保存插件配置' }
  try {
    await editor.edit(entry, (current) => ({ ...current, ...patch }))
    return { saved: true }
  } catch (error) {
    return { saved: false, reason: error?.message ?? String(error) }
  }
}

async function opConfigure(patch, ctx) {
  const next = { ...(patch ?? {}) }
  if (next.defaultPlan) {
    next.defaultPlan = validatePlan(next.defaultPlan, next.defaultContent ?? readConfig().defaultContent)
  }
  const config = writeConfig(next)
  const entryPatch = {}
  for (const key of ['defaultContent', 'defaultPlan', 'schedule', 'ask', 'submit', 'update']) {
    if (next[key] !== undefined) entryPatch[key] = config[key]
  }
  const entryResult = Object.keys(entryPatch).length ? await saveToEntry(ctx, entryPatch) : { saved: false }
  return { ok: true, config, entry: entryResult }
}

async function opCheckUpdate() {
  const config = readConfig()
  const result = await checkForUpdate(config.update?.manifestUrl ?? DEFAULT_MANIFEST)
  const { manifest, ...rest } = result
  return rest
}

async function opUpdate(ctx) {
  const config = readConfig()
  const check = await checkForUpdate(config.update?.manifestUrl ?? DEFAULT_MANIFEST)
  if (!check.newer) return { ok: true, upToDate: true, current: check.current }

  const directSpec = installSpec(check.manifest)
  let password = null
  if (!directSpec && check.encrypted) {
    password = await getPassword('__download__')
    if (!password) {
      password = await prompt({
        title: 'DSH 工时填报',
        message: `安装 v${check.latest} 需要下载密码（输一次会记在钥匙串里）。`,
        hidden: true,
      })
      if (password) await setPassword('__download__', password)
    }
    if (!password) throw new Error('没有下载密码，更新已取消')
  }

  const manager = ctx?.get?.('pluginManager')
  if (typeof manager?.installBundle !== 'function') throw new Error('这个 profile 没有插件管理器，无法自更新')
  const spec = directSpec ?? `file:${await downloadPackage(check.manifest, password)}`
  let installed = await manager.installBundle(spec)
  // A fixed channel URL keeps the same spec across versions; the manager refuses
  // to reinstall a package the profile already depends on, so drop it first.
  if (installed?.error?.code === 'already-installed' && typeof manager.removeBundle === 'function') {
    const removed = await manager.removeBundle('dsh-workhour-filler')
    if (!removed?.error) installed = await manager.installBundle(spec)
  }
  return {
    ok: !installed?.error,
    from: check.current,
    to: check.latest,
    error: installed?.error ?? null,
    result: installed ?? null,
    restart: '安装已完成，重启 DeepSeek Harness 后运行新版本',
  }
}

async function opSchedule({ action = 'status' }) {
  if (action === 'install') {
    const result = await launchd.install(PLUGIN_ROOT)
    updateState({ lastScheduleInstall: new Date().toISOString() })
    return { ok: true, ...result }
  }
  if (action === 'uninstall') return { ok: true, ...(await launchd.uninstall()) }
  return { ok: true, ...(await launchd.query().catch(() => launchd.status())), path: launchd.status().path }
}

function toolDefs(ctx) {
  return [
    defineTool({
      name: 'workhour_status',
      description: '查看工时填报状态：账号、项目列表、今天是否已提交、默认组合、定时规则、可用补填日期。DS Bot 里需要让用户确认时，用 show_view 的表格或 options 卡片展示结果。',
      parameters: {},
      output: { schema: { type: 'string' }, render: (_args, value) => [{ type: 'text', text: value }] },
      async execute() {
        return JSON.stringify(await opStatus(), null, 2)
      },
    }),
    defineTool({
      name: 'workhour_setup',
      description: '首次配置：弹出 macOS 系统对话框让用户输入账号和密码（密码隐藏输入，写入钥匙串，不进聊天记录）。DS Bot 里同样可用，不要在聊天里问密码。',
      parameters: {},
      output: { schema: { type: 'string' }, render: (_args, value) => [{ type: 'text', text: value }] },
      async execute() {
        return JSON.stringify(await opSetupAccount(), null, 2)
      },
    }),
    defineTool({
      name: 'workhour_diag',
      description: '诊断：检查密码存储、Chrome、playwright、系统对话框能力、定时任务状态，用于排查「点了没反应」。',
      parameters: {},
      output: { schema: { type: 'string' }, render: (_args, value) => [{ type: 'text', text: value }] },
      async execute() {
        return JSON.stringify(await opDiag(), null, 2)
      },
    }),
    defineTool({
      name: 'workhour_sync_projects',
      description: '登录内部系统并重新读取本人可填报的项目列表，保存到本地。',
      parameters: {},
      output: { schema: { type: 'string' }, render: (_args, value) => [{ type: 'text', text: value }] },
      async execute() {
        return JSON.stringify(await opSyncProjects(), null, 2)
      },
    }),
    defineTool({
      name: 'workhour_file',
      description:
        '为某一天填报工时。不传 date 即今天；不传 plan 用默认组合。plan 是 [{project, percent, content}]，percent 为 1~100 的整数且合计必须等于 100，项目不能重复。dryRun 只填表不提交。DS Bot 里要用户自定义时，先用 show_view 的 form/options 卡片收集项目和占比，再调这个工具。',
      parameters: {
        date: { type: 'string', description: 'YYYY-MM-DD，默认今天' },
        plan: { type: 'json', description: '填报组合数组' },
        dryRun: { type: 'boolean', description: '只走流程不提交' },
        skipIfFiled: { type: 'boolean', description: '当天已提交则跳过，默认 true' },
      },
      output: { schema: { type: 'string' }, render: (_args, value) => [{ type: 'text', text: value }] },
      async execute(args) {
        const result = await opFile(args)
        return JSON.stringify(
          {
            ...result,
            view: {
              type: 'metric',
              label: result.dryRun ? '已填好，未提交' : result.ok ? '已提交' : '失败',
              value: String(result.date ?? ''),
              tone: result.ok ? 'good' : 'bad',
              caption: String(result.message ?? ''),
            },
          },
          null,
          2,
        )
      },
    }),
    defineTool({
      name: 'workhour_backfill',
      description: '补填：给出当月内的多个日期，按默认组合或给定 plan 依次填报，已填过的日期自动跳过。DS Bot 里先用 show_view 的 options 卡片（multi）让用户挑日期。',
      parameters: {
        dates: { type: 'array', items: { type: 'string' }, description: 'YYYY-MM-DD 列表，仅限当月' },
        plan: { type: 'json', description: '填报组合数组' },
        dryRun: { type: 'boolean', description: '只走流程不提交' },
      },
      output: { schema: { type: 'string' }, render: (_args, value) => [{ type: 'text', text: value }] },
      async execute(args) {
        return JSON.stringify(await opBackfill(args), null, 2)
      },
    }),
    defineTool({
      name: 'workhour_bot_form',
      description:
        '在 DS Bot 里给用户弹出配置卡片：返回一个 deep-view 表单规格，把它原样交给 show_view 即可（Bot 里没有网页设置页）。用户提交后按 next 里的说明调用 workhour_configure。',
      parameters: {},
      output: { schema: { type: 'string' }, render: (_args, value) => [{ type: 'text', text: value }] },
      async execute() {
        const config = readConfig()
        const plan = (config.defaultPlan ?? []).map((row) => `${row.project} ${row.percent}`).join('\n')
        const state = readState()
        return JSON.stringify(
          {
            view: {
              type: 'form',
              id: 'workhour-config',
              title: '工时填报配置',
              fields: [
                { id: 'content', label: '默认工作内容', value: config.defaultContent ?? '项目投入', placeholder: '可留空，默认「项目投入」' },
                {
                  id: 'plan',
                  label: '默认组合',
                  value: plan,
                  multiline: true,
                  placeholder: '每行一个：项目名 占比\n例如 示例项目A 100',
                },
                {
                  id: 'schedule',
                  label: '定时',
                  value: config.schedule?.enabled ? `${config.schedule.kind === 'daily' ? '每天' : '工作日'} ${config.schedule.time ?? '09:05'}` : '关闭',
                  placeholder: '工作日 09:05 / 每天 09:05 / 关闭',
                },
                { id: 'submit', label: '允许真实提交', value: config.submit?.enabled ? '是' : '否', placeholder: '是 / 否' },
              ],
              submitLabel: '保存',
            },
            next:
              '用户提交后：plan 按每行「项目名 占比」拆成 [{project, percent}]，占比合计必须 100；schedule 解析成 {enabled, kind: weekday|daily, time: "HH:mm"}；submit 为「是」时 {enabled:true}。把这些交给 workhour_configure 保存。',
            account: state.account ?? null,
            projects: state.projects ?? [],
          },
          null,
          2,
        )
      },
    }),
    defineTool({
      name: 'workhour_bot_backfill',
      description:
        'DS Bot 里补填用：返回一个多选卡片（只列可填的日期）。把 view 交给 show_view，用户选完后把日期交给 workhour_backfill，再用 show_view 画出它返回的 view。',
      parameters: {},
      output: { schema: { type: 'string' }, render: (_args, value) => [{ type: 'text', text: value }] },
      async execute() {
        const config = readConfig()
        const cached = cachedDayStates()
        const days = cached?.days ?? listBackfillableDays(config.backfill?.days ?? 7).map((date) => ({ date: dayKey(date), filed: false, dot: null }))
        const open = days.filter((day) => !day.filed && !day.disabled)
        const closed = days.filter((day) => day.filed)
        if (!open.length) {
          return JSON.stringify({ view: { type: 'callout', text: `没有可补填的日期。已填报：${closed.map((d) => d.date.slice(5)).join('、')}`, tone: 'good' } }, null, 2)
        }
        return JSON.stringify(
          {
            view: {
              type: 'options',
              id: 'workhour-backfill',
              multi: true,
              options: open.map((day) => ({
                label: day.date,
                description: `${day.disabled ? '系统未开放' : '可补填'}${day.dot ? ` · ${day.dot}` : ''}`,
              })),
            },
            filed: closed.map((day) => day.date),
            next:
              '用户选中的日期直接来自 label（YYYY-MM-DD）。把它们交给 workhour_backfill {dates:[...]}；拿回结果后，用 show_view 把结果里的 view 画出来，并在文字里说清哪几天成功、哪几天跳过。',
          },
          null,
          2,
        )
      },
    }),
    defineTool({
      name: 'workhour_check_update',
      description: '检查插件是否有新版本（读取公开下载站的 latest.json，只读，不安装）。',
      parameters: {},
      output: { schema: { type: 'string' }, render: (_args, value) => [{ type: 'text', text: value }] },
      async execute() {
        return JSON.stringify(await opCheckUpdate(), null, 2)
      },
    }),
    defineTool({
      name: 'workhour_update',
      description: '把插件更新到最新版本：下载加密安装包（需要时在对话框里输入下载密码）、解密、交给 DSH 插件管理器安装，装完需要重启 DSH。',
      parameters: {},
      output: { schema: { type: 'string' }, render: (_args, value) => [{ type: 'text', text: value }] },
      async execute() {
        return JSON.stringify(await opUpdate(ctx), null, 2)
      },
    }),
    defineTool({
      name: 'workhour_days',
      description: '查看当月可补填窗口内每一天是否已填报（读系统日历上的标记点），用于决定补填哪些日期。',
      parameters: {},
      output: { schema: { type: 'string' }, render: (_args, value) => [{ type: 'text', text: value }] },
      async execute() {
        return JSON.stringify({ days: await dayStates() }, null, 2)
      },
    }),
    defineTool({
      name: 'workhour_configure',
      description:
        '修改插件配置（DS Bot 里先 show_view 表单收集，再原样传进来）：defaultPlan（默认组合）、defaultContent（默认工作内容）、schedule（{enabled,kind:weekday|daily,time:"09:05"}）、ask（{mode:"ask"|"auto",timeoutMinutes,remindEveryMinutes}）。',
      parameters: {
        defaultPlan: { type: 'json', description: '默认组合数组' },
        defaultContent: { type: 'string' },
        schedule: { type: 'json' },
        ask: { type: 'json' },
        submit: { type: 'json', description: '{enabled:boolean} 是否允许真的点提交，默认 false' },
      },
      output: { schema: { type: 'string' }, render: (_args, value) => [{ type: 'text', text: value }] },
      async execute(args) {
        return JSON.stringify(await opConfigure(args, ctx), null, 2)
      },
    }),
    defineTool({
      name: 'workhour_schedule',
      description: '安装、卸载或查看 macOS 定时任务（launchd LaunchAgent）。',
      parameters: { action: { type: 'string', enum: ['install', 'uninstall', 'status'] } },
      output: { schema: { type: 'string' }, render: (_args, value) => [{ type: 'text', text: value }] },
      async execute(args) {
        return JSON.stringify(await opSchedule(args), null, 2)
      },
    }),
    defineTool({
      name: 'workhour_history',
      description: '查看最近填报记录，以及今天是否已提交。',
      parameters: { limit: { type: 'number' } },
      output: { schema: { type: 'string' }, render: (_args, value) => [{ type: 'text', text: value }] },
      async execute(args) {
        return JSON.stringify({ today: dayKey(), entries: history(Number(args.limit ?? 20)) }, null, 2)
      },
    }),
  ]
}

async function dispatch(line, ctx) {
  const [sub, ...rest] = line.trim().split(/\s+/)
  const json = (() => {
    const raw = rest.join(' ')
    if (!raw) return undefined
    try {
      return JSON.parse(raw)
    } catch {
      return undefined
    }
  })()

  switch (sub) {
    case undefined:
    case '':
    case 'status':
      return opStatus()
    case 'setup':
      return opSetupAccount(json)
    case 'key':
      return { publicKey: ensureKeyPair() }
    case 'diag':
      return opDiag()
    case 'reset':
      return opReset(ctx)
    case 'sync':
      return opSyncProjects()
    case 'file':
      return opFile(json ?? {})
    case 'backfill':
      return startBackfill(json ?? {})
    case 'backfill-status':
      return opBackfillStatus()
    case 'days':
      return { days: await dayStates({ force: json?.force === true }) }
    case 'config':
      return json ? opConfigure(json, ctx) : readConfig()
    case 'schedule':
      return opSchedule(json ?? {})
    case 'update-check':
      return opCheckUpdate()
    case 'update':
      return opUpdate(ctx)
    case 'history':
      return { today: dayKey(), entries: history(20) }
    case 'days-plain':
      return { days: listBackfillableDays().map((date) => dayKey(date)) }
    case 'run':
      return runScheduled({ force: true })
    default:
      throw new Error(`未知的子命令: ${sub}`)
  }
}

// Volatile fields are stable references; plain fields are snapshots. Reading
// both shapes keeps one mirror function working before and after an edit.
function live(config, key) {
  const field = config?.[key]
  if (field && typeof field.get === 'function') return field.get()
  return field
}

export function apply(ctx, config) {
  const log = ctx.logger('workhour')

  const mirrorToDisk = () => {
    try {
      const existing = readConfig()
      const plan = live(config, 'defaultPlan') ?? []
      const patch = {
        defaultContent: live(config, 'defaultContent') ?? existing.defaultContent,
        schedule: live(config, 'schedule') ?? existing.schedule,
        ask: live(config, 'ask') ?? existing.ask,
        submit: live(config, 'submit') ?? existing.submit,
        update: live(config, 'update') ?? existing.update,
      }
      // Another profile may own the plan (dsh web and desktop share one file);
      // an empty form must not wipe a plan that is already saved.
      if (plan.length > 0 || !(existing.defaultPlan?.length > 0)) patch.defaultPlan = plan
      writeConfig(patch)
    } catch (error) {
      log.error('配置镜像失败：%s', error?.message ?? error)
    }
  }
  mirrorToDisk()
  ctx.on('loader/volatile-update', () => mirrorToDisk())

  ctx.effect(() => {
    const disposers = []
    for (const definition of toolDefs(ctx)) {
      disposers.push(ctx.tools.register(definition))
    }
    return () => {
      for (const dispose of disposers.reverse()) {
        try {
          dispose()
        } catch {
          // already gone
        }
      }
    }
  }, 'workhour: tools')

  ctx.effect(
    () =>
      ctx.commands.register({
        name: NS,
        description: '工时填报：状态、同步项目、执行、补填、配置、定时任务',
        handler: async (invocation) => {
          try {
            // The Host hands a command its arguments in rawInput; `line` holds the
            // whole "/workhour ..." only for some callers. Reading rawInput first
            // is what makes "/workhour key" arrive as "key" instead of "".
            const rawInput = typeof invocation?.rawInput === 'string' ? invocation.rawInput.trim() : ''
            const line = typeof invocation?.line === 'string' ? invocation.line : `/${NS}`
            const body = rawInput || line.replace(/^\/workhour\s*/, '')
            const result = await dispatch(body, ctx)
            return { kind: 'success', text: text(result) }
          } catch (error) {
            log.error('%s', error?.message ?? error)
            return { kind: 'error', text: error?.message ?? String(error) }
          }
        },
      }),
    'workhour: command',
  )

  log.info('工时填报插件已加载（账号：%s）', readState().account ?? '未配置')
}
