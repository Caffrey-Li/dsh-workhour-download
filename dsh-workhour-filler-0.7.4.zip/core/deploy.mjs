// The scheduled job must not depend on where DSH happened to install the
// plugin: pnpm keeps packages in a content-addressed store, and a profile
// reinstall moves them. A launchd job therefore runs a copy under
// ~/Library/Application Support, refreshed every time the schedule is installed.
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { createRequire } from 'node:module'

const COPY = ['bin', 'core', 'agents', 'package.json']

// The scheduled job must not depend on where DSH installed the plugin, so it
// runs a copy in the user's application-data folder on whichever system this is.
export function deployedRoot() {
  if (process.platform === 'win32') {
    const base = process.env.LOCALAPPDATA ?? path.join(os.homedir(), 'AppData', 'Local')
    return path.join(base, 'dsh-workhour', 'app')
  }
  if (process.platform === 'darwin') {
    return path.join(os.homedir(), 'Library', 'Application Support', 'dsh-workhour', 'app')
  }
  const base = process.env.XDG_DATA_HOME ?? path.join(os.homedir(), '.local', 'share')
  return path.join(base, 'dsh-workhour', 'app')
}

export function deploy(root) {
  let playwright
  try {
    playwright = path.dirname(createRequire(path.resolve(root, 'package.json')).resolve('playwright-core/package.json'))
  } catch (error) {
    throw new Error('定时任务缺少 Playwright，请重新安装完整插件包后再试。', { cause: error })
  }
  const target = deployedRoot()
  fs.rmSync(target, { recursive: true, force: true })
  fs.mkdirSync(target, { recursive: true, mode: 0o755 })

  for (const entry of COPY) {
    const from = path.join(root, entry)
    if (!fs.existsSync(from)) continue
    fs.cpSync(from, path.join(target, entry), { recursive: true })
  }

  // DSH may hoist Playwright beside the plugin or link it into a pnpm store.
  fs.cpSync(playwright, path.join(target, 'node_modules', 'playwright-core'), { recursive: true, dereference: true })

  return target
}
