// The filing flow itself: sign in, pick a date, fill one or more project rows,
// submit, and read back what the site kept.
//
// Selectors come from the rendered Vant component tree (captured under
// ~/.dsh-workhour/explore/). They are deliberately structural — name attributes
// and Vant class names — instead of positional, because the site adds and
// removes cards without renaming anything.
import fs from 'node:fs'
import path from 'node:path'
import { files, isoDay, hhmm, timestamp } from './paths.mjs'
import { login, go, settle, capture, ROUTES, readToast } from './site.mjs'

const PROJECT_CARD = '.van-card'
const CELL = '.van-cell--clickable'

export async function ensureSignedIn(page, creds) {
  const result = await login(page, creds)
  if (!result.ok) {
    const reason = result.reason.replace(/^登录失败[：:]\s*/, '')
    if (/无角色|未分配角色/.test(reason)) {
      throw new Error('工时系统登录失败。当前账号没有角色，请联系工时系统管理员核查工时填报权限。')
    }
    const incorrect = /(?:密码|口令)(?:错误|不正确|有误)|(?:账号|用户名|用户)不存在/.test(reason)
    const hint = incorrect ? '（点「修改」重新输入账号密码后重试）' : ''
    throw new Error(`登录失败：${reason}${hint}`)
  }
  return result
}

// --- projects -------------------------------------------------------------

export async function syncProjects(page) {
  await go(page, ROUTES.addDay)
  await settle(page, 1000)
  await openProjectPicker(page, 0)
  const projects = await page.locator('.van-picker-column__item .van-ellipsis').allInnerTexts()
  await cancelPicker(page)
  const unique = [...new Set(projects.map((name) => name.trim()).filter(Boolean))]
  if (!unique.length) throw new Error('项目列表为空：项目选择器里没有读到任何项目')
  return unique
}

function projectCard(page, index) {
  return page.locator(PROJECT_CARD, { hasText: '项目信息' }).nth(index)
}

async function openProjectPicker(page, index) {
  await projectCard(page, index).locator('input[name="projectName"]').click()
  await page.waitForSelector('.van-picker__confirm', { state: 'visible' })
  await settle(page, 400)
}

async function chooseProject(page, name) {
  const item = page.locator('.van-picker-column__item').getByText(name, { exact: true }).first()
  if (!(await item.count())) throw new Error(`项目选择器里没有「${name}」`)
  await item.click()
  await settle(page, 300)
  await page.locator('.van-picker__confirm').click()
  await settle(page, 500)
}

async function cancelPicker(page) {
  await page.locator('.van-picker__cancel').click().catch(() => {})
  await settle(page, 300)
}

// --- date -----------------------------------------------------------------

export async function openCalendar(page) {
  await page.locator(CELL, { hasText: '填报日期' }).first().click()
  await page.waitForSelector('.van-calendar__days', { state: 'visible' })
  await settle(page, 500)
}

// The grid also renders the tail of the previous month and the head of the
// next one, so a bare day number is ambiguous. Day 1 is the cell carrying an
// inline margin-left; every later day follows it in DOM order.
async function dayOneOffset(page) {
  return page.evaluate(() => {
    const cells = [...document.querySelectorAll('.van-calendar__month .van-calendar__day')]
    const index = cells.findIndex((cell) => cell.style && cell.style.marginLeft)
    return index === -1 ? 0 : index
  })
}

export async function pickDay(page, date) {
  const target = date instanceof Date ? date : new Date(`${date}T00:00:00`)
  const day = target.getDate()
  const offset = await dayOneOffset(page)
  const cell = page.locator('.van-calendar__month .van-calendar__day').nth(offset + day - 1)
  if (!(await cell.count())) throw new Error(`日历里没有 ${day} 号`)
  if ((await cell.getAttribute('class') ?? '').includes('disabled')) {
    throw new Error(`日历里的 ${day} 号不可选（可能超出可填报范围）`)
  }
  await cell.click()
  await settle(page, 600)
  const value = await page.locator('input[name="reportingDateTime"]').inputValue()
  const parts = value.trim().match(/^(\d{4})[-/.年](\d{1,2})[-/.月](\d{1,2})(?:日)?$/)
  if (!parts || Number(parts[1]) !== target.getFullYear() || Number(parts[2]) !== target.getMonth() + 1 || Number(parts[3]) !== day) {
    throw new Error(`填报日期没有写入（字段值为「${value}」）`)
  }
  return value
}

// Days the site already shows a coloured dot for: `approved` means the day was
// filed and approved, any other dot class means filed but still in process.
export async function calendarMarks(page) {
  await go(page, ROUTES.addDay)
  await openCalendar(page)
  const marks = await page.evaluate(() => {
    const month = document.querySelector('.van-calendar__month')
    const cells = [...(month?.querySelectorAll('.van-calendar__day') ?? [])]
    const start = cells.findIndex((cell) => cell.style && cell.style.marginLeft)
    const out = {}
    for (const cell of cells.slice(start === -1 ? 0 : start)) {
      const day = parseInt(cell.textContent, 10)
      if (!Number.isFinite(day)) continue
      if (out[day] !== undefined) break
      const dot = cell.querySelector('.status-box .dot')
      out[day] = {
        disabled: cell.classList.contains('van-calendar__day--disabled'),
        dot: dot ? [...dot.classList].filter((name) => name !== 'dot').join(' ') || 'filed' : null,
      }
      if (day >= 31) break
    }
    return out
  })
  const close = page.locator('.van-popup__close-icon:visible').first()
  if (await close.isVisible()) await close.click()
  await settle(page, 400)
  return marks
}

// --- rows -----------------------------------------------------------------

export function validatePlan(plan) {
  if (!Array.isArray(plan) || plan.length === 0) throw new Error('至少需要一个项目')
  const seen = new Set()
  let total = 0
  for (const [index, row] of plan.entries()) {
    const name = String(row.project ?? '').trim()
    if (!name) throw new Error(`第 ${index + 1} 行没有选择项目`)
    if (seen.has(name)) throw new Error(`项目「${name}」重复了，同一个项目只能填一次`)
    seen.add(name)
    const percent = Number(row.percent)
    if (!Number.isInteger(percent) || percent < 1 || percent > 100) {
      throw new Error(`第 ${index + 1} 行的投入百分比必须是 1~100 的整数`)
    }
    total += percent
    if (String(row.content ?? '').trim() === '' && !String(row.content ?? '').length) {
      throw new Error(`第 ${index + 1} 行的工作内容不能为空（可以填空格）`)
    }
    if (String(row.content ?? '').length > 2000) throw new Error(`第 ${index + 1} 行的工作内容超过 2000 字`)
  }
  if (total !== 100) throw new Error(`所有项目投入百分比合计必须等于 100，当前为 ${total}`)
  return plan
}

async function ensureRowCount(page, count) {
  const current = await page.locator(PROJECT_CARD, { hasText: '项目信息' }).count()
  for (let index = current; index < count; index += 1) {
    await page.locator('button.add-btn').first().click()
    await settle(page, 500)
  }
  const after = await page.locator(PROJECT_CARD, { hasText: '项目信息' }).count()
  if (after < count) throw new Error(`点「添加更多」后只有 ${after} 个项目行，需要 ${count} 行`)
}

export async function fillPlan(page, plan) {
  validatePlan(plan)
  await ensureRowCount(page, plan.length)
  for (const [index, row] of plan.entries()) {
    const card = projectCard(page, index)
    await openProjectPicker(page, index)
    await chooseProject(page, String(row.project).trim())
    const chosen = await card.locator('input[name="projectName"]').inputValue()
    if (chosen.trim() !== String(row.project).trim()) throw new Error(`第 ${index + 1} 行项目没有正确写入`)
    await card.locator('input[name="workTimePercent"]').fill(String(row.percent))
    await card.locator('textarea[name="workContent"]').fill(String(row.content))
    await settle(page, 200)
  }
}

async function pageIsBlank(page) {
  return page.evaluate(() => {
    const body = document.body
    if (!body) return true
    return (body.innerText ?? '').trim().length === 0 && body.children.length === 0
  }).catch(() => false)
}

const submitQuestion = /(?:确认|确定|是否|要不要).{0,12}(?:提交|保存).*[？?]|(?:是否|确认|确定).{0,12}(?:提交|保存)(?:工时|填报)?[。！!]?\s*$/

export async function submit(page) {
  const controls = page.locator('.button-fixed-container button:visible')
  const named = controls.filter({ hasText: /^\s*(?:提交(?:工时|填报)?|确认提交|保存并提交)\s*$/ })
  const button = (await named.count()) ? named : controls
  try {
    await button.click({ trial: true, timeout: 8000 })
  } catch (error) {
    return { message: `提交按钮不可点击：${error.message.split('\n')[0]}`, retryable: true }
  }

  let confirmed = false
  let dialogMessage = ''
  const onDialog = async (dialog) => {
    dialogMessage = dialog.message()
    if (!confirmed && dialog.type() === 'confirm' && submitQuestion.test(dialogMessage)) {
      confirmed = true
      dialogMessage = ''
      await dialog.accept().catch(() => {})
    } else {
      await dialog.dismiss().catch(() => {})
    }
  }
  page.on('dialog', onDialog)
  try {
    await button.click({ timeout: 8000 })
    const deadline = Date.now() + 20_000
    while (Date.now() < deadline) {
      if (dialogMessage) return { message: dialogMessage }
      if (page.isClosed() || await pageIsBlank(page)) {
        return { message: '提交后页面已关闭或清空', blanked: true }
      }
      if (new URL(page.url()).hash !== ROUTES.addDay) {
        return { message: '提交后页面已跳转' }
      }
      const dialog = page.locator('.van-dialog:visible', { hasText: submitQuestion })
      const confirm = dialog.locator('.van-dialog__confirm')
      if (!confirmed && await confirm.isVisible() && await dialog.locator('.van-dialog__cancel').isVisible()) {
        confirmed = true
        await confirm.click({ timeout: 8000 })
      } else {
        const toast = await readToast(page)
        if (toast && !submitQuestion.test(toast) && !/提交中|保存中|加载中|请稍候/.test(toast)) {
          const rejected = !/关闭窗口失败/.test(toast) && /失败|错误|为空|必填|无权|不允许|已填报|请填写|请先/.test(toast)
          return { message: `站点提示「${toast}」`, rejected }
        }
      }
      await page.waitForTimeout(250)
    }
    return { message: '点击提交后 20 秒内未收到明确结果' }
  } catch (error) {
    return { message: `提交阶段中断：${error.message.split('\n')[0]}` }
  } finally {
    page.off('dialog', onDialog)
  }
}

async function verifySubmission(context, date) {
  const check = await context.newPage()
  const day = Number(date.slice(-2))
  check.setDefaultTimeout(10_000)
  try {
    const marks = await calendarMarks(check)
    if (marks[day]?.dot) return true
    await check.waitForTimeout(1000)
    await check.reload({ waitUntil: 'domcontentloaded' })
    await settle(check)
    return Boolean((await calendarMarks(check))[day]?.dot)
  } finally {
    await check.close().catch(() => {})
  }
}

// --- one complete filing --------------------------------------------------

export async function fileDay({ page, date, plan, submitIt = true, label = 'run', onStep }) {
  const step = (name) => { try { onStep?.(name) } catch { /* 回调不该影响填报 */ } }

  step('open')
  await go(page, ROUTES.addDay)
  await settle(page, 1000)
  // A fresh page can carry rows from an earlier click in the same session.
  await page.reload({ waitUntil: 'domcontentloaded' })
  await settle(page, 1500)

  step('date')
  await openCalendar(page)
  await pickDay(page, date)

  step('fill')
  await fillPlan(page, plan)

  const shot = await capture(page, `${label}-filled`).catch(() => ({}))
  if (!submitIt) {
    step('done')
    return { ok: true, dryRun: true, screenshot: shot.shot, html: shot.html }
  }

  step('submit')
  const context = page.context()
  const result = await submit(page)
  const after = page.isClosed() ? shot : await capture(page, `${label}-submitted`).catch(() => shot)
  const filed = !result.retryable && await verifySubmission(context, date).catch(() => false)
  step('done')
  const message = filed
    ? '提交成功（系统日历上已标记）'
    : result.retryable ? result.message : `${result.message}。系统日历未确认，请核对后再试`
  const unconfirmed = !filed && !result.retryable && !result.rejected
  return { ok: filed, message, screenshot: after.shot, html: after.html, date, blanked: Boolean(result.blanked), retryable: Boolean(result.retryable), unconfirmed }
}

export function record(entry) {
  const line = { at: new Date().toISOString(), time: hhmm(), ...entry }
  fs.appendFileSync(files.history(), `${JSON.stringify(line)}\n`, { mode: 0o600 })
  return line
}

export { isoDay, timestamp }
