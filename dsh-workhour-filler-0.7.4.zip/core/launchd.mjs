// The scheduled job, on both systems.
//
// macOS:  a LaunchAgent that wakes the tick every five minutes.
// Windows: a Task Scheduler entry doing the same.
//
// The tick itself decides whether this wake-up should file anything, so the
// schedule in config.json can change without touching either registration.
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { execFile } from 'node:child_process'
import { promisify } from 'node:util'
import { deploy, deployedRoot } from './deploy.mjs'
import { nodeBinary } from './runtime.mjs'
import { files, home } from './paths.mjs'

const run = promisify(execFile)
export const LABEL = 'com.dsh.workhour'
export const WIN_TASK = 'DSH-Workhour-Filler'
const INTERVAL_SECONDS = 300

const isWindows = () => process.platform === 'win32'
const xml = (value) => value.replace(/[&<>]/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' })[char])

function agentsDir() {
  return path.join(os.homedir(), 'Library', 'LaunchAgents')
}

function plistPath() {
  return path.join(agentsDir(), `${LABEL}.plist`)
}

function tickPath(root = process.cwd()) {
  return path.join(root, 'bin', 'tick.mjs')
}

// --- Windows --------------------------------------------------------------

async function windowsCreate(deployed, node) {
  const wrapper = path.join(deployed, 'run-tick.cmd')
  const logDir = files.logs()
  fs.mkdirSync(logDir, { recursive: true })
  // Electron needs this flag to behave as node; a standalone node ignores it.
  fs.writeFileSync(
    wrapper,
    [
      '@echo off',
      'set ELECTRON_RUN_AS_NODE=1',
      `set "DSH_WORKHOUR_HOME=${home().replaceAll('%', '%%')}"`,
      `"${node}" "${path.join(deployed, 'bin', 'tick.mjs')}" >> "${path.join(logDir, 'task.out.log')}" 2>&1`,
      '',
    ].join('\r\n'),
    { mode: 0o644 },
  )
  // The task repeats every five minutes; tick decides what to do.
  await run('schtasks', ['/Create', '/F', '/IT', '/SC', 'MINUTE', '/MO', '5', '/TN', WIN_TASK, '/TR', `"${wrapper}"`])
  return wrapper
}

async function windowsStatus() {
  try {
    const { stdout } = await run('schtasks', ['/Query', '/TN', WIN_TASK, '/XML'], { encoding: 'buffer' })
    const task = stdout.toString(stdout.includes(0) ? 'utf16le' : 'utf8')
    const settings = task.match(/<Settings\b[^>]*>([\s\S]*?)<\/Settings>/i)?.[1] ?? ''
    return { installed: true, enabled: !/<Enabled>\s*false\s*<\/Enabled>/i.test(settings), path: WIN_TASK }
  } catch {
    return { installed: false, path: WIN_TASK }
  }
}

// --- public API -----------------------------------------------------------

export function status() {
  if (isWindows()) {
    // The synchronous face of the Windows check keeps callers simple; the
    // detailed answer comes from schtasks through `query()` when needed.
    return { installed: fs.existsSync(path.join(deployedRoot(), 'run-tick.cmd')), path: WIN_TASK, platform: 'win32' }
  }
  const file = plistPath()
  if (!fs.existsSync(file)) return { installed: false, path: file, platform: process.platform }
  return { installed: true, path: file, content: fs.readFileSync(file, 'utf8'), platform: process.platform }
}

export async function query() {
  if (process.platform === 'darwin') {
    const file = plistPath()
    const configured = fs.existsSync(file)
    try {
      const { stdout } = await run('launchctl', ['print', `gui/${process.getuid()}/${LABEL}`])
      const runs = stdout.match(/^\s*runs = (\d+)/m)?.[1]
      const exit = stdout.match(/^\s*last exit code = (-?\d+)/m)?.[1]
      return { installed: true, configured, path: file, runs: runs === undefined ? null : Number(runs),
        lastExitCode: exit === undefined ? null : Number(exit) }
    } catch {
      return { installed: false, configured, path: file }
    }
  }
  if (!isWindows()) return { installed: false, path: plistPath() }
  return windowsStatus()
}

export async function install(root) {
  const node = await nodeBinary()
  const deployed = deploy(root)
  const script = tickPath(deployed)
  if (!fs.existsSync(script)) throw new Error(`找不到 ${script}`)

  if (isWindows()) {
    const wrapper = await windowsCreate(deployed, node)
    return { installed: true, path: WIN_TASK, deployed, wrapper, platform: 'win32' }
  }

  const plist = `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key><string>${LABEL}</string>
  <key>ProgramArguments</key>
  <array>
    <string>${xml(node)}</string>
    <string>${xml(script)}</string>
  </array>
  <key>WorkingDirectory</key><string>${xml(deployed)}</string>
  <key>EnvironmentVariables</key>
  <dict>
    <key>PATH</key><string>/usr/local/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin</string>
    <key>ELECTRON_RUN_AS_NODE</key><string>1</string>
    <key>DSH_WORKHOUR_HOME</key><string>${xml(home())}</string>
  </dict>
  <key>StartInterval</key><integer>${INTERVAL_SECONDS}</integer>
  <key>RunAtLoad</key><false/>
  <key>StandardOutPath</key><string>${xml(path.join(files.logs(), 'launchd.out.log'))}</string>
  <key>StandardErrorPath</key><string>${xml(path.join(files.logs(), 'launchd.err.log'))}</string>
</dict>
</plist>
`
  fs.mkdirSync(agentsDir(), { recursive: true })
  fs.mkdirSync(files.logs(), { recursive: true, mode: 0o700 })
  fs.writeFileSync(plistPath(), plist, { mode: 0o644 })
  await run('launchctl', ['bootout', `gui/${process.getuid()}`, plistPath()]).catch(() => {})
  await run('launchctl', ['bootstrap', `gui/${process.getuid()}`, plistPath()])
  return { installed: true, path: plistPath(), deployed, platform: 'darwin' }
}

export async function uninstall() {
  if (isWindows()) {
    if ((await windowsStatus()).installed) await run('schtasks', ['/Delete', '/TN', WIN_TASK, '/F'])
    const wrapper = path.join(deployedRoot(), 'run-tick.cmd')
    try {
      fs.unlinkSync(wrapper)
    } catch {
      // already gone
    }
    return { installed: false, path: WIN_TASK, platform: 'win32' }
  }
  if (process.platform !== 'darwin') return { installed: false }
  await run('launchctl', ['bootout', `gui/${process.getuid()}`, plistPath()]).catch(() => {})
  if ((await query()).installed) throw new Error('macOS 未卸载系统任务，请检查当前账户的后台项目权限')
  if (fs.existsSync(plistPath())) fs.unlinkSync(plistPath())
  return { installed: false, path: plistPath(), platform: 'darwin' }
}
