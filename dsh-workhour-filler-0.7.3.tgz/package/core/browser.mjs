// One persistent, invisible automation browser per machine.
//
// The browser runs from the user's own Chrome binary but with a dedicated
// profile directory, so the user's open Chrome windows, tabs and sessions are
// never touched and no `--remote-debugging-port` restart is required.
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { ensureDirs, files, home } from './paths.mjs'

// Loaded lazily: a folder install without node_modules must still activate the
// plugin, so the settings page can explain what is missing instead of the whole
// bundle failing to import.
let chromium
async function loadPlaywright() {
  if (chromium) return chromium
  try {
    ;({ chromium } = await import('playwright-core'))
    return chromium
  } catch (error) {
    throw new Error(
      `缺少 playwright-core：${error?.message ?? error}\n` +
        'Windows 用户请重新下载 zip 安装包（里面已带 node_modules），解压后整个文件夹一起用，不要删掉其中的 node_modules。',
    )
  }
}

const UNIX_BROWSERS = [
  '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
  '/Applications/Chromium.app/Contents/MacOS/Chromium',
  '/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge',
  '/Applications/Brave Browser.app/Contents/MacOS/Brave Browser',
  '/usr/bin/google-chrome',
  '/usr/bin/chromium',
]

function installedBrowsers() {
  let defaults = UNIX_BROWSERS
  if (process.platform === 'win32') {
    const roots = [
      process.env.ProgramW6432 ?? process.env.ProgramFiles ?? 'C:\\Program Files',
      process.env['ProgramFiles(x86)'] ?? 'C:\\Program Files (x86)',
      process.env.LOCALAPPDATA,
    ].filter(Boolean)
    defaults = [
      ...roots.map((root) => path.win32.join(root, 'Google', 'Chrome', 'Application', 'chrome.exe')),
      ...roots.map((root) => path.win32.join(root, 'Microsoft', 'Edge', 'Application', 'msedge.exe')),
    ]
  }
  return [...new Set([process.env.CHROME_PATH, ...defaults].filter(Boolean))].filter((file) => {
    try {
      return fs.statSync(file).isFile()
    } catch {
      return false
    }
  })
}

const BROWSER_NOT_FOUND = '没有找到浏览器。请安装 Google Chrome 或 Microsoft Edge，或设置 CHROME_PATH。'

export function findChrome() {
  const [executable] = installedBrowsers()
  if (!executable) throw new Error(BROWSER_NOT_FOUND)
  return executable
}

// The internal site is a mobile-first Vant page; a phone-sized viewport keeps
// every control on the layout the design was made for.
export const VIEWPORT = { width: 430, height: 932 }

async function launchBrowser({ headless, slowMo }, probeDir) {
  const chromium = await loadPlaywright()
  const candidates = installedBrowsers()
  if (!candidates.length) throw new Error(BROWSER_NOT_FOUND)

  const windows = process.platform === 'win32'
  const attempts = []
  for (const executablePath of windows ? candidates : candidates.slice(0, 1)) {
    const filename = windows ? path.win32.basename(executablePath) : path.basename(executablePath)
    const edge = windows && filename.toLowerCase() === 'msedge.exe'
    const profile = probeDir ? path.join(probeDir, edge ? 'edge-profile' : 'chrome-profile')
      : edge ? files.edgeProfile() : files.chromeProfile()
    try {
      const context = await chromium.launchPersistentContext(profile, {
        executablePath,
        headless,
        slowMo,
        ...(windows ? { timeout: 20_000 } : {}),
        viewport: VIEWPORT,
        deviceScaleFactor: 2,
        locale: 'zh-CN',
        timezoneId: 'Asia/Shanghai',
        args: [
          '--no-first-run',
          '--no-default-browser-check',
          '--no-sandbox',
          '--disable-blink-features=AutomationControlled',
          '--hide-crash-restore-bubble',
        ],
      })
      return { context, executablePath, attempts }
    } catch (error) {
      const reason = String(error?.message ?? error)
        .replace(/\x1b\[[0-9;]*m/g, '').split(/\r?\n|Call log:/, 1)[0]
        .replace(/^browserType\.[^:]+:\s*/, '').trim()
      attempts.push({ browser: filename, reason })
    }
  }
  const reasons = attempts.map(({ browser, reason }) => `${browser}（${reason}）`).join('、')
  const hint = windows ? '请先从开始菜单打开浏览器。如果能手动打开，请让 IT 核查 DSH 启动浏览器的权限。' : ''
  throw Object.assign(new Error(`自动化浏览器启动失败。尝试了 ${reasons}。${hint}`), { attempts })
}

export async function probeBrowser() {
  let dir
  try {
    dir = fs.mkdtempSync(path.join(os.tmpdir(), 'workhour-browser-check-'))
    const { context, executablePath, attempts } = await launchBrowser({ headless: true, slowMo: 0 }, dir)
    await context.close()
    return { ok: true, executablePath, attempts }
  } catch (error) {
    return { ok: false, error: error.message, attempts: error.attempts ?? [] }
  } finally {
    if (dir) await fs.promises.rm(dir, { recursive: true, force: true, maxRetries: 2 }).catch(() => {})
  }
}

// One Chrome at a time: a second launch on the same profile fails with a lock
// error, which used to surface as an empty day list in the settings page.
const LOCK_WAIT_MS = 90_000

function lockFile() {
  return path.join(home(), 'browser.lock')
}

async function acquireLock() {
  const file = lockFile()
  const deadline = Date.now() + LOCK_WAIT_MS
  for (;;) {
    try {
      const fd = fs.openSync(file, 'wx')
      fs.writeSync(fd, JSON.stringify({ pid: process.pid, at: Date.now() }))
      fs.closeSync(fd)
      return
    } catch (error) {
      if (error.code !== 'EEXIST') throw error
      try {
        const info = JSON.parse(fs.readFileSync(file, 'utf8'))
        const alive = Number.isInteger(info.pid) && info.pid > 0 && (() => {
          try {
            process.kill(info.pid, 0)
            return true
          } catch (error) {
            return error.code !== 'ESRCH'
          }
        })()
        if (!alive) {
          fs.unlinkSync(file)
          continue
        }
      } catch (error) {
        if (error.code === 'ENOENT') continue
        if (!(error instanceof SyntaxError)) throw error
        try {
          // Another process may still be writing a new lock.
          if (Date.now() - fs.statSync(file).mtimeMs > 5000) {
            fs.unlinkSync(file)
            continue
          }
        } catch (error) {
          if (error.code === 'ENOENT') continue
          throw error
        }
      }
      if (Date.now() > deadline) throw new Error('另一个填报任务正在运行（浏览器占用中），请稍后再试')
      await new Promise((resolve) => setTimeout(resolve, 500))
    }
  }
}

function releaseLock() {
  try {
    fs.unlinkSync(lockFile())
  } catch {
    // already gone
  }
}

export async function open({ headless = true, slowMo = 0 } = {}) {
  ensureDirs()
  await acquireLock()
  let context
  let page
  try {
    ;({ context } = await launchBrowser({ headless, slowMo }))
    page = context.pages()[0] ?? (await context.newPage())
    page.setDefaultTimeout(20_000)
  } catch (error) {
    try {
      await context?.close().catch(() => {})
    } finally {
      releaseLock()
    }
    throw error
  }
  return {
    context,
    page,
    async close() {
      try {
        await context.close()
      } finally {
        releaseLock()
      }
    },
  }
}

export async function screenshot(page, name) {
  ensureDirs()
  const file = path.join(files.screenshots(), `${name}.png`)
  await page.screenshot({ path: file, fullPage: false })
  return file
}
